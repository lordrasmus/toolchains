/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_movsi_high (reload_completed)
#define HAVE_movstricthi_high (reload_completed)
#define HAVE_movsi_low (reload_completed)
#define HAVE_movsi_high_pic 1
#define HAVE_movsi_low_pic 1
#define HAVE_movdi_insn (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) == REG)
#define HAVE_movbi 1
#define HAVE_movpdi 1
#define HAVE_load_accumulator 1
#define HAVE_load_accumulator_pair 1
#define HAVE_movdf_insn (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) == REG)
#define HAVE_movstricthi_1 1
#define HAVE_extendhisi2 1
#define HAVE_zero_extendhisi2 1
#define HAVE_zero_extendbisi2 1
#define HAVE_extendqihi2 1
#define HAVE_extendqisi2 1
#define HAVE_zero_extendqihi2 1
#define HAVE_zero_extendqisi2 1
#define HAVE_zero_extendqidi2 1
#define HAVE_zero_extendhidi2 1
#define HAVE_extendsidi2 1
#define HAVE_extendqidi2 1
#define HAVE_extendhidi2 1
#define HAVE_add_with_carry 1
#define HAVE_sub_with_carry 1
#define HAVE_mulhisi3 1
#define HAVE_umulhisi3 1
#define HAVE_usmulhisi3 1
#define HAVE_addsi3 1
#define HAVE_ssaddsi3 1
#define HAVE_subsi3 1
#define HAVE_sssubsi3 1
#define HAVE_addpdi3 1
#define HAVE_sum_of_accumulators 1
#define HAVE_us_truncpdisi2 1
#define HAVE_iorsi3 1
#define HAVE_xorsi3 1
#define HAVE_ones 1
#define HAVE_smaxsi3 1
#define HAVE_sminsi3 1
#define HAVE_abssi2 1
#define HAVE_ssabssi2 1
#define HAVE_negsi2 1
#define HAVE_ssnegsi2 1
#define HAVE_one_cmplsi2 1
#define HAVE_signbitssi2 1
#define HAVE_ssroundsi2 1
#define HAVE_smaxhi3 1
#define HAVE_sminhi3 1
#define HAVE_abshi2 1
#define HAVE_neghi2 1
#define HAVE_ssneghi2 1
#define HAVE_clrsbhi2 1
#define HAVE_mulsi3 1
#define HAVE_ashrsi3 1
#define HAVE_rotl16 1
#define HAVE_ror_one 1
#define HAVE_rol_one 1
#define HAVE_lshrsi3 1
#define HAVE_lshrpdi3 1
#define HAVE_ashrpdi3 1
#define HAVE_reload_inpdi 1
#define HAVE_reload_inv2pdi 1
#define HAVE_reload_outpdi 1
#define HAVE_reload_outv2pdi 1
#define HAVE_jump 1
#define HAVE_indirect_jump 1
#define HAVE_loop_end 1
#define HAVE_lsetup_with_autoinit 1
#define HAVE_lsetup_without_autoinit 1
#define HAVE_load_funcdescsi 1
#define HAVE_rep_movsi 1
#define HAVE_rep_movhi 1
#define HAVE_compare_eq 1
#define HAVE_compare_lt 1
#define HAVE_compare_le 1
#define HAVE_compare_leu 1
#define HAVE_compare_ltu 1
#define HAVE_flag_mul_macv2hi_parts_acconly_andcc0 (MACFLAGS_MATCH_P (INTVAL (operands[10]), INTVAL (operands[11])))
#define HAVE_cbranchbi4 1
#define HAVE_cbranch_predicted_taken 1
#define HAVE_cbranch_with_nops (reload_completed)
#define HAVE_nop 1
#define HAVE_forced_nop 1
#define HAVE_mnop 1
#define HAVE_movsibi 1
#define HAVE_movbisi 1
#define HAVE_notbi 1
#define HAVE_eh_store_handler 1
#define HAVE_eh_return_internal 1
#define HAVE_link 1
#define HAVE_unlink 1
#define HAVE_push_multiple 1
#define HAVE_pop_multiple 1
#define HAVE_return_internal (reload_completed)
#define HAVE_dummy_load 1
#define HAVE_stall 1
#define HAVE_csync 1
#define HAVE_ssync 1
#define HAVE_trap 1
#define HAVE_trapifcc 1
#define HAVE_movhiv2hi_low 1
#define HAVE_movhiv2hi_high 1
#define HAVE_composev2hi 1
#define HAVE_packv2hi 1
#define HAVE_movv2hi_hi 1
#define HAVE_ssaddhi3 1
#define HAVE_sssubhi3 1
#define HAVE_ssaddhi3_parts 1
#define HAVE_sssubhi3_parts 1
#define HAVE_ssaddhi3_low_parts 1
#define HAVE_sssubhi3_low_parts 1
#define HAVE_ssaddhi3_high_parts 1
#define HAVE_sssubhi3_high_parts 1
#define HAVE_addv2hi3 1
#define HAVE_ssaddv2hi3 1
#define HAVE_subv2hi3 1
#define HAVE_sssubv2hi3 1
#define HAVE_addsubv2hi3 1
#define HAVE_subaddv2hi3 1
#define HAVE_ssaddsubv2hi3 1
#define HAVE_sssubaddv2hi3 1
#define HAVE_sublohiv2hi3 1
#define HAVE_subhilov2hi3 1
#define HAVE_sssublohiv2hi3 1
#define HAVE_sssubhilov2hi3 1
#define HAVE_addlohiv2hi3 1
#define HAVE_addhilov2hi3 1
#define HAVE_ssaddlohiv2hi3 1
#define HAVE_ssaddhilov2hi3 1
#define HAVE_sminv2hi3 1
#define HAVE_smaxv2hi3 1
#define HAVE_flag_mulhi 1
#define HAVE_flag_mulhi_parts 1
#define HAVE_flag_mulhisi 1
#define HAVE_flag_mulhisi_parts 1
#define HAVE_flag_machi 1
#define HAVE_flag_machi_acconly 1
#define HAVE_flag_machi_parts_acconly 1
#define HAVE_flag_macinithi 1
#define HAVE_flag_macinit1hi 1
#define HAVE_mulv2hi3 1
#define HAVE_flag_mulv2hi 1
#define HAVE_flag_mulv2hi_parts 1
#define HAVE_flag_macv2hi_parts 1
#define HAVE_flag_macv2hi_parts_acconly 1
#define HAVE_flag_macinitv2hi_parts 1
#define HAVE_flag_macinit1v2hi_parts 1
#define HAVE_flag_mul_macv2hi_parts_acconly (MACFLAGS_MATCH_P (INTVAL (operands[10]), INTVAL (operands[11])))
#define HAVE_mulhisi_ll 1
#define HAVE_umulhisi_ll 1
#define HAVE_mulhisi_lh 1
#define HAVE_umulhisi_lh 1
#define HAVE_mulhisi_hl 1
#define HAVE_umulhisi_hl 1
#define HAVE_mulhisi_hh 1
#define HAVE_umulhisi_hh 1
#define HAVE_usmulhisi_ull 1
#define HAVE_usmulhisi_ulh 1
#define HAVE_usmulhisi_uhl 1
#define HAVE_usmulhisi_uhh 1
#define HAVE_mulhisi_ll_lh 1
#define HAVE_umulhisi_ll_lh 1
#define HAVE_mulhisi_ll_hl 1
#define HAVE_umulhisi_ll_hl 1
#define HAVE_mulhisi_ll_hh 1
#define HAVE_umulhisi_ll_hh 1
#define HAVE_mulhisi_lh_hl 1
#define HAVE_umulhisi_lh_hl 1
#define HAVE_mulhisi_lh_hh 1
#define HAVE_umulhisi_lh_hh 1
#define HAVE_mulhisi_hl_hh 1
#define HAVE_umulhisi_hl_hh 1
#define HAVE_usmulhisi_ll_lul 1
#define HAVE_usmulhisi_ll_luh 1
#define HAVE_usmulhisi_ll_hul 1
#define HAVE_usmulhisi_ll_huh 1
#define HAVE_usmulhisi_lh_lul 1
#define HAVE_usmulhisi_lh_luh 1
#define HAVE_usmulhisi_lh_hul 1
#define HAVE_usmulhisi_lh_huh 1
#define HAVE_usmulhisi_hl_lul 1
#define HAVE_usmulhisi_hl_luh 1
#define HAVE_usmulhisi_hl_hul 1
#define HAVE_usmulhisi_hl_huh 1
#define HAVE_usmulhisi_hh_lul 1
#define HAVE_usmulhisi_hh_luh 1
#define HAVE_usmulhisi_hh_hul 1
#define HAVE_usmulhisi_hh_huh 1
#define HAVE_ssnegv2hi2 1
#define HAVE_ssabsv2hi2 1
#define HAVE_ssashiftv2hi3 1
#define HAVE_ssashifthi3 1
#define HAVE_ssashiftsi3 1
#define HAVE_lshiftv2hi3 1
#define HAVE_lshifthi3 1
#define HAVE_loadbytes 1
#define HAVE_sync_addsi_internal 1
#define HAVE_sync_subsi_internal 1
#define HAVE_sync_iorsi_internal 1
#define HAVE_sync_andsi_internal 1
#define HAVE_sync_xorsi_internal 1
#define HAVE_sync_old_addsi_internal 1
#define HAVE_sync_old_subsi_internal 1
#define HAVE_sync_old_iorsi_internal 1
#define HAVE_sync_old_andsi_internal 1
#define HAVE_sync_old_xorsi_internal 1
#define HAVE_sync_new_addsi_internal 1
#define HAVE_sync_new_subsi_internal 1
#define HAVE_sync_new_iorsi_internal 1
#define HAVE_sync_new_andsi_internal 1
#define HAVE_sync_new_xorsi_internal 1
#define HAVE_sync_compare_and_swapsi_internal 1
#define HAVE_movqicc 1
#define HAVE_movhicc 1
#define HAVE_movsicc 1
#define HAVE_insv 1
#define HAVE_movsi 1
#define HAVE_movv2hi 1
#define HAVE_movdi 1
#define HAVE_movsf 1
#define HAVE_movdf 1
#define HAVE_movhi 1
#define HAVE_movqi 1
#define HAVE_anddi3 1
#define HAVE_iordi3 1
#define HAVE_xordi3 1
#define HAVE_adddi3 1
#define HAVE_subdi3 1
#define HAVE_andsi3 1
#define HAVE_popcountsi2 1
#define HAVE_popcounthi2 1
#define HAVE_clrsbsi2 1
#define HAVE_umulsi3_highpart 1
#define HAVE_smulsi3_highpart 1
#define HAVE_ashlsi3 1
#define HAVE_rotlsi3 1
#define HAVE_rotrsi3 1
#define HAVE_lshrdi3 1
#define HAVE_ashrdi3 1
#define HAVE_ashldi3 1
#define HAVE_reload_insi 1
#define HAVE_tablejump 1
#define HAVE_doloop_end 1
#define HAVE_call 1
#define HAVE_sibcall 1
#define HAVE_call_value 1
#define HAVE_sibcall_value 1
#define HAVE_cpymemsi 1
#define HAVE_cbranchsi4 1
#define HAVE_cstorebi4 1
#define HAVE_cstoresi4 1
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_eh_return 1
#define HAVE_movv2hi_hi_low 1
#define HAVE_movv2hi_hi_high 1
#define HAVE_sync_addsi 1
#define HAVE_sync_subsi 1
#define HAVE_sync_iorsi 1
#define HAVE_sync_andsi 1
#define HAVE_sync_xorsi 1
#define HAVE_sync_old_addsi 1
#define HAVE_sync_old_subsi 1
#define HAVE_sync_old_iorsi 1
#define HAVE_sync_old_andsi 1
#define HAVE_sync_old_xorsi 1
#define HAVE_sync_new_addsi 1
#define HAVE_sync_new_subsi 1
#define HAVE_sync_new_iorsi 1
#define HAVE_sync_new_andsi 1
#define HAVE_sync_new_xorsi 1
#define HAVE_sync_compare_and_swapsi 1
extern rtx        gen_movsi_high                            (rtx, rtx);
extern rtx        gen_movstricthi_high                      (rtx, rtx);
extern rtx        gen_movsi_low                             (rtx, rtx, rtx);
extern rtx        gen_movsi_high_pic                        (rtx, rtx);
extern rtx        gen_movsi_low_pic                         (rtx, rtx, rtx);
extern rtx        gen_movdi_insn                            (rtx, rtx);
extern rtx        gen_movbi                                 (rtx, rtx);
extern rtx        gen_movpdi                                (rtx, rtx);
extern rtx        gen_load_accumulator                      (rtx, rtx);
extern rtx        gen_load_accumulator_pair                 (rtx, rtx, rtx);
extern rtx        gen_movdf_insn                            (rtx, rtx);
extern rtx        gen_movstricthi_1                         (rtx, rtx);
extern rtx        gen_extendhisi2                           (rtx, rtx);
extern rtx        gen_zero_extendhisi2                      (rtx, rtx);
extern rtx        gen_zero_extendbisi2                      (rtx, rtx);
extern rtx        gen_extendqihi2                           (rtx, rtx);
extern rtx        gen_extendqisi2                           (rtx, rtx);
extern rtx        gen_zero_extendqihi2                      (rtx, rtx);
extern rtx        gen_zero_extendqisi2                      (rtx, rtx);
extern rtx        gen_zero_extendqidi2                      (rtx, rtx);
extern rtx        gen_zero_extendhidi2                      (rtx, rtx);
extern rtx        gen_extendsidi2                           (rtx, rtx);
extern rtx        gen_extendqidi2                           (rtx, rtx);
extern rtx        gen_extendhidi2                           (rtx, rtx);
extern rtx        gen_add_with_carry                        (rtx, rtx, rtx, rtx);
extern rtx        gen_sub_with_carry                        (rtx, rtx, rtx, rtx);
extern rtx        gen_mulhisi3                              (rtx, rtx, rtx);
extern rtx        gen_umulhisi3                             (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3                            (rtx, rtx, rtx);
extern rtx        gen_addsi3                                (rtx, rtx, rtx);
extern rtx        gen_ssaddsi3                              (rtx, rtx, rtx);
extern rtx        gen_subsi3                                (rtx, rtx, rtx);
extern rtx        gen_sssubsi3                              (rtx, rtx, rtx);
extern rtx        gen_addpdi3                               (rtx, rtx, rtx);
extern rtx        gen_sum_of_accumulators                   (rtx, rtx, rtx, rtx);
extern rtx        gen_us_truncpdisi2                        (rtx, rtx);
extern rtx        gen_iorsi3                                (rtx, rtx, rtx);
extern rtx        gen_xorsi3                                (rtx, rtx, rtx);
extern rtx        gen_ones                                  (rtx, rtx);
extern rtx        gen_smaxsi3                               (rtx, rtx, rtx);
extern rtx        gen_sminsi3                               (rtx, rtx, rtx);
extern rtx        gen_abssi2                                (rtx, rtx);
extern rtx        gen_ssabssi2                              (rtx, rtx);
extern rtx        gen_negsi2                                (rtx, rtx);
extern rtx        gen_ssnegsi2                              (rtx, rtx);
extern rtx        gen_one_cmplsi2                           (rtx, rtx);
extern rtx        gen_signbitssi2                           (rtx, rtx);
extern rtx        gen_ssroundsi2                            (rtx, rtx);
extern rtx        gen_smaxhi3                               (rtx, rtx, rtx);
extern rtx        gen_sminhi3                               (rtx, rtx, rtx);
extern rtx        gen_abshi2                                (rtx, rtx);
extern rtx        gen_neghi2                                (rtx, rtx);
extern rtx        gen_ssneghi2                              (rtx, rtx);
extern rtx        gen_clrsbhi2                              (rtx, rtx);
extern rtx        gen_mulsi3                                (rtx, rtx, rtx);
extern rtx        gen_ashrsi3                               (rtx, rtx, rtx);
extern rtx        gen_rotl16                                (rtx, rtx);
extern rtx        gen_ror_one                               (rtx, rtx);
extern rtx        gen_rol_one                               (rtx, rtx);
extern rtx        gen_lshrsi3                               (rtx, rtx, rtx);
extern rtx        gen_lshrpdi3                              (rtx, rtx, rtx);
extern rtx        gen_ashrpdi3                              (rtx, rtx, rtx);
extern rtx        gen_reload_inpdi                          (rtx, rtx, rtx);
extern rtx        gen_reload_inv2pdi                        (rtx, rtx, rtx);
extern rtx        gen_reload_outpdi                         (rtx, rtx, rtx);
extern rtx        gen_reload_outv2pdi                       (rtx, rtx, rtx);
extern rtx        gen_jump                                  (rtx);
extern rtx        gen_indirect_jump                         (rtx);
extern rtx        gen_loop_end                              (rtx, rtx, rtx);
extern rtx        gen_lsetup_with_autoinit                  (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_lsetup_without_autoinit               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_load_funcdescsi                       (rtx, rtx);
extern rtx        gen_rep_movsi                             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_rep_movhi                             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_compare_eq                            (rtx, rtx, rtx);
static inline rtx gen_compare_ne                            (rtx, rtx, rtx);
static inline rtx
gen_compare_ne(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_compare_lt                            (rtx, rtx, rtx);
extern rtx        gen_compare_le                            (rtx, rtx, rtx);
extern rtx        gen_compare_leu                           (rtx, rtx, rtx);
extern rtx        gen_compare_ltu                           (rtx, rtx, rtx);
extern rtx        gen_flag_mul_macv2hi_parts_acconly_andcc0 (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchbi4                            (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranch_predicted_taken               (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranch_with_nops                     (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_nop                                   (void);
extern rtx        gen_forced_nop                            (void);
extern rtx        gen_mnop                                  (void);
extern rtx        gen_movsibi                               (rtx, rtx);
extern rtx        gen_movbisi                               (rtx, rtx);
extern rtx        gen_notbi                                 (rtx, rtx);
extern rtx        gen_eh_store_handler                      (rtx, rtx);
extern rtx        gen_eh_return_internal                    (void);
extern rtx        gen_link                                  (rtx);
extern rtx        gen_unlink                                (void);
extern rtx        gen_push_multiple                         (rtx, rtx);
extern rtx        gen_pop_multiple                          (rtx, rtx);
extern rtx        gen_return_internal                       (rtx);
extern rtx        gen_dummy_load                            (rtx, rtx);
extern rtx        gen_stall                                 (rtx);
extern rtx        gen_csync                                 (void);
extern rtx        gen_ssync                                 (void);
extern rtx        gen_trap                                  (void);
extern rtx        gen_trapifcc                              (void);
extern rtx        gen_movhiv2hi_low                         (rtx, rtx, rtx);
extern rtx        gen_movhiv2hi_high                        (rtx, rtx, rtx);
extern rtx        gen_composev2hi                           (rtx, rtx, rtx);
extern rtx        gen_packv2hi                              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_movv2hi_hi                            (rtx, rtx, rtx);
extern rtx        gen_ssaddhi3                              (rtx, rtx, rtx);
extern rtx        gen_sssubhi3                              (rtx, rtx, rtx);
extern rtx        gen_ssaddhi3_parts                        (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sssubhi3_parts                        (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_ssaddhi3_low_parts                    (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sssubhi3_low_parts                    (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_ssaddhi3_high_parts                   (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sssubhi3_high_parts                   (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_addv2hi3                              (rtx, rtx, rtx);
extern rtx        gen_ssaddv2hi3                            (rtx, rtx, rtx);
extern rtx        gen_subv2hi3                              (rtx, rtx, rtx);
extern rtx        gen_sssubv2hi3                            (rtx, rtx, rtx);
extern rtx        gen_addsubv2hi3                           (rtx, rtx, rtx);
extern rtx        gen_subaddv2hi3                           (rtx, rtx, rtx);
extern rtx        gen_ssaddsubv2hi3                         (rtx, rtx, rtx);
extern rtx        gen_sssubaddv2hi3                         (rtx, rtx, rtx);
extern rtx        gen_sublohiv2hi3                          (rtx, rtx, rtx);
extern rtx        gen_subhilov2hi3                          (rtx, rtx, rtx);
extern rtx        gen_sssublohiv2hi3                        (rtx, rtx, rtx);
extern rtx        gen_sssubhilov2hi3                        (rtx, rtx, rtx);
extern rtx        gen_addlohiv2hi3                          (rtx, rtx, rtx);
extern rtx        gen_addhilov2hi3                          (rtx, rtx, rtx);
extern rtx        gen_ssaddlohiv2hi3                        (rtx, rtx, rtx);
extern rtx        gen_ssaddhilov2hi3                        (rtx, rtx, rtx);
extern rtx        gen_sminv2hi3                             (rtx, rtx, rtx);
extern rtx        gen_smaxv2hi3                             (rtx, rtx, rtx);
extern rtx        gen_flag_mulhi                            (rtx, rtx, rtx, rtx);
extern rtx        gen_flag_mulhi_parts                      (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_mulhisi                          (rtx, rtx, rtx, rtx);
extern rtx        gen_flag_mulhisi_parts                    (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_machi                            (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_machi_acconly                    (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_machi_parts_acconly              (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_macinithi                        (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_macinit1hi                       (rtx, rtx, rtx, rtx);
extern rtx        gen_mulv2hi3                              (rtx, rtx, rtx);
extern rtx        gen_flag_mulv2hi                          (rtx, rtx, rtx, rtx);
extern rtx        gen_flag_mulv2hi_parts                    (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_macv2hi_parts                    (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_macv2hi_parts_acconly            (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_macinitv2hi_parts                (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_macinit1v2hi_parts               (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_flag_mul_macv2hi_parts_acconly        (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_mulhisi_ll                            (rtx, rtx, rtx);
extern rtx        gen_umulhisi_ll                           (rtx, rtx, rtx);
extern rtx        gen_mulhisi_lh                            (rtx, rtx, rtx);
extern rtx        gen_umulhisi_lh                           (rtx, rtx, rtx);
extern rtx        gen_mulhisi_hl                            (rtx, rtx, rtx);
extern rtx        gen_umulhisi_hl                           (rtx, rtx, rtx);
extern rtx        gen_mulhisi_hh                            (rtx, rtx, rtx);
extern rtx        gen_umulhisi_hh                           (rtx, rtx, rtx);
extern rtx        gen_usmulhisi_ull                         (rtx, rtx, rtx);
extern rtx        gen_usmulhisi_ulh                         (rtx, rtx, rtx);
extern rtx        gen_usmulhisi_uhl                         (rtx, rtx, rtx);
extern rtx        gen_usmulhisi_uhh                         (rtx, rtx, rtx);
extern rtx        gen_mulhisi_ll_lh                         (rtx, rtx, rtx, rtx);
extern rtx        gen_umulhisi_ll_lh                        (rtx, rtx, rtx, rtx);
extern rtx        gen_mulhisi_ll_hl                         (rtx, rtx, rtx, rtx);
extern rtx        gen_umulhisi_ll_hl                        (rtx, rtx, rtx, rtx);
extern rtx        gen_mulhisi_ll_hh                         (rtx, rtx, rtx, rtx);
extern rtx        gen_umulhisi_ll_hh                        (rtx, rtx, rtx, rtx);
extern rtx        gen_mulhisi_lh_hl                         (rtx, rtx, rtx, rtx);
extern rtx        gen_umulhisi_lh_hl                        (rtx, rtx, rtx, rtx);
extern rtx        gen_mulhisi_lh_hh                         (rtx, rtx, rtx, rtx);
extern rtx        gen_umulhisi_lh_hh                        (rtx, rtx, rtx, rtx);
extern rtx        gen_mulhisi_hl_hh                         (rtx, rtx, rtx, rtx);
extern rtx        gen_umulhisi_hl_hh                        (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_ll_lul                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_ll_luh                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_ll_hul                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_ll_huh                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_lh_lul                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_lh_luh                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_lh_hul                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_lh_huh                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_hl_lul                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_hl_luh                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_hl_hul                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_hl_huh                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_hh_lul                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_hh_luh                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_hh_hul                      (rtx, rtx, rtx, rtx);
extern rtx        gen_usmulhisi_hh_huh                      (rtx, rtx, rtx, rtx);
extern rtx        gen_ssnegv2hi2                            (rtx, rtx);
extern rtx        gen_ssabsv2hi2                            (rtx, rtx);
extern rtx        gen_ssashiftv2hi3                         (rtx, rtx, rtx);
extern rtx        gen_ssashifthi3                           (rtx, rtx, rtx);
extern rtx        gen_ssashiftsi3                           (rtx, rtx, rtx);
extern rtx        gen_lshiftv2hi3                           (rtx, rtx, rtx);
extern rtx        gen_lshifthi3                             (rtx, rtx, rtx);
extern rtx        gen_loadbytes                             (rtx, rtx);
extern rtx        gen_sync_addsi_internal                   (rtx, rtx, rtx);
extern rtx        gen_sync_subsi_internal                   (rtx, rtx, rtx);
extern rtx        gen_sync_iorsi_internal                   (rtx, rtx, rtx);
extern rtx        gen_sync_andsi_internal                   (rtx, rtx, rtx);
extern rtx        gen_sync_xorsi_internal                   (rtx, rtx, rtx);
extern rtx        gen_sync_old_addsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_old_subsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_old_iorsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_old_andsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_old_xorsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_new_addsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_new_subsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_new_iorsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_new_andsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_new_xorsi_internal               (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_compare_and_swapsi_internal      (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_movqicc                               (rtx, rtx, rtx, rtx);
extern rtx        gen_movhicc                               (rtx, rtx, rtx, rtx);
extern rtx        gen_movsicc                               (rtx, rtx, rtx, rtx);
extern rtx        gen_insv                                  (rtx, rtx, rtx, rtx);
extern rtx        gen_movsi                                 (rtx, rtx);
extern rtx        gen_movv2hi                               (rtx, rtx);
extern rtx        gen_movdi                                 (rtx, rtx);
extern rtx        gen_movsf                                 (rtx, rtx);
extern rtx        gen_movdf                                 (rtx, rtx);
extern rtx        gen_movhi                                 (rtx, rtx);
extern rtx        gen_movqi                                 (rtx, rtx);
extern rtx        gen_anddi3                                (rtx, rtx, rtx);
extern rtx        gen_iordi3                                (rtx, rtx, rtx);
extern rtx        gen_xordi3                                (rtx, rtx, rtx);
extern rtx        gen_adddi3                                (rtx, rtx, rtx);
extern rtx        gen_subdi3                                (rtx, rtx, rtx);
extern rtx        gen_andsi3                                (rtx, rtx, rtx);
extern rtx        gen_popcountsi2                           (rtx, rtx);
extern rtx        gen_popcounthi2                           (rtx, rtx);
extern rtx        gen_clrsbsi2                              (rtx, rtx);
extern rtx        gen_umulsi3_highpart                      (rtx, rtx, rtx);
extern rtx        gen_smulsi3_highpart                      (rtx, rtx, rtx);
extern rtx        gen_ashlsi3                               (rtx, rtx, rtx);
extern rtx        gen_rotlsi3                               (rtx, rtx, rtx);
extern rtx        gen_rotrsi3                               (rtx, rtx, rtx);
extern rtx        gen_lshrdi3                               (rtx, rtx, rtx);
extern rtx        gen_ashrdi3                               (rtx, rtx, rtx);
extern rtx        gen_ashldi3                               (rtx, rtx, rtx);
extern rtx        gen_reload_insi                           (rtx, rtx, rtx);
extern rtx        gen_tablejump                             (rtx, rtx);
extern rtx        gen_doloop_end                            (rtx, rtx);
extern rtx        gen_call                                  (rtx, rtx, rtx);
extern rtx        gen_sibcall                               (rtx, rtx, rtx);
extern rtx        gen_call_value                            (rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value                         (rtx, rtx, rtx, rtx);
extern rtx        gen_cpymemsi                              (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsi4                            (rtx, rtx, rtx, rtx);
extern rtx        gen_cstorebi4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresi4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_prologue                              (void);
extern rtx        gen_epilogue                              (void);
extern rtx        gen_sibcall_epilogue                      (void);
extern rtx        gen_eh_return                             (rtx);
extern rtx        gen_movv2hi_hi_low                        (rtx, rtx);
extern rtx        gen_movv2hi_hi_high                       (rtx, rtx);
extern rtx        gen_sync_addsi                            (rtx, rtx);
extern rtx        gen_sync_subsi                            (rtx, rtx);
extern rtx        gen_sync_iorsi                            (rtx, rtx);
extern rtx        gen_sync_andsi                            (rtx, rtx);
extern rtx        gen_sync_xorsi                            (rtx, rtx);
extern rtx        gen_sync_old_addsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_old_subsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_old_iorsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_old_andsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_old_xorsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_new_addsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_new_subsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_new_iorsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_new_andsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_new_xorsi                        (rtx, rtx, rtx);
extern rtx        gen_sync_compare_and_swapsi               (rtx, rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
