/* Generated automatically by the program 'build/genpreds'
   from the machine description file '/home/ramin/openadk/toolchain_build_generic-bfin_uclibc-ng_bf512_flat_nommu/w-gcc-13.2.0-1/gcc-13.2.0/gcc/config/bfin/bfin.md'.  */

#ifndef GCC_TM_PREDS_H
#define GCC_TM_PREDS_H

#ifdef HAVE_MACHINE_MODES
extern bool general_operand (rtx, machine_mode);
extern bool address_operand (rtx, machine_mode);
extern bool register_operand (rtx, machine_mode);
extern bool pmode_register_operand (rtx, machine_mode);
extern bool scratch_operand (rtx, machine_mode);
extern bool immediate_operand (rtx, machine_mode);
extern bool const_int_operand (rtx, machine_mode);
extern bool const_double_operand (rtx, machine_mode);
extern bool nonimmediate_operand (rtx, machine_mode);
extern bool nonmemory_operand (rtx, machine_mode);
extern bool push_operand (rtx, machine_mode);
extern bool pop_operand (rtx, machine_mode);
extern bool memory_operand (rtx, machine_mode);
extern bool indirect_operand (rtx, machine_mode);
extern bool ordered_comparison_operator (rtx, machine_mode);
extern bool comparison_operator (rtx, machine_mode);
extern bool pos_scale_operand (rtx, machine_mode);
extern bool scale_by_operand (rtx, machine_mode);
extern bool highbits_operand (rtx, machine_mode);
extern bool rhs_andsi3_operand (rtx, machine_mode);
extern bool regorlog2_operand (rtx, machine_mode);
extern bool reg_or_const_int_operand (rtx, machine_mode);
extern bool const01_operand (rtx, machine_mode);
extern bool const1_operand (rtx, machine_mode);
extern bool const3_operand (rtx, machine_mode);
extern bool vec_shift_operand (rtx, machine_mode);
extern bool valid_reg_operand (rtx, machine_mode);
extern bool d_register_operand (rtx, machine_mode);
extern bool p_register_operand (rtx, machine_mode);
extern bool dp_register_operand (rtx, machine_mode);
extern bool lc_register_operand (rtx, machine_mode);
extern bool lt_register_operand (rtx, machine_mode);
extern bool lb_register_operand (rtx, machine_mode);
extern bool reg_or_7bit_operand (rtx, machine_mode);
extern bool nondp_register_operand (rtx, machine_mode);
extern bool nondp_reg_or_memory_operand (rtx, machine_mode);
extern bool reg_or_neg7bit_operand (rtx, machine_mode);
extern bool fp_plus_const_operand (rtx, machine_mode);
extern bool symbolic_operand (rtx, machine_mode);
extern bool symbolic_or_const_operand (rtx, machine_mode);
extern bool symbol_ref_operand (rtx, machine_mode);
extern bool register_no_elim_operand (rtx, machine_mode);
extern bool bfin_bimode_comparison_operator (rtx, machine_mode);
extern bool bfin_direct_comparison_operator (rtx, machine_mode);
extern bool mem_p_address_operand (rtx, machine_mode);
extern bool mem_spfp_address_operand (rtx, machine_mode);
extern bool mem_i_address_operand (rtx, machine_mode);
extern bool push_multiple_operation (rtx, machine_mode);
extern bool pop_multiple_operation (rtx, machine_mode);
#endif /* HAVE_MACHINE_MODES */

#define CONSTRAINT_NUM_DEFINED_P 1
enum constraint_num
{
  CONSTRAINT__UNKNOWN = 0,
  CONSTRAINT_r,
  CONSTRAINT_a,
  CONSTRAINT_d,
  CONSTRAINT_z,
  CONSTRAINT_D,
  CONSTRAINT_W,
  CONSTRAINT_e,
  CONSTRAINT_A,
  CONSTRAINT_B,
  CONSTRAINT_b,
  CONSTRAINT_v,
  CONSTRAINT_f,
  CONSTRAINT_c,
  CONSTRAINT_C,
  CONSTRAINT_t,
  CONSTRAINT_u,
  CONSTRAINT_k,
  CONSTRAINT_x,
  CONSTRAINT_y,
  CONSTRAINT_w,
  CONSTRAINT_Z,
  CONSTRAINT_Y,
  CONSTRAINT_q0,
  CONSTRAINT_q1,
  CONSTRAINT_q2,
  CONSTRAINT_q3,
  CONSTRAINT_q4,
  CONSTRAINT_q5,
  CONSTRAINT_q6,
  CONSTRAINT_q7,
  CONSTRAINT_qA,
  CONSTRAINT_J,
  CONSTRAINT_Ks3,
  CONSTRAINT_Ku3,
  CONSTRAINT_Ks4,
  CONSTRAINT_Ku4,
  CONSTRAINT_Ks5,
  CONSTRAINT_Ku5,
  CONSTRAINT_Ks7,
  CONSTRAINT_KN7,
  CONSTRAINT_Ksh,
  CONSTRAINT_Kuh,
  CONSTRAINT_L,
  CONSTRAINT_M1,
  CONSTRAINT_M2,
  CONSTRAINT_P0,
  CONSTRAINT_P1,
  CONSTRAINT_P2,
  CONSTRAINT_P3,
  CONSTRAINT_P4,
  CONSTRAINT_PA,
  CONSTRAINT_PB,
  CONSTRAINT_m,
  CONSTRAINT_o,
  CONSTRAINT_p,
  CONSTRAINT_Q,
  CONSTRAINT_V,
  CONSTRAINT__l,
  CONSTRAINT__g,
  CONSTRAINT_i,
  CONSTRAINT_s,
  CONSTRAINT_n,
  CONSTRAINT_E,
  CONSTRAINT_F,
  CONSTRAINT_X,
  CONSTRAINT__LIMIT
};

extern enum constraint_num lookup_constraint_1 (const char *);
extern const unsigned char lookup_constraint_array[];

/* Return the constraint at the beginning of P, or CONSTRAINT__UNKNOWN if it
   isn't recognized.  */

static inline enum constraint_num
lookup_constraint (const char *p)
{
  unsigned int index = lookup_constraint_array[(unsigned char) *p];
  return (index == UCHAR_MAX
          ? lookup_constraint_1 (p)
          : (enum constraint_num) index);
}

extern bool (*constraint_satisfied_p_array[]) (rtx);

/* Return true if X satisfies constraint C.  */

static inline bool
constraint_satisfied_p (rtx x, enum constraint_num c)
{
  int i = (int) c - (int) CONSTRAINT_J;
  return i >= 0 && constraint_satisfied_p_array[i] (x);
}

static inline bool
insn_extra_register_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_r && c <= CONSTRAINT_qA;
}

static inline bool
insn_extra_memory_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_m && c <= CONSTRAINT_o;
}

static inline bool
insn_extra_special_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_relaxed_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_address_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_p && c <= CONSTRAINT_p;
}

static inline void
insn_extra_constraint_allows_reg_mem (enum constraint_num c,
				      bool *allows_reg, bool *allows_mem)
{
  if (c >= CONSTRAINT_Q && c <= CONSTRAINT_Q)
    return;
  if (c >= CONSTRAINT_V && c <= CONSTRAINT__g)
    {
      *allows_mem = true;
      return;
    }
  (void) c;
  *allows_reg = true;
  *allows_mem = true;
}

static inline size_t
insn_constraint_len (char fc, const char *str ATTRIBUTE_UNUSED)
{
  switch (fc)
    {
    case 'K': return 3;
    case 'M': return 2;
    case 'P': return 2;
    case 'q': return 2;
    default: break;
    }
  return 1;
}

#define CONSTRAINT_LEN(c_,s_) insn_constraint_len (c_,s_)

extern enum reg_class reg_class_for_constraint_1 (enum constraint_num);

static inline enum reg_class
reg_class_for_constraint (enum constraint_num c)
{
  if (insn_extra_register_constraint (c))
    return reg_class_for_constraint_1 (c);
  return NO_REGS;
}

extern bool insn_const_int_ok_for_constraint (HOST_WIDE_INT, enum constraint_num);
#define CONST_OK_FOR_CONSTRAINT_P(v_,c_,s_) \
    insn_const_int_ok_for_constraint (v_, lookup_constraint (s_))

enum constraint_type
{
  CT_REGISTER,
  CT_CONST_INT,
  CT_MEMORY,
  CT_SPECIAL_MEMORY,
  CT_RELAXED_MEMORY,
  CT_ADDRESS,
  CT_FIXED_FORM
};

static inline enum constraint_type
get_constraint_type (enum constraint_num c)
{
  if (c >= CONSTRAINT_p)
    {
      if (c >= CONSTRAINT_Q)
        return CT_FIXED_FORM;
      return CT_ADDRESS;
    }
  if (c >= CONSTRAINT_m)
    return CT_MEMORY;
  if (c >= CONSTRAINT_J)
    return CT_CONST_INT;
  return CT_REGISTER;
}
#endif /* tm-preds.h */
