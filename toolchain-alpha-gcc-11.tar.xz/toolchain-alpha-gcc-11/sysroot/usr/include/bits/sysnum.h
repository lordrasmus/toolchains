/* WARNING!!! AUTO-GENERATED FILE!!! DO NOT EDIT!!! */
/* See extra/scripts/gen_bits_syscall_h.sh for more information. */

#ifndef _BITS_SYSNUM_H
#define _BITS_SYSNUM_H

#ifndef _SYSCALL_H
# error "Never use <bits/sysnum.h> directly; include <sys/syscall.h> instead."
#endif

#undef __NR_umount
#define __NR_umount 22
#define SYS_umount __NR_umount
#undef __NR_osf_shmat
#define __NR_osf_shmat 209
#define SYS_osf_shmat __NR_osf_shmat
#undef __NR_getpid
#define __NR_getpid 20
#define SYS_getpid __NR_getpid
#undef __NR_getuid
#define __NR_getuid 24
#define SYS_getuid __NR_getuid
#undef __NR_getgid
#define __NR_getgid 47
#define SYS_getgid __NR_getgid
#undef __NR_osf_syscall
#define __NR_osf_syscall 0
#define SYS_osf_syscall __NR_osf_syscall
#undef __NR_exit
#define __NR_exit 1
#define SYS_exit __NR_exit
#undef __NR_fork
#define __NR_fork 2
#define SYS_fork __NR_fork
#undef __NR_read
#define __NR_read 3
#define SYS_read __NR_read
#undef __NR_write
#define __NR_write 4
#define SYS_write __NR_write
#undef __NR_osf_old_open
#define __NR_osf_old_open 5
#define SYS_osf_old_open __NR_osf_old_open
#undef __NR_close
#define __NR_close 6
#define SYS_close __NR_close
#undef __NR_osf_wait4
#define __NR_osf_wait4 7
#define SYS_osf_wait4 __NR_osf_wait4
#undef __NR_osf_old_creat
#define __NR_osf_old_creat 8
#define SYS_osf_old_creat __NR_osf_old_creat
#undef __NR_link
#define __NR_link 9
#define SYS_link __NR_link
#undef __NR_unlink
#define __NR_unlink 10
#define SYS_unlink __NR_unlink
#undef __NR_osf_execve
#define __NR_osf_execve 11
#define SYS_osf_execve __NR_osf_execve
#undef __NR_chdir
#define __NR_chdir 12
#define SYS_chdir __NR_chdir
#undef __NR_fchdir
#define __NR_fchdir 13
#define SYS_fchdir __NR_fchdir
#undef __NR_mknod
#define __NR_mknod 14
#define SYS_mknod __NR_mknod
#undef __NR_chmod
#define __NR_chmod 15
#define SYS_chmod __NR_chmod
#undef __NR_chown
#define __NR_chown 16
#define SYS_chown __NR_chown
#undef __NR_brk
#define __NR_brk 17
#define SYS_brk __NR_brk
#undef __NR_osf_getfsstat
#define __NR_osf_getfsstat 18
#define SYS_osf_getfsstat __NR_osf_getfsstat
#undef __NR_lseek
#define __NR_lseek 19
#define SYS_lseek __NR_lseek
#undef __NR_getxpid
#define __NR_getxpid 20
#define SYS_getxpid __NR_getxpid
#undef __NR_osf_mount
#define __NR_osf_mount 21
#define SYS_osf_mount __NR_osf_mount
#undef __NR_umount2
#define __NR_umount2 22
#define SYS_umount2 __NR_umount2
#undef __NR_setuid
#define __NR_setuid 23
#define SYS_setuid __NR_setuid
#undef __NR_getxuid
#define __NR_getxuid 24
#define SYS_getxuid __NR_getxuid
#undef __NR_exec_with_loader
#define __NR_exec_with_loader 25
#define SYS_exec_with_loader __NR_exec_with_loader
#undef __NR_ptrace
#define __NR_ptrace 26
#define SYS_ptrace __NR_ptrace
#undef __NR_osf_nrecvmsg
#define __NR_osf_nrecvmsg 27
#define SYS_osf_nrecvmsg __NR_osf_nrecvmsg
#undef __NR_osf_nsendmsg
#define __NR_osf_nsendmsg 28
#define SYS_osf_nsendmsg __NR_osf_nsendmsg
#undef __NR_osf_nrecvfrom
#define __NR_osf_nrecvfrom 29
#define SYS_osf_nrecvfrom __NR_osf_nrecvfrom
#undef __NR_osf_naccept
#define __NR_osf_naccept 30
#define SYS_osf_naccept __NR_osf_naccept
#undef __NR_osf_ngetpeername
#define __NR_osf_ngetpeername 31
#define SYS_osf_ngetpeername __NR_osf_ngetpeername
#undef __NR_osf_ngetsockname
#define __NR_osf_ngetsockname 32
#define SYS_osf_ngetsockname __NR_osf_ngetsockname
#undef __NR_access
#define __NR_access 33
#define SYS_access __NR_access
#undef __NR_osf_chflags
#define __NR_osf_chflags 34
#define SYS_osf_chflags __NR_osf_chflags
#undef __NR_osf_fchflags
#define __NR_osf_fchflags 35
#define SYS_osf_fchflags __NR_osf_fchflags
#undef __NR_sync
#define __NR_sync 36
#define SYS_sync __NR_sync
#undef __NR_kill
#define __NR_kill 37
#define SYS_kill __NR_kill
#undef __NR_osf_old_stat
#define __NR_osf_old_stat 38
#define SYS_osf_old_stat __NR_osf_old_stat
#undef __NR_setpgid
#define __NR_setpgid 39
#define SYS_setpgid __NR_setpgid
#undef __NR_osf_old_lstat
#define __NR_osf_old_lstat 40
#define SYS_osf_old_lstat __NR_osf_old_lstat
#undef __NR_dup
#define __NR_dup 41
#define SYS_dup __NR_dup
#undef __NR_pipe
#define __NR_pipe 42
#define SYS_pipe __NR_pipe
#undef __NR_osf_set_program_attributes
#define __NR_osf_set_program_attributes 43
#define SYS_osf_set_program_attributes __NR_osf_set_program_attributes
#undef __NR_osf_profil
#define __NR_osf_profil 44
#define SYS_osf_profil __NR_osf_profil
#undef __NR_open
#define __NR_open 45
#define SYS_open __NR_open
#undef __NR_osf_old_sigaction
#define __NR_osf_old_sigaction 46
#define SYS_osf_old_sigaction __NR_osf_old_sigaction
#undef __NR_getxgid
#define __NR_getxgid 47
#define SYS_getxgid __NR_getxgid
#undef __NR_osf_sigprocmask
#define __NR_osf_sigprocmask 48
#define SYS_osf_sigprocmask __NR_osf_sigprocmask
#undef __NR_osf_getlogin
#define __NR_osf_getlogin 49
#define SYS_osf_getlogin __NR_osf_getlogin
#undef __NR_osf_setlogin
#define __NR_osf_setlogin 50
#define SYS_osf_setlogin __NR_osf_setlogin
#undef __NR_acct
#define __NR_acct 51
#define SYS_acct __NR_acct
#undef __NR_sigpending
#define __NR_sigpending 52
#define SYS_sigpending __NR_sigpending
#undef __NR_ioctl
#define __NR_ioctl 54
#define SYS_ioctl __NR_ioctl
#undef __NR_osf_reboot
#define __NR_osf_reboot 55
#define SYS_osf_reboot __NR_osf_reboot
#undef __NR_osf_revoke
#define __NR_osf_revoke 56
#define SYS_osf_revoke __NR_osf_revoke
#undef __NR_symlink
#define __NR_symlink 57
#define SYS_symlink __NR_symlink
#undef __NR_readlink
#define __NR_readlink 58
#define SYS_readlink __NR_readlink
#undef __NR_execve
#define __NR_execve 59
#define SYS_execve __NR_execve
#undef __NR_umask
#define __NR_umask 60
#define SYS_umask __NR_umask
#undef __NR_chroot
#define __NR_chroot 61
#define SYS_chroot __NR_chroot
#undef __NR_osf_old_fstat
#define __NR_osf_old_fstat 62
#define SYS_osf_old_fstat __NR_osf_old_fstat
#undef __NR_getpgrp
#define __NR_getpgrp 63
#define SYS_getpgrp __NR_getpgrp
#undef __NR_getpagesize
#define __NR_getpagesize 64
#define SYS_getpagesize __NR_getpagesize
#undef __NR_osf_mremap
#define __NR_osf_mremap 65
#define SYS_osf_mremap __NR_osf_mremap
#undef __NR_vfork
#define __NR_vfork 66
#define SYS_vfork __NR_vfork
#undef __NR_stat
#define __NR_stat 67
#define SYS_stat __NR_stat
#undef __NR_lstat
#define __NR_lstat 68
#define SYS_lstat __NR_lstat
#undef __NR_osf_sbrk
#define __NR_osf_sbrk 69
#define SYS_osf_sbrk __NR_osf_sbrk
#undef __NR_osf_sstk
#define __NR_osf_sstk 70
#define SYS_osf_sstk __NR_osf_sstk
#undef __NR_mmap
#define __NR_mmap 71
#define SYS_mmap __NR_mmap
#undef __NR_osf_old_vadvise
#define __NR_osf_old_vadvise 72
#define SYS_osf_old_vadvise __NR_osf_old_vadvise
#undef __NR_munmap
#define __NR_munmap 73
#define SYS_munmap __NR_munmap
#undef __NR_mprotect
#define __NR_mprotect 74
#define SYS_mprotect __NR_mprotect
#undef __NR_madvise
#define __NR_madvise 75
#define SYS_madvise __NR_madvise
#undef __NR_vhangup
#define __NR_vhangup 76
#define SYS_vhangup __NR_vhangup
#undef __NR_osf_kmodcall
#define __NR_osf_kmodcall 77
#define SYS_osf_kmodcall __NR_osf_kmodcall
#undef __NR_osf_mincore
#define __NR_osf_mincore 78
#define SYS_osf_mincore __NR_osf_mincore
#undef __NR_getgroups
#define __NR_getgroups 79
#define SYS_getgroups __NR_getgroups
#undef __NR_setgroups
#define __NR_setgroups 80
#define SYS_setgroups __NR_setgroups
#undef __NR_osf_old_getpgrp
#define __NR_osf_old_getpgrp 81
#define SYS_osf_old_getpgrp __NR_osf_old_getpgrp
#undef __NR_setpgrp
#define __NR_setpgrp 82
#define SYS_setpgrp __NR_setpgrp
#undef __NR_osf_setitimer
#define __NR_osf_setitimer 83
#define SYS_osf_setitimer __NR_osf_setitimer
#undef __NR_osf_old_wait
#define __NR_osf_old_wait 84
#define SYS_osf_old_wait __NR_osf_old_wait
#undef __NR_osf_table
#define __NR_osf_table 85
#define SYS_osf_table __NR_osf_table
#undef __NR_osf_getitimer
#define __NR_osf_getitimer 86
#define SYS_osf_getitimer __NR_osf_getitimer
#undef __NR_gethostname
#define __NR_gethostname 87
#define SYS_gethostname __NR_gethostname
#undef __NR_sethostname
#define __NR_sethostname 88
#define SYS_sethostname __NR_sethostname
#undef __NR_getdtablesize
#define __NR_getdtablesize 89
#define SYS_getdtablesize __NR_getdtablesize
#undef __NR_dup2
#define __NR_dup2 90
#define SYS_dup2 __NR_dup2
#undef __NR_fstat
#define __NR_fstat 91
#define SYS_fstat __NR_fstat
#undef __NR_fcntl
#define __NR_fcntl 92
#define SYS_fcntl __NR_fcntl
#undef __NR_osf_select
#define __NR_osf_select 93
#define SYS_osf_select __NR_osf_select
#undef __NR_poll
#define __NR_poll 94
#define SYS_poll __NR_poll
#undef __NR_fsync
#define __NR_fsync 95
#define SYS_fsync __NR_fsync
#undef __NR_setpriority
#define __NR_setpriority 96
#define SYS_setpriority __NR_setpriority
#undef __NR_socket
#define __NR_socket 97
#define SYS_socket __NR_socket
#undef __NR_connect
#define __NR_connect 98
#define SYS_connect __NR_connect
#undef __NR_accept
#define __NR_accept 99
#define SYS_accept __NR_accept
#undef __NR_getpriority
#define __NR_getpriority 100
#define SYS_getpriority __NR_getpriority
#undef __NR_send
#define __NR_send 101
#define SYS_send __NR_send
#undef __NR_recv
#define __NR_recv 102
#define SYS_recv __NR_recv
#undef __NR_sigreturn
#define __NR_sigreturn 103
#define SYS_sigreturn __NR_sigreturn
#undef __NR_bind
#define __NR_bind 104
#define SYS_bind __NR_bind
#undef __NR_setsockopt
#define __NR_setsockopt 105
#define SYS_setsockopt __NR_setsockopt
#undef __NR_listen
#define __NR_listen 106
#define SYS_listen __NR_listen
#undef __NR_osf_plock
#define __NR_osf_plock 107
#define SYS_osf_plock __NR_osf_plock
#undef __NR_osf_old_sigvec
#define __NR_osf_old_sigvec 108
#define SYS_osf_old_sigvec __NR_osf_old_sigvec
#undef __NR_osf_old_sigblock
#define __NR_osf_old_sigblock 109
#define SYS_osf_old_sigblock __NR_osf_old_sigblock
#undef __NR_osf_old_sigsetmask
#define __NR_osf_old_sigsetmask 110
#define SYS_osf_old_sigsetmask __NR_osf_old_sigsetmask
#undef __NR_sigsuspend
#define __NR_sigsuspend 111
#define SYS_sigsuspend __NR_sigsuspend
#undef __NR_osf_sigstack
#define __NR_osf_sigstack 112
#define SYS_osf_sigstack __NR_osf_sigstack
#undef __NR_recvmsg
#define __NR_recvmsg 113
#define SYS_recvmsg __NR_recvmsg
#undef __NR_sendmsg
#define __NR_sendmsg 114
#define SYS_sendmsg __NR_sendmsg
#undef __NR_osf_old_vtrace
#define __NR_osf_old_vtrace 115
#define SYS_osf_old_vtrace __NR_osf_old_vtrace
#undef __NR_osf_gettimeofday
#define __NR_osf_gettimeofday 116
#define SYS_osf_gettimeofday __NR_osf_gettimeofday
#undef __NR_osf_getrusage
#define __NR_osf_getrusage 117
#define SYS_osf_getrusage __NR_osf_getrusage
#undef __NR_getsockopt
#define __NR_getsockopt 118
#define SYS_getsockopt __NR_getsockopt
#undef __NR_readv
#define __NR_readv 120
#define SYS_readv __NR_readv
#undef __NR_writev
#define __NR_writev 121
#define SYS_writev __NR_writev
#undef __NR_osf_settimeofday
#define __NR_osf_settimeofday 122
#define SYS_osf_settimeofday __NR_osf_settimeofday
#undef __NR_fchown
#define __NR_fchown 123
#define SYS_fchown __NR_fchown
#undef __NR_fchmod
#define __NR_fchmod 124
#define SYS_fchmod __NR_fchmod
#undef __NR_recvfrom
#define __NR_recvfrom 125
#define SYS_recvfrom __NR_recvfrom
#undef __NR_setreuid
#define __NR_setreuid 126
#define SYS_setreuid __NR_setreuid
#undef __NR_setregid
#define __NR_setregid 127
#define SYS_setregid __NR_setregid
#undef __NR_rename
#define __NR_rename 128
#define SYS_rename __NR_rename
#undef __NR_truncate
#define __NR_truncate 129
#define SYS_truncate __NR_truncate
#undef __NR_ftruncate
#define __NR_ftruncate 130
#define SYS_ftruncate __NR_ftruncate
#undef __NR_flock
#define __NR_flock 131
#define SYS_flock __NR_flock
#undef __NR_setgid
#define __NR_setgid 132
#define SYS_setgid __NR_setgid
#undef __NR_sendto
#define __NR_sendto 133
#define SYS_sendto __NR_sendto
#undef __NR_shutdown
#define __NR_shutdown 134
#define SYS_shutdown __NR_shutdown
#undef __NR_socketpair
#define __NR_socketpair 135
#define SYS_socketpair __NR_socketpair
#undef __NR_mkdir
#define __NR_mkdir 136
#define SYS_mkdir __NR_mkdir
#undef __NR_rmdir
#define __NR_rmdir 137
#define SYS_rmdir __NR_rmdir
#undef __NR_osf_utimes
#define __NR_osf_utimes 138
#define SYS_osf_utimes __NR_osf_utimes
#undef __NR_osf_old_sigreturn
#define __NR_osf_old_sigreturn 139
#define SYS_osf_old_sigreturn __NR_osf_old_sigreturn
#undef __NR_osf_adjtime
#define __NR_osf_adjtime 140
#define SYS_osf_adjtime __NR_osf_adjtime
#undef __NR_getpeername
#define __NR_getpeername 141
#define SYS_getpeername __NR_getpeername
#undef __NR_osf_gethostid
#define __NR_osf_gethostid 142
#define SYS_osf_gethostid __NR_osf_gethostid
#undef __NR_osf_sethostid
#define __NR_osf_sethostid 143
#define SYS_osf_sethostid __NR_osf_sethostid
#undef __NR_getrlimit
#define __NR_getrlimit 144
#define SYS_getrlimit __NR_getrlimit
#undef __NR_setrlimit
#define __NR_setrlimit 145
#define SYS_setrlimit __NR_setrlimit
#undef __NR_osf_old_killpg
#define __NR_osf_old_killpg 146
#define SYS_osf_old_killpg __NR_osf_old_killpg
#undef __NR_setsid
#define __NR_setsid 147
#define SYS_setsid __NR_setsid
#undef __NR_quotactl
#define __NR_quotactl 148
#define SYS_quotactl __NR_quotactl
#undef __NR_osf_oldquota
#define __NR_osf_oldquota 149
#define SYS_osf_oldquota __NR_osf_oldquota
#undef __NR_getsockname
#define __NR_getsockname 150
#define SYS_getsockname __NR_getsockname
#undef __NR_osf_pid_block
#define __NR_osf_pid_block 153
#define SYS_osf_pid_block __NR_osf_pid_block
#undef __NR_osf_pid_unblock
#define __NR_osf_pid_unblock 154
#define SYS_osf_pid_unblock __NR_osf_pid_unblock
#undef __NR_sigaction
#define __NR_sigaction 156
#define SYS_sigaction __NR_sigaction
#undef __NR_osf_sigwaitprim
#define __NR_osf_sigwaitprim 157
#define SYS_osf_sigwaitprim __NR_osf_sigwaitprim
#undef __NR_osf_nfssvc
#define __NR_osf_nfssvc 158
#define SYS_osf_nfssvc __NR_osf_nfssvc
#undef __NR_osf_getdirentries
#define __NR_osf_getdirentries 159
#define SYS_osf_getdirentries __NR_osf_getdirentries
#undef __NR_osf_statfs
#define __NR_osf_statfs 160
#define SYS_osf_statfs __NR_osf_statfs
#undef __NR_osf_fstatfs
#define __NR_osf_fstatfs 161
#define SYS_osf_fstatfs __NR_osf_fstatfs
#undef __NR_osf_asynch_daemon
#define __NR_osf_asynch_daemon 163
#define SYS_osf_asynch_daemon __NR_osf_asynch_daemon
#undef __NR_osf_getfh
#define __NR_osf_getfh 164
#define SYS_osf_getfh __NR_osf_getfh
#undef __NR_osf_getdomainname
#define __NR_osf_getdomainname 165
#define SYS_osf_getdomainname __NR_osf_getdomainname
#undef __NR_setdomainname
#define __NR_setdomainname 166
#define SYS_setdomainname __NR_setdomainname
#undef __NR_osf_exportfs
#define __NR_osf_exportfs 169
#define SYS_osf_exportfs __NR_osf_exportfs
#undef __NR_osf_alt_plock
#define __NR_osf_alt_plock 181
#define SYS_osf_alt_plock __NR_osf_alt_plock
#undef __NR_osf_getmnt
#define __NR_osf_getmnt 184
#define SYS_osf_getmnt __NR_osf_getmnt
#undef __NR_osf_alt_sigpending
#define __NR_osf_alt_sigpending 187
#define SYS_osf_alt_sigpending __NR_osf_alt_sigpending
#undef __NR_osf_alt_setsid
#define __NR_osf_alt_setsid 188
#define SYS_osf_alt_setsid __NR_osf_alt_setsid
#undef __NR_osf_swapon
#define __NR_osf_swapon 199
#define SYS_osf_swapon __NR_osf_swapon
#undef __NR_msgctl
#define __NR_msgctl 200
#define SYS_msgctl __NR_msgctl
#undef __NR_msgget
#define __NR_msgget 201
#define SYS_msgget __NR_msgget
#undef __NR_msgrcv
#define __NR_msgrcv 202
#define SYS_msgrcv __NR_msgrcv
#undef __NR_msgsnd
#define __NR_msgsnd 203
#define SYS_msgsnd __NR_msgsnd
#undef __NR_semctl
#define __NR_semctl 204
#define SYS_semctl __NR_semctl
#undef __NR_semget
#define __NR_semget 205
#define SYS_semget __NR_semget
#undef __NR_semop
#define __NR_semop 206
#define SYS_semop __NR_semop
#undef __NR_osf_utsname
#define __NR_osf_utsname 207
#define SYS_osf_utsname __NR_osf_utsname
#undef __NR_lchown
#define __NR_lchown 208
#define SYS_lchown __NR_lchown
#undef __NR_shmat
#define __NR_shmat 209
#define SYS_shmat __NR_shmat
#undef __NR_shmctl
#define __NR_shmctl 210
#define SYS_shmctl __NR_shmctl
#undef __NR_shmdt
#define __NR_shmdt 211
#define SYS_shmdt __NR_shmdt
#undef __NR_shmget
#define __NR_shmget 212
#define SYS_shmget __NR_shmget
#undef __NR_osf_mvalid
#define __NR_osf_mvalid 213
#define SYS_osf_mvalid __NR_osf_mvalid
#undef __NR_osf_getaddressconf
#define __NR_osf_getaddressconf 214
#define SYS_osf_getaddressconf __NR_osf_getaddressconf
#undef __NR_osf_msleep
#define __NR_osf_msleep 215
#define SYS_osf_msleep __NR_osf_msleep
#undef __NR_osf_mwakeup
#define __NR_osf_mwakeup 216
#define SYS_osf_mwakeup __NR_osf_mwakeup
#undef __NR_msync
#define __NR_msync 217
#define SYS_msync __NR_msync
#undef __NR_osf_signal
#define __NR_osf_signal 218
#define SYS_osf_signal __NR_osf_signal
#undef __NR_osf_utc_gettime
#define __NR_osf_utc_gettime 219
#define SYS_osf_utc_gettime __NR_osf_utc_gettime
#undef __NR_osf_utc_adjtime
#define __NR_osf_utc_adjtime 220
#define SYS_osf_utc_adjtime __NR_osf_utc_adjtime
#undef __NR_osf_security
#define __NR_osf_security 222
#define SYS_osf_security __NR_osf_security
#undef __NR_osf_kloadcall
#define __NR_osf_kloadcall 223
#define SYS_osf_kloadcall __NR_osf_kloadcall
#undef __NR_osf_stat
#define __NR_osf_stat 224
#define SYS_osf_stat __NR_osf_stat
#undef __NR_osf_lstat
#define __NR_osf_lstat 225
#define SYS_osf_lstat __NR_osf_lstat
#undef __NR_osf_fstat
#define __NR_osf_fstat 226
#define SYS_osf_fstat __NR_osf_fstat
#undef __NR_osf_statfs64
#define __NR_osf_statfs64 227
#define SYS_osf_statfs64 __NR_osf_statfs64
#undef __NR_osf_fstatfs64
#define __NR_osf_fstatfs64 228
#define SYS_osf_fstatfs64 __NR_osf_fstatfs64
#undef __NR_getpgid
#define __NR_getpgid 233
#define SYS_getpgid __NR_getpgid
#undef __NR_getsid
#define __NR_getsid 234
#define SYS_getsid __NR_getsid
#undef __NR_sigaltstack
#define __NR_sigaltstack 235
#define SYS_sigaltstack __NR_sigaltstack
#undef __NR_osf_waitid
#define __NR_osf_waitid 236
#define SYS_osf_waitid __NR_osf_waitid
#undef __NR_osf_priocntlset
#define __NR_osf_priocntlset 237
#define SYS_osf_priocntlset __NR_osf_priocntlset
#undef __NR_osf_sigsendset
#define __NR_osf_sigsendset 238
#define SYS_osf_sigsendset __NR_osf_sigsendset
#undef __NR_osf_set_speculative
#define __NR_osf_set_speculative 239
#define SYS_osf_set_speculative __NR_osf_set_speculative
#undef __NR_osf_msfs_syscall
#define __NR_osf_msfs_syscall 240
#define SYS_osf_msfs_syscall __NR_osf_msfs_syscall
#undef __NR_osf_sysinfo
#define __NR_osf_sysinfo 241
#define SYS_osf_sysinfo __NR_osf_sysinfo
#undef __NR_osf_uadmin
#define __NR_osf_uadmin 242
#define SYS_osf_uadmin __NR_osf_uadmin
#undef __NR_osf_fuser
#define __NR_osf_fuser 243
#define SYS_osf_fuser __NR_osf_fuser
#undef __NR_osf_proplist_syscall
#define __NR_osf_proplist_syscall 244
#define SYS_osf_proplist_syscall __NR_osf_proplist_syscall
#undef __NR_osf_ntp_adjtime
#define __NR_osf_ntp_adjtime 245
#define SYS_osf_ntp_adjtime __NR_osf_ntp_adjtime
#undef __NR_osf_ntp_gettime
#define __NR_osf_ntp_gettime 246
#define SYS_osf_ntp_gettime __NR_osf_ntp_gettime
#undef __NR_osf_pathconf
#define __NR_osf_pathconf 247
#define SYS_osf_pathconf __NR_osf_pathconf
#undef __NR_osf_fpathconf
#define __NR_osf_fpathconf 248
#define SYS_osf_fpathconf __NR_osf_fpathconf
#undef __NR_osf_uswitch
#define __NR_osf_uswitch 250
#define SYS_osf_uswitch __NR_osf_uswitch
#undef __NR_osf_usleep_thread
#define __NR_osf_usleep_thread 251
#define SYS_osf_usleep_thread __NR_osf_usleep_thread
#undef __NR_osf_audcntl
#define __NR_osf_audcntl 252
#define SYS_osf_audcntl __NR_osf_audcntl
#undef __NR_osf_audgen
#define __NR_osf_audgen 253
#define SYS_osf_audgen __NR_osf_audgen
#undef __NR_sysfs
#define __NR_sysfs 254
#define SYS_sysfs __NR_sysfs
#undef __NR_osf_subsys_info
#define __NR_osf_subsys_info 255
#define SYS_osf_subsys_info __NR_osf_subsys_info
#undef __NR_osf_getsysinfo
#define __NR_osf_getsysinfo 256
#define SYS_osf_getsysinfo __NR_osf_getsysinfo
#undef __NR_osf_setsysinfo
#define __NR_osf_setsysinfo 257
#define SYS_osf_setsysinfo __NR_osf_setsysinfo
#undef __NR_osf_afs_syscall
#define __NR_osf_afs_syscall 258
#define SYS_osf_afs_syscall __NR_osf_afs_syscall
#undef __NR_osf_swapctl
#define __NR_osf_swapctl 259
#define SYS_osf_swapctl __NR_osf_swapctl
#undef __NR_osf_memcntl
#define __NR_osf_memcntl 260
#define SYS_osf_memcntl __NR_osf_memcntl
#undef __NR_osf_fdatasync
#define __NR_osf_fdatasync 261
#define SYS_osf_fdatasync __NR_osf_fdatasync
#undef __NR_bdflush
#define __NR_bdflush 300
#define SYS_bdflush __NR_bdflush
#undef __NR_sethae
#define __NR_sethae 301
#define SYS_sethae __NR_sethae
#undef __NR_mount
#define __NR_mount 302
#define SYS_mount __NR_mount
#undef __NR_old_adjtimex
#define __NR_old_adjtimex 303
#define SYS_old_adjtimex __NR_old_adjtimex
#undef __NR_swapoff
#define __NR_swapoff 304
#define SYS_swapoff __NR_swapoff
#undef __NR_getdents
#define __NR_getdents 305
#define SYS_getdents __NR_getdents
#undef __NR_create_module
#define __NR_create_module 306
#define SYS_create_module __NR_create_module
#undef __NR_init_module
#define __NR_init_module 307
#define SYS_init_module __NR_init_module
#undef __NR_delete_module
#define __NR_delete_module 308
#define SYS_delete_module __NR_delete_module
#undef __NR_get_kernel_syms
#define __NR_get_kernel_syms 309
#define SYS_get_kernel_syms __NR_get_kernel_syms
#undef __NR_syslog
#define __NR_syslog 310
#define SYS_syslog __NR_syslog
#undef __NR_reboot
#define __NR_reboot 311
#define SYS_reboot __NR_reboot
#undef __NR_clone
#define __NR_clone 312
#define SYS_clone __NR_clone
#undef __NR_uselib
#define __NR_uselib 313
#define SYS_uselib __NR_uselib
#undef __NR_mlock
#define __NR_mlock 314
#define SYS_mlock __NR_mlock
#undef __NR_munlock
#define __NR_munlock 315
#define SYS_munlock __NR_munlock
#undef __NR_mlockall
#define __NR_mlockall 316
#define SYS_mlockall __NR_mlockall
#undef __NR_munlockall
#define __NR_munlockall 317
#define SYS_munlockall __NR_munlockall
#undef __NR_sysinfo
#define __NR_sysinfo 318
#define SYS_sysinfo __NR_sysinfo
#undef __NR__sysctl
#define __NR__sysctl 319
#define SYS__sysctl __NR__sysctl
#undef __NR_oldumount
#define __NR_oldumount 321
#define SYS_oldumount __NR_oldumount
#undef __NR_swapon
#define __NR_swapon 322
#define SYS_swapon __NR_swapon
#undef __NR_times
#define __NR_times 323
#define SYS_times __NR_times
#undef __NR_personality
#define __NR_personality 324
#define SYS_personality __NR_personality
#undef __NR_setfsuid
#define __NR_setfsuid 325
#define SYS_setfsuid __NR_setfsuid
#undef __NR_setfsgid
#define __NR_setfsgid 326
#define SYS_setfsgid __NR_setfsgid
#undef __NR_ustat
#define __NR_ustat 327
#define SYS_ustat __NR_ustat
#undef __NR_statfs
#define __NR_statfs 328
#define SYS_statfs __NR_statfs
#undef __NR_fstatfs
#define __NR_fstatfs 329
#define SYS_fstatfs __NR_fstatfs
#undef __NR_sched_setparam
#define __NR_sched_setparam 330
#define SYS_sched_setparam __NR_sched_setparam
#undef __NR_sched_getparam
#define __NR_sched_getparam 331
#define SYS_sched_getparam __NR_sched_getparam
#undef __NR_sched_setscheduler
#define __NR_sched_setscheduler 332
#define SYS_sched_setscheduler __NR_sched_setscheduler
#undef __NR_sched_getscheduler
#define __NR_sched_getscheduler 333
#define SYS_sched_getscheduler __NR_sched_getscheduler
#undef __NR_sched_yield
#define __NR_sched_yield 334
#define SYS_sched_yield __NR_sched_yield
#undef __NR_sched_get_priority_max
#define __NR_sched_get_priority_max 335
#define SYS_sched_get_priority_max __NR_sched_get_priority_max
#undef __NR_sched_get_priority_min
#define __NR_sched_get_priority_min 336
#define SYS_sched_get_priority_min __NR_sched_get_priority_min
#undef __NR_sched_rr_get_interval
#define __NR_sched_rr_get_interval 337
#define SYS_sched_rr_get_interval __NR_sched_rr_get_interval
#undef __NR_afs_syscall
#define __NR_afs_syscall 338
#define SYS_afs_syscall __NR_afs_syscall
#undef __NR_uname
#define __NR_uname 339
#define SYS_uname __NR_uname
#undef __NR_nanosleep
#define __NR_nanosleep 340
#define SYS_nanosleep __NR_nanosleep
#undef __NR_mremap
#define __NR_mremap 341
#define SYS_mremap __NR_mremap
#undef __NR_nfsservctl
#define __NR_nfsservctl 342
#define SYS_nfsservctl __NR_nfsservctl
#undef __NR_setresuid
#define __NR_setresuid 343
#define SYS_setresuid __NR_setresuid
#undef __NR_getresuid
#define __NR_getresuid 344
#define SYS_getresuid __NR_getresuid
#undef __NR_pciconfig_read
#define __NR_pciconfig_read 345
#define SYS_pciconfig_read __NR_pciconfig_read
#undef __NR_pciconfig_write
#define __NR_pciconfig_write 346
#define SYS_pciconfig_write __NR_pciconfig_write
#undef __NR_query_module
#define __NR_query_module 347
#define SYS_query_module __NR_query_module
#undef __NR_prctl
#define __NR_prctl 348
#define SYS_prctl __NR_prctl
#undef __NR_pread64
#define __NR_pread64 349
#define SYS_pread64 __NR_pread64
#undef __NR_pwrite64
#define __NR_pwrite64 350
#define SYS_pwrite64 __NR_pwrite64
#undef __NR_rt_sigreturn
#define __NR_rt_sigreturn 351
#define SYS_rt_sigreturn __NR_rt_sigreturn
#undef __NR_rt_sigaction
#define __NR_rt_sigaction 352
#define SYS_rt_sigaction __NR_rt_sigaction
#undef __NR_rt_sigprocmask
#define __NR_rt_sigprocmask 353
#define SYS_rt_sigprocmask __NR_rt_sigprocmask
#undef __NR_rt_sigpending
#define __NR_rt_sigpending 354
#define SYS_rt_sigpending __NR_rt_sigpending
#undef __NR_rt_sigtimedwait
#define __NR_rt_sigtimedwait 355
#define SYS_rt_sigtimedwait __NR_rt_sigtimedwait
#undef __NR_rt_sigqueueinfo
#define __NR_rt_sigqueueinfo 356
#define SYS_rt_sigqueueinfo __NR_rt_sigqueueinfo
#undef __NR_rt_sigsuspend
#define __NR_rt_sigsuspend 357
#define SYS_rt_sigsuspend __NR_rt_sigsuspend
#undef __NR_select
#define __NR_select 358
#define SYS_select __NR_select
#undef __NR_gettimeofday
#define __NR_gettimeofday 359
#define SYS_gettimeofday __NR_gettimeofday
#undef __NR_settimeofday
#define __NR_settimeofday 360
#define SYS_settimeofday __NR_settimeofday
#undef __NR_getitimer
#define __NR_getitimer 361
#define SYS_getitimer __NR_getitimer
#undef __NR_setitimer
#define __NR_setitimer 362
#define SYS_setitimer __NR_setitimer
#undef __NR_utimes
#define __NR_utimes 363
#define SYS_utimes __NR_utimes
#undef __NR_getrusage
#define __NR_getrusage 364
#define SYS_getrusage __NR_getrusage
#undef __NR_wait4
#define __NR_wait4 365
#define SYS_wait4 __NR_wait4
#undef __NR_adjtimex
#define __NR_adjtimex 366
#define SYS_adjtimex __NR_adjtimex
#undef __NR_getcwd
#define __NR_getcwd 367
#define SYS_getcwd __NR_getcwd
#undef __NR_capget
#define __NR_capget 368
#define SYS_capget __NR_capget
#undef __NR_capset
#define __NR_capset 369
#define SYS_capset __NR_capset
#undef __NR_sendfile
#define __NR_sendfile 370
#define SYS_sendfile __NR_sendfile
#undef __NR_setresgid
#define __NR_setresgid 371
#define SYS_setresgid __NR_setresgid
#undef __NR_getresgid
#define __NR_getresgid 372
#define SYS_getresgid __NR_getresgid
#undef __NR_dipc
#define __NR_dipc 373
#define SYS_dipc __NR_dipc
#undef __NR_pivot_root
#define __NR_pivot_root 374
#define SYS_pivot_root __NR_pivot_root
#undef __NR_mincore
#define __NR_mincore 375
#define SYS_mincore __NR_mincore
#undef __NR_pciconfig_iobase
#define __NR_pciconfig_iobase 376
#define SYS_pciconfig_iobase __NR_pciconfig_iobase
#undef __NR_getdents64
#define __NR_getdents64 377
#define SYS_getdents64 __NR_getdents64
#undef __NR_gettid
#define __NR_gettid 378
#define SYS_gettid __NR_gettid
#undef __NR_readahead
#define __NR_readahead 379
#define SYS_readahead __NR_readahead
#undef __NR_tkill
#define __NR_tkill 381
#define SYS_tkill __NR_tkill
#undef __NR_setxattr
#define __NR_setxattr 382
#define SYS_setxattr __NR_setxattr
#undef __NR_lsetxattr
#define __NR_lsetxattr 383
#define SYS_lsetxattr __NR_lsetxattr
#undef __NR_fsetxattr
#define __NR_fsetxattr 384
#define SYS_fsetxattr __NR_fsetxattr
#undef __NR_getxattr
#define __NR_getxattr 385
#define SYS_getxattr __NR_getxattr
#undef __NR_lgetxattr
#define __NR_lgetxattr 386
#define SYS_lgetxattr __NR_lgetxattr
#undef __NR_fgetxattr
#define __NR_fgetxattr 387
#define SYS_fgetxattr __NR_fgetxattr
#undef __NR_listxattr
#define __NR_listxattr 388
#define SYS_listxattr __NR_listxattr
#undef __NR_llistxattr
#define __NR_llistxattr 389
#define SYS_llistxattr __NR_llistxattr
#undef __NR_flistxattr
#define __NR_flistxattr 390
#define SYS_flistxattr __NR_flistxattr
#undef __NR_removexattr
#define __NR_removexattr 391
#define SYS_removexattr __NR_removexattr
#undef __NR_lremovexattr
#define __NR_lremovexattr 392
#define SYS_lremovexattr __NR_lremovexattr
#undef __NR_fremovexattr
#define __NR_fremovexattr 393
#define SYS_fremovexattr __NR_fremovexattr
#undef __NR_futex
#define __NR_futex 394
#define SYS_futex __NR_futex
#undef __NR_sched_setaffinity
#define __NR_sched_setaffinity 395
#define SYS_sched_setaffinity __NR_sched_setaffinity
#undef __NR_sched_getaffinity
#define __NR_sched_getaffinity 396
#define SYS_sched_getaffinity __NR_sched_getaffinity
#undef __NR_tuxcall
#define __NR_tuxcall 397
#define SYS_tuxcall __NR_tuxcall
#undef __NR_io_setup
#define __NR_io_setup 398
#define SYS_io_setup __NR_io_setup
#undef __NR_io_destroy
#define __NR_io_destroy 399
#define SYS_io_destroy __NR_io_destroy
#undef __NR_io_getevents
#define __NR_io_getevents 400
#define SYS_io_getevents __NR_io_getevents
#undef __NR_io_submit
#define __NR_io_submit 401
#define SYS_io_submit __NR_io_submit
#undef __NR_io_cancel
#define __NR_io_cancel 402
#define SYS_io_cancel __NR_io_cancel
#undef __NR_exit_group
#define __NR_exit_group 405
#define SYS_exit_group __NR_exit_group
#undef __NR_lookup_dcookie
#define __NR_lookup_dcookie 406
#define SYS_lookup_dcookie __NR_lookup_dcookie
#undef __NR_epoll_create
#define __NR_epoll_create 407
#define SYS_epoll_create __NR_epoll_create
#undef __NR_epoll_ctl
#define __NR_epoll_ctl 408
#define SYS_epoll_ctl __NR_epoll_ctl
#undef __NR_epoll_wait
#define __NR_epoll_wait 409
#define SYS_epoll_wait __NR_epoll_wait
#undef __NR_remap_file_pages
#define __NR_remap_file_pages 410
#define SYS_remap_file_pages __NR_remap_file_pages
#undef __NR_set_tid_address
#define __NR_set_tid_address 411
#define SYS_set_tid_address __NR_set_tid_address
#undef __NR_restart_syscall
#define __NR_restart_syscall 412
#define SYS_restart_syscall __NR_restart_syscall
#undef __NR_fadvise64
#define __NR_fadvise64 413
#define SYS_fadvise64 __NR_fadvise64
#undef __NR_timer_create
#define __NR_timer_create 414
#define SYS_timer_create __NR_timer_create
#undef __NR_timer_settime
#define __NR_timer_settime 415
#define SYS_timer_settime __NR_timer_settime
#undef __NR_timer_gettime
#define __NR_timer_gettime 416
#define SYS_timer_gettime __NR_timer_gettime
#undef __NR_timer_getoverrun
#define __NR_timer_getoverrun 417
#define SYS_timer_getoverrun __NR_timer_getoverrun
#undef __NR_timer_delete
#define __NR_timer_delete 418
#define SYS_timer_delete __NR_timer_delete
#undef __NR_clock_settime
#define __NR_clock_settime 419
#define SYS_clock_settime __NR_clock_settime
#undef __NR_clock_gettime
#define __NR_clock_gettime 420
#define SYS_clock_gettime __NR_clock_gettime
#undef __NR_clock_getres
#define __NR_clock_getres 421
#define SYS_clock_getres __NR_clock_getres
#undef __NR_clock_nanosleep
#define __NR_clock_nanosleep 422
#define SYS_clock_nanosleep __NR_clock_nanosleep
#undef __NR_semtimedop
#define __NR_semtimedop 423
#define SYS_semtimedop __NR_semtimedop
#undef __NR_tgkill
#define __NR_tgkill 424
#define SYS_tgkill __NR_tgkill
#undef __NR_stat64
#define __NR_stat64 425
#define SYS_stat64 __NR_stat64
#undef __NR_lstat64
#define __NR_lstat64 426
#define SYS_lstat64 __NR_lstat64
#undef __NR_fstat64
#define __NR_fstat64 427
#define SYS_fstat64 __NR_fstat64
#undef __NR_vserver
#define __NR_vserver 428
#define SYS_vserver __NR_vserver
#undef __NR_mbind
#define __NR_mbind 429
#define SYS_mbind __NR_mbind
#undef __NR_get_mempolicy
#define __NR_get_mempolicy 430
#define SYS_get_mempolicy __NR_get_mempolicy
#undef __NR_set_mempolicy
#define __NR_set_mempolicy 431
#define SYS_set_mempolicy __NR_set_mempolicy
#undef __NR_mq_open
#define __NR_mq_open 432
#define SYS_mq_open __NR_mq_open
#undef __NR_mq_unlink
#define __NR_mq_unlink 433
#define SYS_mq_unlink __NR_mq_unlink
#undef __NR_mq_timedsend
#define __NR_mq_timedsend 434
#define SYS_mq_timedsend __NR_mq_timedsend
#undef __NR_mq_timedreceive
#define __NR_mq_timedreceive 435
#define SYS_mq_timedreceive __NR_mq_timedreceive
#undef __NR_mq_notify
#define __NR_mq_notify 436
#define SYS_mq_notify __NR_mq_notify
#undef __NR_mq_getsetattr
#define __NR_mq_getsetattr 437
#define SYS_mq_getsetattr __NR_mq_getsetattr
#undef __NR_waitid
#define __NR_waitid 438
#define SYS_waitid __NR_waitid
#undef __NR_add_key
#define __NR_add_key 439
#define SYS_add_key __NR_add_key
#undef __NR_request_key
#define __NR_request_key 440
#define SYS_request_key __NR_request_key
#undef __NR_keyctl
#define __NR_keyctl 441
#define SYS_keyctl __NR_keyctl
#undef __NR_ioprio_set
#define __NR_ioprio_set 442
#define SYS_ioprio_set __NR_ioprio_set
#undef __NR_ioprio_get
#define __NR_ioprio_get 443
#define SYS_ioprio_get __NR_ioprio_get
#undef __NR_inotify_init
#define __NR_inotify_init 444
#define SYS_inotify_init __NR_inotify_init
#undef __NR_inotify_add_watch
#define __NR_inotify_add_watch 445
#define SYS_inotify_add_watch __NR_inotify_add_watch
#undef __NR_inotify_rm_watch
#define __NR_inotify_rm_watch 446
#define SYS_inotify_rm_watch __NR_inotify_rm_watch
#undef __NR_fdatasync
#define __NR_fdatasync 447
#define SYS_fdatasync __NR_fdatasync
#undef __NR_kexec_load
#define __NR_kexec_load 448
#define SYS_kexec_load __NR_kexec_load
#undef __NR_migrate_pages
#define __NR_migrate_pages 449
#define SYS_migrate_pages __NR_migrate_pages
#undef __NR_openat
#define __NR_openat 450
#define SYS_openat __NR_openat
#undef __NR_mkdirat
#define __NR_mkdirat 451
#define SYS_mkdirat __NR_mkdirat
#undef __NR_mknodat
#define __NR_mknodat 452
#define SYS_mknodat __NR_mknodat
#undef __NR_fchownat
#define __NR_fchownat 453
#define SYS_fchownat __NR_fchownat
#undef __NR_futimesat
#define __NR_futimesat 454
#define SYS_futimesat __NR_futimesat
#undef __NR_fstatat64
#define __NR_fstatat64 455
#define SYS_fstatat64 __NR_fstatat64
#undef __NR_unlinkat
#define __NR_unlinkat 456
#define SYS_unlinkat __NR_unlinkat
#undef __NR_renameat
#define __NR_renameat 457
#define SYS_renameat __NR_renameat
#undef __NR_linkat
#define __NR_linkat 458
#define SYS_linkat __NR_linkat
#undef __NR_symlinkat
#define __NR_symlinkat 459
#define SYS_symlinkat __NR_symlinkat
#undef __NR_readlinkat
#define __NR_readlinkat 460
#define SYS_readlinkat __NR_readlinkat
#undef __NR_fchmodat
#define __NR_fchmodat 461
#define SYS_fchmodat __NR_fchmodat
#undef __NR_faccessat
#define __NR_faccessat 462
#define SYS_faccessat __NR_faccessat
#undef __NR_pselect6
#define __NR_pselect6 463
#define SYS_pselect6 __NR_pselect6
#undef __NR_ppoll
#define __NR_ppoll 464
#define SYS_ppoll __NR_ppoll
#undef __NR_unshare
#define __NR_unshare 465
#define SYS_unshare __NR_unshare
#undef __NR_set_robust_list
#define __NR_set_robust_list 466
#define SYS_set_robust_list __NR_set_robust_list
#undef __NR_get_robust_list
#define __NR_get_robust_list 467
#define SYS_get_robust_list __NR_get_robust_list
#undef __NR_splice
#define __NR_splice 468
#define SYS_splice __NR_splice
#undef __NR_sync_file_range
#define __NR_sync_file_range 469
#define SYS_sync_file_range __NR_sync_file_range
#undef __NR_tee
#define __NR_tee 470
#define SYS_tee __NR_tee
#undef __NR_vmsplice
#define __NR_vmsplice 471
#define SYS_vmsplice __NR_vmsplice
#undef __NR_move_pages
#define __NR_move_pages 472
#define SYS_move_pages __NR_move_pages
#undef __NR_getcpu
#define __NR_getcpu 473
#define SYS_getcpu __NR_getcpu
#undef __NR_epoll_pwait
#define __NR_epoll_pwait 474
#define SYS_epoll_pwait __NR_epoll_pwait
#undef __NR_utimensat
#define __NR_utimensat 475
#define SYS_utimensat __NR_utimensat
#undef __NR_signalfd
#define __NR_signalfd 476
#define SYS_signalfd __NR_signalfd
#undef __NR_timerfd
#define __NR_timerfd 477
#define SYS_timerfd __NR_timerfd
#undef __NR_eventfd
#define __NR_eventfd 478
#define SYS_eventfd __NR_eventfd
#undef __NR_recvmmsg
#define __NR_recvmmsg 479
#define SYS_recvmmsg __NR_recvmmsg
#undef __NR_fallocate
#define __NR_fallocate 480
#define SYS_fallocate __NR_fallocate
#undef __NR_timerfd_create
#define __NR_timerfd_create 481
#define SYS_timerfd_create __NR_timerfd_create
#undef __NR_timerfd_settime
#define __NR_timerfd_settime 482
#define SYS_timerfd_settime __NR_timerfd_settime
#undef __NR_timerfd_gettime
#define __NR_timerfd_gettime 483
#define SYS_timerfd_gettime __NR_timerfd_gettime
#undef __NR_signalfd4
#define __NR_signalfd4 484
#define SYS_signalfd4 __NR_signalfd4
#undef __NR_eventfd2
#define __NR_eventfd2 485
#define SYS_eventfd2 __NR_eventfd2
#undef __NR_epoll_create1
#define __NR_epoll_create1 486
#define SYS_epoll_create1 __NR_epoll_create1
#undef __NR_dup3
#define __NR_dup3 487
#define SYS_dup3 __NR_dup3
#undef __NR_pipe2
#define __NR_pipe2 488
#define SYS_pipe2 __NR_pipe2
#undef __NR_inotify_init1
#define __NR_inotify_init1 489
#define SYS_inotify_init1 __NR_inotify_init1
#undef __NR_preadv
#define __NR_preadv 490
#define SYS_preadv __NR_preadv
#undef __NR_pwritev
#define __NR_pwritev 491
#define SYS_pwritev __NR_pwritev
#undef __NR_rt_tgsigqueueinfo
#define __NR_rt_tgsigqueueinfo 492
#define SYS_rt_tgsigqueueinfo __NR_rt_tgsigqueueinfo
#undef __NR_perf_event_open
#define __NR_perf_event_open 493
#define SYS_perf_event_open __NR_perf_event_open
#undef __NR_fanotify_init
#define __NR_fanotify_init 494
#define SYS_fanotify_init __NR_fanotify_init
#undef __NR_fanotify_mark
#define __NR_fanotify_mark 495
#define SYS_fanotify_mark __NR_fanotify_mark
#undef __NR_prlimit64
#define __NR_prlimit64 496
#define SYS_prlimit64 __NR_prlimit64
#undef __NR_name_to_handle_at
#define __NR_name_to_handle_at 497
#define SYS_name_to_handle_at __NR_name_to_handle_at
#undef __NR_open_by_handle_at
#define __NR_open_by_handle_at 498
#define SYS_open_by_handle_at __NR_open_by_handle_at
#undef __NR_clock_adjtime
#define __NR_clock_adjtime 499
#define SYS_clock_adjtime __NR_clock_adjtime
#undef __NR_syncfs
#define __NR_syncfs 500
#define SYS_syncfs __NR_syncfs
#undef __NR_setns
#define __NR_setns 501
#define SYS_setns __NR_setns
#undef __NR_accept4
#define __NR_accept4 502
#define SYS_accept4 __NR_accept4
#undef __NR_sendmmsg
#define __NR_sendmmsg 503
#define SYS_sendmmsg __NR_sendmmsg
#undef __NR_process_vm_readv
#define __NR_process_vm_readv 504
#define SYS_process_vm_readv __NR_process_vm_readv
#undef __NR_process_vm_writev
#define __NR_process_vm_writev 505
#define SYS_process_vm_writev __NR_process_vm_writev
#undef __NR_kcmp
#define __NR_kcmp 506
#define SYS_kcmp __NR_kcmp
#undef __NR_finit_module
#define __NR_finit_module 507
#define SYS_finit_module __NR_finit_module
#undef __NR_sched_setattr
#define __NR_sched_setattr 508
#define SYS_sched_setattr __NR_sched_setattr
#undef __NR_sched_getattr
#define __NR_sched_getattr 509
#define SYS_sched_getattr __NR_sched_getattr
#undef __NR_renameat2
#define __NR_renameat2 510
#define SYS_renameat2 __NR_renameat2
#undef __NR_getrandom
#define __NR_getrandom 511
#define SYS_getrandom __NR_getrandom
#undef __NR_memfd_create
#define __NR_memfd_create 512
#define SYS_memfd_create __NR_memfd_create
#undef __NR_execveat
#define __NR_execveat 513
#define SYS_execveat __NR_execveat
#undef __NR_seccomp
#define __NR_seccomp 514
#define SYS_seccomp __NR_seccomp
#undef __NR_bpf
#define __NR_bpf 515
#define SYS_bpf __NR_bpf
#undef __NR_userfaultfd
#define __NR_userfaultfd 516
#define SYS_userfaultfd __NR_userfaultfd
#undef __NR_membarrier
#define __NR_membarrier 517
#define SYS_membarrier __NR_membarrier
#undef __NR_mlock2
#define __NR_mlock2 518
#define SYS_mlock2 __NR_mlock2
#undef __NR_copy_file_range
#define __NR_copy_file_range 519
#define SYS_copy_file_range __NR_copy_file_range
#undef __NR_preadv2
#define __NR_preadv2 520
#define SYS_preadv2 __NR_preadv2
#undef __NR_pwritev2
#define __NR_pwritev2 521
#define SYS_pwritev2 __NR_pwritev2
#undef __NR_statx
#define __NR_statx 522
#define SYS_statx __NR_statx
#undef __NR_io_pgetevents
#define __NR_io_pgetevents 523
#define SYS_io_pgetevents __NR_io_pgetevents
#undef __NR_pkey_mprotect
#define __NR_pkey_mprotect 524
#define SYS_pkey_mprotect __NR_pkey_mprotect
#undef __NR_pkey_alloc
#define __NR_pkey_alloc 525
#define SYS_pkey_alloc __NR_pkey_alloc
#undef __NR_pkey_free
#define __NR_pkey_free 526
#define SYS_pkey_free __NR_pkey_free
#undef __NR_rseq
#define __NR_rseq 527
#define SYS_rseq __NR_rseq
#undef __NR_statfs64
#define __NR_statfs64 528
#define SYS_statfs64 __NR_statfs64
#undef __NR_fstatfs64
#define __NR_fstatfs64 529
#define SYS_fstatfs64 __NR_fstatfs64
#undef __NR_getegid
#define __NR_getegid 530
#define SYS_getegid __NR_getegid
#undef __NR_geteuid
#define __NR_geteuid 531
#define SYS_geteuid __NR_geteuid
#undef __NR_getppid
#define __NR_getppid 532
#define SYS_getppid __NR_getppid
#undef __NR_pidfd_send_signal
#define __NR_pidfd_send_signal 534
#define SYS_pidfd_send_signal __NR_pidfd_send_signal
#undef __NR_io_uring_setup
#define __NR_io_uring_setup 535
#define SYS_io_uring_setup __NR_io_uring_setup
#undef __NR_io_uring_enter
#define __NR_io_uring_enter 536
#define SYS_io_uring_enter __NR_io_uring_enter
#undef __NR_io_uring_register
#define __NR_io_uring_register 537
#define SYS_io_uring_register __NR_io_uring_register
#undef __NR_open_tree
#define __NR_open_tree 538
#define SYS_open_tree __NR_open_tree
#undef __NR_move_mount
#define __NR_move_mount 539
#define SYS_move_mount __NR_move_mount
#undef __NR_fsopen
#define __NR_fsopen 540
#define SYS_fsopen __NR_fsopen
#undef __NR_fsconfig
#define __NR_fsconfig 541
#define SYS_fsconfig __NR_fsconfig
#undef __NR_fsmount
#define __NR_fsmount 542
#define SYS_fsmount __NR_fsmount
#undef __NR_fspick
#define __NR_fspick 543
#define SYS_fspick __NR_fspick
#undef __NR_pidfd_open
#define __NR_pidfd_open 544
#define SYS_pidfd_open __NR_pidfd_open
#undef __NR_close_range
#define __NR_close_range 546
#define SYS_close_range __NR_close_range
#undef __NR_openat2
#define __NR_openat2 547
#define SYS_openat2 __NR_openat2
#undef __NR_pidfd_getfd
#define __NR_pidfd_getfd 548
#define SYS_pidfd_getfd __NR_pidfd_getfd
#undef __NR_faccessat2
#define __NR_faccessat2 549
#define SYS_faccessat2 __NR_faccessat2
#undef __NR_process_madvise
#define __NR_process_madvise 550
#define SYS_process_madvise __NR_process_madvise
#undef __NR_epoll_pwait2
#define __NR_epoll_pwait2 551
#define SYS_epoll_pwait2 __NR_epoll_pwait2
#undef __NR_mount_setattr
#define __NR_mount_setattr 552
#define SYS_mount_setattr __NR_mount_setattr
#undef __NR_quotactl_fd
#define __NR_quotactl_fd 553
#define SYS_quotactl_fd __NR_quotactl_fd
#undef __NR_landlock_create_ruleset
#define __NR_landlock_create_ruleset 554
#define SYS_landlock_create_ruleset __NR_landlock_create_ruleset
#undef __NR_landlock_add_rule
#define __NR_landlock_add_rule 555
#define SYS_landlock_add_rule __NR_landlock_add_rule
#undef __NR_landlock_restrict_self
#define __NR_landlock_restrict_self 556
#define SYS_landlock_restrict_self __NR_landlock_restrict_self
#undef __NR_process_mrelease
#define __NR_process_mrelease 558
#define SYS_process_mrelease __NR_process_mrelease
#undef __NR_futex_waitv
#define __NR_futex_waitv 559
#define SYS_futex_waitv __NR_futex_waitv
#undef __NR_set_mempolicy_home_node
#define __NR_set_mempolicy_home_node 560
#define SYS_set_mempolicy_home_node __NR_set_mempolicy_home_node

#endif
