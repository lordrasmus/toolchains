/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_movhi 1
#define HAVE_movstricthi 1
#define HAVE_movqi 1
#define HAVE_movstrictqi 1
#define HAVE_movsf 1
#define HAVE_extendsidi2 1
#define HAVE_extendhidi2 1
#define HAVE_extendqidi2 1
#define HAVE_extendhisi2 1
#define HAVE_extendqisi2 1
#define HAVE_extendqihi2 1
#define HAVE_zero_extendhisi2 1
#define HAVE_zero_extendqisi2 1
#define HAVE_zero_extendqihi2 1
#define HAVE_addi_mul (operands[0] != frame_pointer_rtx \
   && operands[1] != frame_pointer_rtx \
   && CONST_INT_P (operands[2]) \
   && (INTVAL (operands[2]) == 2 \
       || INTVAL (operands[2]) == 4 || INTVAL (operands[2]) == 3 \
       || INTVAL (operands[2]) == 5))
#define HAVE_mstep_shift (!TARGET_V32)
#define HAVE_mstep_mul (!TARGET_V32 \
   && operands[0] != frame_pointer_rtx \
   && operands[1] != frame_pointer_rtx \
   && operands[2] != frame_pointer_rtx \
   && operands[3] != frame_pointer_rtx)
#define HAVE_mulhisi3 (TARGET_HAS_MUL_INSNS)
#define HAVE_umulhisi3 (TARGET_HAS_MUL_INSNS)
#define HAVE_mulqihi3 (TARGET_HAS_MUL_INSNS)
#define HAVE_umulqihi3 (TARGET_HAS_MUL_INSNS)
#define HAVE_mulsi3 (TARGET_HAS_MUL_INSNS)
#define HAVE_mulsidi3 (TARGET_HAS_MUL_INSNS)
#define HAVE_umulsidi3 (TARGET_HAS_MUL_INSNS)
#define HAVE_smulsi3_highpart (TARGET_HAS_MUL_INSNS)
#define HAVE_umulsi3_highpart (TARGET_HAS_MUL_INSNS)
#define HAVE_dstep_shift 1
#define HAVE_dstep_mul (operands[0] != frame_pointer_rtx \
   && operands[1] != frame_pointer_rtx \
   && operands[2] != frame_pointer_rtx \
   && operands[3] != frame_pointer_rtx)
#define HAVE_xorsi3 1
#define HAVE_xorhi3 1
#define HAVE_xorqi3 1
#define HAVE_negsi2 1
#define HAVE_neghi2 1
#define HAVE_negqi2 1
#define HAVE_one_cmplsi2 1
#define HAVE_one_cmplhi2 1
#define HAVE_one_cmplqi2 1
#define HAVE_ashrsi3 1
#define HAVE_lshrsi3 1
#define HAVE_ashlsi3 1
#define HAVE_ashlhi3 1
#define HAVE_ashlqi3 1
#define HAVE_abssf2 1
#define HAVE_abssi2 1
#define HAVE_clzsi2 (TARGET_HAS_LZ)
#define HAVE_bswapsi2 (TARGET_HAS_SWAP)
#define HAVE_cris_swap_bits (TARGET_HAS_SWAP)
#define HAVE_jump 1
#define HAVE_beq 1
#define HAVE_bne 1
#define HAVE_bgtu 1
#define HAVE_bltu 1
#define HAVE_bgeu 1
#define HAVE_bleu 1
#define HAVE_bgt 1
#define HAVE_ble 1
#define HAVE_blt 1
#define HAVE_bge 1
#define HAVE_seq 1
#define HAVE_sne 1
#define HAVE_sgtu 1
#define HAVE_sltu 1
#define HAVE_sgeu 1
#define HAVE_sleu 1
#define HAVE_slt 1
#define HAVE_sge 1
#define HAVE_sgt 1
#define HAVE_sle 1
#define HAVE_nop 1
#define HAVE_trap (TARGET_TRAP_USING_BREAK8)
#define HAVE_cris_frame_deallocated_barrier 1
#define HAVE_cris_atomic_fetch_addsi_1 (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_subsi_1 (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_orsi_1 (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_andsi_1 (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_xorsi_1 (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_nandsi_1 (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_addhi_1 (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_subhi_1 (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_orhi_1 (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_andhi_1 (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_xorhi_1 (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_nandhi_1 (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_fetch_addqi_1 1
#define HAVE_cris_atomic_fetch_subqi_1 1
#define HAVE_cris_atomic_fetch_orqi_1 1
#define HAVE_cris_atomic_fetch_andqi_1 1
#define HAVE_cris_atomic_fetch_xorqi_1 1
#define HAVE_cris_atomic_fetch_nandqi_1 1
#define HAVE_cris_atomic_compare_and_swapsi_1 (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_compare_and_swaphi_1 (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_cris_atomic_compare_and_swapqi_1 1
#define HAVE_movdi 1
#define HAVE_movsi 1
#define HAVE_reload_inhi 1
#define HAVE_reload_inqi 1
#define HAVE_reload_outhi 1
#define HAVE_reload_outqi 1
#define HAVE_load_multiple (TARGET_V32)
#define HAVE_store_multiple (TARGET_V32)
#define HAVE_adddi3 1
#define HAVE_addsi3 1
#define HAVE_addhi3 1
#define HAVE_addqi3 1
#define HAVE_subdi3 1
#define HAVE_subsi3 1
#define HAVE_subhi3 1
#define HAVE_subqi3 1
#define HAVE_andsi3 1
#define HAVE_andhi3 1
#define HAVE_andqi3 1
#define HAVE_iorsi3 1
#define HAVE_iorhi3 1
#define HAVE_iorqi3 1
#define HAVE_negsf2 1
#define HAVE_ashrhi3 1
#define HAVE_ashrqi3 1
#define HAVE_lshrhi3 1
#define HAVE_lshrqi3 1
#define HAVE_abshi2 1
#define HAVE_absqi2 1
#define HAVE_ctzsi2 (TARGET_HAS_LZ && TARGET_HAS_SWAP)
#define HAVE_uminsi3 1
#define HAVE_indirect_jump 1
#define HAVE_return (cris_simple_epilogue ())
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_cbranchsi4 1
#define HAVE_cbranchhi4 1
#define HAVE_cbranchqi4 1
#define HAVE_cbranchdi4 1
#define HAVE_cstoredi4 1
#define HAVE_cstoresi4 1
#define HAVE_cstorehi4 1
#define HAVE_cstoreqi4 1
#define HAVE_call 1
#define HAVE_call_value 1
#define HAVE_cris_casesi_non_v32 1
#define HAVE_cris_casesi_v32 (TARGET_V32)
#define HAVE_casesi 1
#define HAVE_atomic_fetch_addsi (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_subsi (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_orsi (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_andsi (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_xorsi (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_nandsi (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_addhi (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_subhi (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_orhi (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_andhi (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_xorhi (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_nandhi (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_fetch_addqi 1
#define HAVE_atomic_fetch_subqi 1
#define HAVE_atomic_fetch_orqi 1
#define HAVE_atomic_fetch_andqi 1
#define HAVE_atomic_fetch_xorqi 1
#define HAVE_atomic_fetch_nandqi 1
#define HAVE_atomic_compare_and_swapsi (SImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_compare_and_swaphi (HImode == QImode || !TARGET_ATOMICS_MAY_CALL_LIBFUNCS)
#define HAVE_atomic_compare_and_swapqi 1
extern rtx        gen_movhi                            (rtx, rtx);
extern rtx        gen_movstricthi                      (rtx, rtx);
extern rtx        gen_movqi                            (rtx, rtx);
extern rtx        gen_movstrictqi                      (rtx, rtx);
extern rtx        gen_movsf                            (rtx, rtx);
extern rtx        gen_extendsidi2                      (rtx, rtx);
extern rtx        gen_extendhidi2                      (rtx, rtx);
extern rtx        gen_extendqidi2                      (rtx, rtx);
extern rtx        gen_extendhisi2                      (rtx, rtx);
extern rtx        gen_extendqisi2                      (rtx, rtx);
extern rtx        gen_extendqihi2                      (rtx, rtx);
extern rtx        gen_zero_extendhisi2                 (rtx, rtx);
extern rtx        gen_zero_extendqisi2                 (rtx, rtx);
extern rtx        gen_zero_extendqihi2                 (rtx, rtx);
extern rtx        gen_addi_mul                         (rtx, rtx, rtx);
extern rtx        gen_mstep_shift                      (rtx, rtx, rtx, rtx);
extern rtx        gen_mstep_mul                        (rtx, rtx, rtx, rtx);
extern rtx        gen_mulhisi3                         (rtx, rtx, rtx);
extern rtx        gen_umulhisi3                        (rtx, rtx, rtx);
extern rtx        gen_mulqihi3                         (rtx, rtx, rtx);
extern rtx        gen_umulqihi3                        (rtx, rtx, rtx);
extern rtx        gen_mulsi3                           (rtx, rtx, rtx);
extern rtx        gen_mulsidi3                         (rtx, rtx, rtx);
extern rtx        gen_umulsidi3                        (rtx, rtx, rtx);
extern rtx        gen_smulsi3_highpart                 (rtx, rtx, rtx);
extern rtx        gen_umulsi3_highpart                 (rtx, rtx, rtx);
extern rtx        gen_dstep_shift                      (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_dstep_mul                        (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_xorsi3                           (rtx, rtx, rtx);
extern rtx        gen_xorhi3                           (rtx, rtx, rtx);
extern rtx        gen_xorqi3                           (rtx, rtx, rtx);
extern rtx        gen_negsi2                           (rtx, rtx);
extern rtx        gen_neghi2                           (rtx, rtx);
extern rtx        gen_negqi2                           (rtx, rtx);
extern rtx        gen_one_cmplsi2                      (rtx, rtx);
extern rtx        gen_one_cmplhi2                      (rtx, rtx);
extern rtx        gen_one_cmplqi2                      (rtx, rtx);
extern rtx        gen_ashrsi3                          (rtx, rtx, rtx);
extern rtx        gen_lshrsi3                          (rtx, rtx, rtx);
extern rtx        gen_ashlsi3                          (rtx, rtx, rtx);
extern rtx        gen_ashlhi3                          (rtx, rtx, rtx);
extern rtx        gen_ashlqi3                          (rtx, rtx, rtx);
extern rtx        gen_abssf2                           (rtx, rtx);
extern rtx        gen_abssi2                           (rtx, rtx);
extern rtx        gen_clzsi2                           (rtx, rtx);
extern rtx        gen_bswapsi2                         (rtx, rtx);
extern rtx        gen_cris_swap_bits                   (rtx, rtx);
extern rtx        gen_jump                             (rtx);
extern rtx        gen_beq                              (rtx);
extern rtx        gen_bne                              (rtx);
extern rtx        gen_bgtu                             (rtx);
extern rtx        gen_bltu                             (rtx);
extern rtx        gen_bgeu                             (rtx);
extern rtx        gen_bleu                             (rtx);
extern rtx        gen_bgt                              (rtx);
extern rtx        gen_ble                              (rtx);
extern rtx        gen_blt                              (rtx);
extern rtx        gen_bge                              (rtx);
extern rtx        gen_seq                              (rtx);
extern rtx        gen_sne                              (rtx);
extern rtx        gen_sgtu                             (rtx);
extern rtx        gen_sltu                             (rtx);
extern rtx        gen_sgeu                             (rtx);
extern rtx        gen_sleu                             (rtx);
extern rtx        gen_slt                              (rtx);
extern rtx        gen_sge                              (rtx);
extern rtx        gen_sgt                              (rtx);
extern rtx        gen_sle                              (rtx);
extern rtx        gen_nop                              (void);
extern rtx        gen_trap                             (void);
extern rtx        gen_cris_frame_deallocated_barrier   (void);
extern rtx        gen_cris_atomic_fetch_addsi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_subsi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_orsi_1         (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_andsi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_xorsi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_nandsi_1       (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_addhi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_subhi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_orhi_1         (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_andhi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_xorhi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_nandhi_1       (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_addqi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_subqi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_orqi_1         (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_andqi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_xorqi_1        (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_fetch_nandqi_1       (rtx, rtx, rtx);
extern rtx        gen_cris_atomic_compare_and_swapsi_1 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cris_atomic_compare_and_swaphi_1 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cris_atomic_compare_and_swapqi_1 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_movdi                            (rtx, rtx);
extern rtx        gen_movsi                            (rtx, rtx);
extern rtx        gen_reload_inhi                      (rtx, rtx, rtx);
extern rtx        gen_reload_inqi                      (rtx, rtx, rtx);
extern rtx        gen_reload_outhi                     (rtx, rtx, rtx);
extern rtx        gen_reload_outqi                     (rtx, rtx, rtx);
extern rtx        gen_load_multiple                    (rtx, rtx, rtx);
extern rtx        gen_store_multiple                   (rtx, rtx, rtx);
extern rtx        gen_adddi3                           (rtx, rtx, rtx);
extern rtx        gen_addsi3                           (rtx, rtx, rtx);
extern rtx        gen_addhi3                           (rtx, rtx, rtx);
extern rtx        gen_addqi3                           (rtx, rtx, rtx);
extern rtx        gen_subdi3                           (rtx, rtx, rtx);
extern rtx        gen_subsi3                           (rtx, rtx, rtx);
extern rtx        gen_subhi3                           (rtx, rtx, rtx);
extern rtx        gen_subqi3                           (rtx, rtx, rtx);
extern rtx        gen_andsi3                           (rtx, rtx, rtx);
extern rtx        gen_andhi3                           (rtx, rtx, rtx);
extern rtx        gen_andqi3                           (rtx, rtx, rtx);
extern rtx        gen_iorsi3                           (rtx, rtx, rtx);
extern rtx        gen_iorhi3                           (rtx, rtx, rtx);
extern rtx        gen_iorqi3                           (rtx, rtx, rtx);
extern rtx        gen_negsf2                           (rtx, rtx);
extern rtx        gen_ashrhi3                          (rtx, rtx, rtx);
extern rtx        gen_ashrqi3                          (rtx, rtx, rtx);
extern rtx        gen_lshrhi3                          (rtx, rtx, rtx);
extern rtx        gen_lshrqi3                          (rtx, rtx, rtx);
extern rtx        gen_abshi2                           (rtx, rtx);
extern rtx        gen_absqi2                           (rtx, rtx);
extern rtx        gen_ctzsi2                           (rtx, rtx);
extern rtx        gen_uminsi3                          (rtx, rtx, rtx);
extern rtx        gen_indirect_jump                    (rtx);
extern rtx        gen_return                           (void);
extern rtx        gen_prologue                         (void);
extern rtx        gen_epilogue                         (void);
extern rtx        gen_cbranchsi4                       (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchhi4                       (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchqi4                       (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdi4                       (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredi4                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresi4                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cstorehi4                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoreqi4                        (rtx, rtx, rtx, rtx);
extern rtx        gen_call                             (rtx, rtx);
extern rtx        gen_call_value                       (rtx, rtx, rtx);
extern rtx        gen_cris_casesi_non_v32              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cris_casesi_v32                  (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_casesi                           (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addsi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subsi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orsi                (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andsi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorsi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandsi              (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addhi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subhi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orhi                (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andhi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorhi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandhi              (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addqi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subqi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orqi                (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andqi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorqi               (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandqi              (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapsi        (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swaphi        (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapqi        (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
