/* Generated automatically by the program `genattr-common'
   from the machine description file `md'.  */

#ifndef GCC_INSN_ATTR_COMMON_H
#define GCC_INSN_ATTR_COMMON_H

enum attr_slottable {SLOTTABLE_NO, SLOTTABLE_YES, SLOTTABLE_HAS_SLOT, SLOTTABLE_HAS_RETURN_SLOT, SLOTTABLE_HAS_CALL_SLOT};
enum attr_cc {CC_NONE, CC_CLOBBER, CC_NORMAL, CC_NOOV32, CC_REV};
#define DELAY_SLOTS 1

#endif /* GCC_INSN_ATTR_COMMON_H */
