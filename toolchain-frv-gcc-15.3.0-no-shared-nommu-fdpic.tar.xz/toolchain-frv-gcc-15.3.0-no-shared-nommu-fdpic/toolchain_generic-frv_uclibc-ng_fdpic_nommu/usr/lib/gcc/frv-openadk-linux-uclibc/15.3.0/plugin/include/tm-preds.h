/* Generated automatically by the program 'build/genpreds'
   from the machine description file '/home/ramin/openadk-frv/toolchain_build_generic-frv_uclibc-ng_fdpic_nommu/w-gcc-15.3.0-1/gcc-15.3.0/gcc/config/frv/frv.md'.  */

#ifndef GCC_TM_PREDS_H
#define GCC_TM_PREDS_H

#ifdef HAVE_MACHINE_MODES
extern bool general_operand (rtx, machine_mode);
extern bool address_operand (rtx, machine_mode);
extern bool register_operand (rtx, machine_mode);
extern bool pmode_register_operand (rtx, machine_mode);
extern bool scratch_operand (rtx, machine_mode);
extern bool immediate_operand (rtx, machine_mode);
extern bool const_int_operand (rtx, machine_mode);
extern bool const_double_operand (rtx, machine_mode);
extern bool nonimmediate_operand (rtx, machine_mode);
extern bool nonmemory_operand (rtx, machine_mode);
extern bool push_operand (rtx, machine_mode);
extern bool pop_operand (rtx, machine_mode);
extern bool memory_operand (rtx, machine_mode);
extern bool indirect_operand (rtx, machine_mode);
extern bool ordered_comparison_operator (rtx, machine_mode);
extern bool comparison_operator (rtx, machine_mode);
extern bool aligned_register_operand (rtx, machine_mode);
extern bool integer_register_operand (rtx, machine_mode);
extern bool frv_load_operand (rtx, machine_mode);
extern bool gpr_no_subreg_operand (rtx, machine_mode);
extern bool gpr_or_fpr_operand (rtx, machine_mode);
extern bool gpr_or_int12_operand (rtx, machine_mode);
extern bool gpr_fpr_or_int12_operand (rtx, machine_mode);
extern bool gpr_or_int10_operand (rtx, machine_mode);
extern bool gpr_or_int_operand (rtx, machine_mode);
extern bool move_source_operand (rtx, machine_mode);
extern bool move_destination_operand (rtx, machine_mode);
extern bool movcc_fp_destination_operand (rtx, machine_mode);
extern bool condexec_source_operand (rtx, machine_mode);
extern bool condexec_dest_operand (rtx, machine_mode);
extern bool reg_or_0_operand (rtx, machine_mode);
extern bool lr_operand (rtx, machine_mode);
extern bool gpr_or_memory_operand (rtx, machine_mode);
extern bool gpr_or_memory_operand_with_scratch (rtx, machine_mode);
extern bool fpr_or_memory_operand (rtx, machine_mode);
extern bool int12_operand (rtx, machine_mode);
extern bool int_2word_operand (rtx, machine_mode);
extern bool fdpic_operand (rtx, machine_mode);
extern bool fdpic_fptr_operand (rtx, machine_mode);
extern bool ldd_address_operand (rtx, machine_mode);
extern bool got12_operand (rtx, machine_mode);
extern bool const_unspec_operand (rtx, machine_mode);
extern bool icc_operand (rtx, machine_mode);
extern bool fcc_operand (rtx, machine_mode);
extern bool cc_operand (rtx, machine_mode);
extern bool icr_operand (rtx, machine_mode);
extern bool fcr_operand (rtx, machine_mode);
extern bool cr_operand (rtx, machine_mode);
extern bool fpr_operand (rtx, machine_mode);
extern bool even_reg_operand (rtx, machine_mode);
extern bool odd_reg_operand (rtx, machine_mode);
extern bool even_gpr_operand (rtx, machine_mode);
extern bool odd_gpr_operand (rtx, machine_mode);
extern bool quad_fpr_operand (rtx, machine_mode);
extern bool even_fpr_operand (rtx, machine_mode);
extern bool odd_fpr_operand (rtx, machine_mode);
extern bool dbl_memory_one_insn_operand (rtx, machine_mode);
extern bool dbl_memory_two_insn_operand (rtx, machine_mode);
extern bool call_operand (rtx, machine_mode);
extern bool sibcall_operand (rtx, machine_mode);
extern bool upper_int16_operand (rtx, machine_mode);
extern bool uint16_operand (rtx, machine_mode);
extern bool symbolic_operand (rtx, machine_mode);
extern bool relational_operator (rtx, machine_mode);
extern bool integer_relational_operator (rtx, machine_mode);
extern bool float_relational_operator (rtx, machine_mode);
extern bool ccr_eqne_operator (rtx, machine_mode);
extern bool minmax_operator (rtx, machine_mode);
extern bool condexec_si_binary_operator (rtx, machine_mode);
extern bool condexec_si_media_operator (rtx, machine_mode);
extern bool condexec_si_divide_operator (rtx, machine_mode);
extern bool condexec_si_unary_operator (rtx, machine_mode);
extern bool condexec_sf_add_operator (rtx, machine_mode);
extern bool condexec_sf_conv_operator (rtx, machine_mode);
extern bool intop_compare_operator (rtx, machine_mode);
extern bool fpr_or_int6_operand (rtx, machine_mode);
extern bool int6_operand (rtx, machine_mode);
extern bool int5_operand (rtx, machine_mode);
extern bool uint5_operand (rtx, machine_mode);
extern bool uint4_operand (rtx, machine_mode);
extern bool uint1_operand (rtx, machine_mode);
extern bool acc_operand (rtx, machine_mode);
extern bool even_acc_operand (rtx, machine_mode);
extern bool quad_acc_operand (rtx, machine_mode);
extern bool accg_operand (rtx, machine_mode);
#endif /* HAVE_MACHINE_MODES */

#ifdef GCC_HARD_REG_SET_H
struct target_constraints {
  HARD_REG_SET register_filters[1];
};

extern struct target_constraints default_target_constraints;
#if SWITCHABLE_TARGET
extern struct target_constraints *this_target_constraints;
#else
#define this_target_constraints (&default_target_constraints)
#endif

#define TEST_REGISTER_FILTER_BIT(ID, REGNO) \
  ((void) (ID), (void) (REGNO), false)

inline bool
test_register_filters (unsigned int, unsigned int)
{
  return true;
}
#endif

#define CONSTRAINT_NUM_DEFINED_P 1
enum constraint_num
{
  CONSTRAINT__UNKNOWN = 0,
  CONSTRAINT_r,
  CONSTRAINT_a,
  CONSTRAINT_b,
  CONSTRAINT_c,
  CONSTRAINT_d,
  CONSTRAINT_e,
  CONSTRAINT_f,
  CONSTRAINT_h,
  CONSTRAINT_l,
  CONSTRAINT_q,
  CONSTRAINT_t,
  CONSTRAINT_u,
  CONSTRAINT_v,
  CONSTRAINT_w,
  CONSTRAINT_x,
  CONSTRAINT_y,
  CONSTRAINT_z,
  CONSTRAINT_A,
  CONSTRAINT_B,
  CONSTRAINT_C,
  CONSTRAINT_D89,
  CONSTRAINT_D09,
  CONSTRAINT_D08,
  CONSTRAINT_D14,
  CONSTRAINT_D15,
  CONSTRAINT_W,
  CONSTRAINT_Z,
  CONSTRAINT_I,
  CONSTRAINT_J,
  CONSTRAINT_K,
  CONSTRAINT_L,
  CONSTRAINT_M,
  CONSTRAINT_N,
  CONSTRAINT_O,
  CONSTRAINT_P,
  CONSTRAINT_m,
  CONSTRAINT_o,
  CONSTRAINT_R,
  CONSTRAINT_T,
  CONSTRAINT_U,
  CONSTRAINT_p,
  CONSTRAINT_G,
  CONSTRAINT_H,
  CONSTRAINT_V,
  CONSTRAINT__l,
  CONSTRAINT__g,
  CONSTRAINT_i,
  CONSTRAINT_s,
  CONSTRAINT__c,
  CONSTRAINT_n,
  CONSTRAINT_E,
  CONSTRAINT_F,
  CONSTRAINT_X,
  CONSTRAINT_Q,
  CONSTRAINT_S,
  CONSTRAINT__LIMIT
};

extern enum constraint_num lookup_constraint_1 (const char *);
extern const unsigned char lookup_constraint_array[];

/* Return the constraint at the beginning of P, or CONSTRAINT__UNKNOWN if it
   isn't recognized.  */

static inline enum constraint_num
lookup_constraint (const char *p)
{
  unsigned int index = lookup_constraint_array[(unsigned char) *p];
  return (index == UCHAR_MAX
          ? lookup_constraint_1 (p)
          : (enum constraint_num) index);
}

extern bool (*constraint_satisfied_p_array[]) (rtx);

/* Return true if X satisfies constraint C.  */

static inline bool
constraint_satisfied_p (rtx x, enum constraint_num c)
{
  int i = (int) c - (int) CONSTRAINT_I;
  return i >= 0 && constraint_satisfied_p_array[i] (x);
}

static inline bool
insn_extra_register_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_r && c <= CONSTRAINT_Z;
}

static inline bool
insn_extra_memory_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_m && c <= CONSTRAINT_U;
}

static inline bool
insn_extra_special_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_relaxed_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_address_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_p && c <= CONSTRAINT_p;
}

static inline void
insn_extra_constraint_allows_reg_mem (enum constraint_num c,
				      bool *allows_reg, bool *allows_mem)
{
  if (c >= CONSTRAINT_G && c <= CONSTRAINT_H)
    return;
  if (c >= CONSTRAINT_V && c <= CONSTRAINT__g)
    {
      *allows_mem = true;
      return;
    }
  (void) c;
  *allows_reg = true;
  *allows_mem = true;
}

static inline size_t
insn_constraint_len (char fc, const char *str ATTRIBUTE_UNUSED)
{
  switch (fc)
    {
    case 'D': return 3;
    default: break;
    }
  return 1;
}

#define CONSTRAINT_LEN(c_,s_) insn_constraint_len (c_,s_)

extern enum reg_class reg_class_for_constraint_1 (enum constraint_num);

static inline enum reg_class
reg_class_for_constraint (enum constraint_num c)
{
  if (insn_extra_register_constraint (c))
    return reg_class_for_constraint_1 (c);
  return NO_REGS;
}

extern bool insn_const_int_ok_for_constraint (HOST_WIDE_INT, enum constraint_num);
#define CONST_OK_FOR_CONSTRAINT_P(v_,c_,s_) \
    insn_const_int_ok_for_constraint (v_, lookup_constraint (s_))

enum constraint_type
{
  CT_REGISTER,
  CT_CONST_INT,
  CT_MEMORY,
  CT_SPECIAL_MEMORY,
  CT_RELAXED_MEMORY,
  CT_ADDRESS,
  CT_FIXED_FORM
};

static inline enum constraint_type
get_constraint_type (enum constraint_num c)
{
  if (c >= CONSTRAINT_p)
    {
      if (c >= CONSTRAINT_G)
        return CT_FIXED_FORM;
      return CT_ADDRESS;
    }
  if (c >= CONSTRAINT_m)
    return CT_MEMORY;
  if (c >= CONSTRAINT_I)
    return CT_CONST_INT;
  return CT_REGISTER;
}

#ifdef GCC_HARD_REG_SET_H
static inline const HARD_REG_SET *
get_register_filter (constraint_num)
{
  return nullptr;
}
#endif

static inline int
get_register_filter_id (constraint_num)
{
  return -1;
}
#endif /* tm-preds.h */
