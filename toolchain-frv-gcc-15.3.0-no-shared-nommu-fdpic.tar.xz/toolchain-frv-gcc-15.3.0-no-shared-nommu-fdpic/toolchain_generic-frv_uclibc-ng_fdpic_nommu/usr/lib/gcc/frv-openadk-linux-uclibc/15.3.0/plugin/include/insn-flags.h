/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_movhi_high 1
#define HAVE_movhi_lo_sum 1
#define HAVE_movsi_high 1
#define HAVE_movsi_lo_sum 1
#define HAVE_movsf_high 1
#define HAVE_movsf_lo_sum 1
#define HAVE_optional_membar_qi 1
#define HAVE_optional_membar_hi 1
#define HAVE_optional_membar_si 1
#define HAVE_optional_membar_di 1
#define HAVE_read_fcc (TARGET_HAS_FPRS)
#define HAVE_update_fcc (TARGET_HAS_FPRS)
#define HAVE_movcc_ccr 1
#define HAVE_extendqihi2 1
#define HAVE_extendqisi2 1
#define HAVE_extendhisi2 1
#define HAVE_zero_extendqihi2 1
#define HAVE_zero_extendqisi2 1
#define HAVE_zero_extendhisi2 1
#define HAVE_floatsisf2 (TARGET_HARD_FLOAT)
#define HAVE_floatsidf2 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_fix_truncsfsi2 (TARGET_HARD_FLOAT)
#define HAVE_fix_truncdfsi2 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_addsi3 1
#define HAVE_subsi3 1
#define HAVE_mulsidi3_const 1
#define HAVE_umulsidi3_const 1
#define HAVE_divsi3 1
#define HAVE_udivsi3 1
#define HAVE_negsi2 1
#define HAVE_adddi3 1
#define HAVE_subdi3 1
#define HAVE_adddi3_lower 1
#define HAVE_adddi3_upper 1
#define HAVE_subdi3_lower 1
#define HAVE_subdi3_upper 1
#define HAVE_negdi2 1
#define HAVE_addsf3 (TARGET_HARD_FLOAT)
#define HAVE_subsf3 (TARGET_HARD_FLOAT)
#define HAVE_mulsf3 (TARGET_HARD_FLOAT)
#define HAVE_fmasf4 (TARGET_HARD_FLOAT && TARGET_MULADD)
#define HAVE_fmssf4 (TARGET_HARD_FLOAT && TARGET_MULADD)
#define HAVE_divsf3 (TARGET_HARD_FLOAT)
#define HAVE_negsf2 (TARGET_HARD_FLOAT)
#define HAVE_abssf2 (TARGET_HARD_FLOAT)
#define HAVE_sqrtsf2 (TARGET_HARD_FLOAT)
#define HAVE_adddf3 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_subdf3 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_muldf3 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_divdf3 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_negdf2 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_absdf2 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_sqrtdf2 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_ashlsi3 1
#define HAVE_ashrsi3 1
#define HAVE_lshrsi3 1
#define HAVE_andsi3_media (TARGET_MEDIA)
#define HAVE_andsi3_nomedia (!TARGET_MEDIA)
#define HAVE_iorsi3_media (TARGET_MEDIA)
#define HAVE_iorsi3_nomedia (!TARGET_MEDIA)
#define HAVE_xorsi3_media (TARGET_MEDIA)
#define HAVE_xorsi3_nomedia (!TARGET_MEDIA)
#define HAVE_one_cmplsi2_media (TARGET_MEDIA)
#define HAVE_one_cmplsi2_nomedia (!TARGET_MEDIA)
#define HAVE_cmpsi_cc 1
#define HAVE_cond_exec_ck 1
#define HAVE_call_internal (! TARGET_FDPIC)
#define HAVE_movdi_ldd 1
#define HAVE_call_fdpicdi (TARGET_FDPIC)
#define HAVE_call_fdpicsi (TARGET_FDPIC)
#define HAVE_sibcall_internal (! TARGET_FDPIC)
#define HAVE_sibcall_fdpicdi (TARGET_FDPIC)
#define HAVE_call_value_internal (! TARGET_FDPIC)
#define HAVE_call_value_fdpicdi (TARGET_FDPIC)
#define HAVE_call_value_fdpicsi (TARGET_FDPIC)
#define HAVE_sibcall_value_internal (! TARGET_FDPIC)
#define HAVE_sibcall_value_fdpicdi (TARGET_FDPIC)
#define HAVE_stack_adjust 1
#define HAVE_jump 1
#define HAVE_indirect_jump 1
#define HAVE_tablejump_insn 1
#define HAVE_pic_prologue 1
#define HAVE_nop 1
#define HAVE_fnop 1
#define HAVE_mnop 1
#define HAVE_blockage 1
#define HAVE_mnot (TARGET_MEDIA)
#define HAVE_maveh (TARGET_MEDIA)
#define HAVE_mpackh (TARGET_MEDIA)
#define HAVE_munpackh (TARGET_MEDIA)
#define HAVE_mdpackh (TARGET_MEDIA)
#define HAVE_mbtoh (TARGET_MEDIA)
#define HAVE_mhtob (TARGET_MEDIA)
#define HAVE_mexpdhw (TARGET_MEDIA)
#define HAVE_mexpdhd (TARGET_MEDIA)
#define HAVE_mwcut (TARGET_MEDIA)
#define HAVE_mrdacc (TARGET_MEDIA)
#define HAVE_mrdaccg (TARGET_MEDIA)
#define HAVE_mwtacc (TARGET_MEDIA)
#define HAVE_mwtaccg (TARGET_MEDIA)
#define HAVE_mtrap (TARGET_MEDIA)
#define HAVE_mclracc_internal (TARGET_MEDIA)
#define HAVE_mclracca8_internal (TARGET_MEDIA && TARGET_ACC_8)
#define HAVE_mclracca4_internal (TARGET_MEDIA && TARGET_ACC_4)
#define HAVE_mcop1 (TARGET_MEDIA_REV1)
#define HAVE_mcop2 (TARGET_MEDIA_REV1)
#define HAVE_mdunpackh (TARGET_MEDIA_REV1)
#define HAVE_mbtohe (TARGET_MEDIA_REV1)
#define HAVE_masaccs (TARGET_MEDIA_REV2)
#define HAVE_mdasaccs (TARGET_MEDIA_REV2)
#define HAVE_mabshs (TARGET_MEDIA_REV2)
#define HAVE_mdrotli (TARGET_MEDIA_REV2)
#define HAVE_mcplhi (TARGET_MEDIA_REV2)
#define HAVE_mcpli (TARGET_MEDIA_REV2)
#define HAVE_mdcutssi (TARGET_MEDIA_REV2)
#define HAVE_mqsaths (TARGET_MEDIA_REV2)
#define HAVE_mqlclrhs (TARGET_MEDIA_FR450)
#define HAVE_mqlmths (TARGET_MEDIA_FR450)
#define HAVE_mqsllhi (TARGET_MEDIA_FR450)
#define HAVE_mqsrahi (TARGET_MEDIA_FR450)
#define HAVE_mhsetlos (TARGET_MEDIA_REV2)
#define HAVE_mhsetloh (TARGET_MEDIA_REV2)
#define HAVE_mhsethis (TARGET_MEDIA_REV2)
#define HAVE_mhsethih (TARGET_MEDIA_REV2)
#define HAVE_mhdsets (TARGET_MEDIA_REV2)
#define HAVE_mhdseth (TARGET_MEDIA_REV2)
#define HAVE_smul 1
#define HAVE_umul 1
#define HAVE_smass (TARGET_FR405_BUILTINS)
#define HAVE_smsss (TARGET_FR405_BUILTINS)
#define HAVE_smu (TARGET_FR405_BUILTINS)
#define HAVE_addss (TARGET_FR405_BUILTINS)
#define HAVE_subss (TARGET_FR405_BUILTINS)
#define HAVE_slass (TARGET_FR405_BUILTINS)
#define HAVE_scan 1
#define HAVE_scutss (TARGET_FR405_BUILTINS)
#define HAVE_frv_prefetch0 1
#define HAVE_frv_prefetch (TARGET_FR500_FR550_BUILTINS)
#define HAVE_tls_tlsdesc_ldd 1
#define HAVE_tls_tlsoff_ld 1
#define HAVE_tls_lddi 1
#define HAVE_movqi 1
#define HAVE_movhi 1
#define HAVE_movsi 1
#define HAVE_movdi 1
#define HAVE_movsf 1
#define HAVE_movdf 1
#define HAVE_cpymemsi 1
#define HAVE_setmemsi 1
#define HAVE_movcc 1
#define HAVE_movcc_uns 1
#define HAVE_movcc_nz 1
#define HAVE_movcc_fp (TARGET_HAS_FPRS)
#define HAVE_reload_incc_fp (TARGET_HAS_FPRS)
#define HAVE_reload_outcc_fp (TARGET_HAS_FPRS)
#define HAVE_reload_incc_ccr 1
#define HAVE_reload_outcc_ccr 1
#define HAVE_mulsidi3 1
#define HAVE_umulsidi3 1
#define HAVE_andsi3 1
#define HAVE_iorsi3 1
#define HAVE_xorsi3 1
#define HAVE_one_cmplsi2 1
#define HAVE_cbranchdf4 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_cbranchsf4 (TARGET_HARD_FLOAT)
#define HAVE_cbranchsi4 1
#define HAVE_cstoredf4 (TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_cstoresf4 (TARGET_HARD_FLOAT)
#define HAVE_cstoresi4 1
#define HAVE_andcr 1
#define HAVE_orcr 1
#define HAVE_xorcr 1
#define HAVE_nandcr 1
#define HAVE_norcr 1
#define HAVE_andncr 1
#define HAVE_orncr 1
#define HAVE_nandncr 1
#define HAVE_norncr 1
#define HAVE_notcr 1
#define HAVE_movqicc (TARGET_COND_MOVE)
#define HAVE_movhicc (TARGET_COND_MOVE)
#define HAVE_movsicc (TARGET_COND_MOVE)
#define HAVE_movsfcc (TARGET_COND_MOVE)
#define HAVE_abssi2 (TARGET_COND_MOVE)
#define HAVE_sminsi3 (TARGET_COND_MOVE)
#define HAVE_smaxsi3 (TARGET_COND_MOVE)
#define HAVE_uminsi3 (TARGET_COND_MOVE)
#define HAVE_umaxsi3 (TARGET_COND_MOVE)
#define HAVE_sminsf3 (TARGET_COND_MOVE && TARGET_HARD_FLOAT)
#define HAVE_smaxsf3 (TARGET_COND_MOVE && TARGET_HARD_FLOAT)
#define HAVE_smindf3 (TARGET_COND_MOVE && TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_smaxdf3 (TARGET_COND_MOVE && TARGET_HARD_FLOAT && TARGET_DOUBLE)
#define HAVE_call 1
#define HAVE_sibcall 1
#define HAVE_call_value 1
#define HAVE_sibcall_value 1
#define HAVE_return (direct_return_p ())
#define HAVE_epilogue_return 1
#define HAVE_tablejump (!flag_pic)
#define HAVE_casesi (flag_pic)
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_mand (TARGET_MEDIA)
#define HAVE_mor (TARGET_MEDIA)
#define HAVE_mxor (TARGET_MEDIA)
#define HAVE_msaths (TARGET_MEDIA)
#define HAVE_msathu (TARGET_MEDIA)
#define HAVE_maddhss (TARGET_MEDIA)
#define HAVE_maddhus (TARGET_MEDIA)
#define HAVE_msubhss (TARGET_MEDIA)
#define HAVE_msubhus (TARGET_MEDIA)
#define HAVE_mqaddhss (TARGET_MEDIA)
#define HAVE_mqaddhus (TARGET_MEDIA)
#define HAVE_mqsubhss (TARGET_MEDIA)
#define HAVE_mqsubhus (TARGET_MEDIA)
#define HAVE_mrotli (TARGET_MEDIA)
#define HAVE_mrotri (TARGET_MEDIA)
#define HAVE_msllhi (TARGET_MEDIA)
#define HAVE_msrlhi (TARGET_MEDIA)
#define HAVE_msrahi (TARGET_MEDIA)
#define HAVE_mmulhs (TARGET_MEDIA)
#define HAVE_mmulhu (TARGET_MEDIA)
#define HAVE_mmulxhs (TARGET_MEDIA)
#define HAVE_mmulxhu (TARGET_MEDIA)
#define HAVE_mmachs (TARGET_MEDIA)
#define HAVE_mmachu (TARGET_MEDIA)
#define HAVE_mmrdhs (TARGET_MEDIA)
#define HAVE_mmrdhu (TARGET_MEDIA)
#define HAVE_mqmulhs (TARGET_MEDIA)
#define HAVE_mqmulhu (TARGET_MEDIA)
#define HAVE_mqmulxhs (TARGET_MEDIA)
#define HAVE_mqmulxhu (TARGET_MEDIA)
#define HAVE_mqmachs (TARGET_MEDIA)
#define HAVE_mqmachu (TARGET_MEDIA)
#define HAVE_mcpxrs (TARGET_MEDIA)
#define HAVE_mcpxru (TARGET_MEDIA)
#define HAVE_mcpxis (TARGET_MEDIA)
#define HAVE_mcpxiu (TARGET_MEDIA)
#define HAVE_mqcpxrs (TARGET_MEDIA)
#define HAVE_mqcpxru (TARGET_MEDIA)
#define HAVE_mqcpxis (TARGET_MEDIA)
#define HAVE_mqcpxiu (TARGET_MEDIA)
#define HAVE_mcut (TARGET_MEDIA)
#define HAVE_mcutss (TARGET_MEDIA)
#define HAVE_mclracc (TARGET_MEDIA)
#define HAVE_mclracca8 (TARGET_MEDIA && TARGET_ACC_8)
#define HAVE_mclracca4 (TARGET_MEDIA && TARGET_ACC_4)
#define HAVE_mqxmachs (TARGET_MEDIA_REV2)
#define HAVE_mqxmacxhs (TARGET_MEDIA_REV2)
#define HAVE_mqmacxhs (TARGET_MEDIA_REV2)
#define HAVE_maddaccs (TARGET_MEDIA_REV2)
#define HAVE_msubaccs (TARGET_MEDIA_REV2)
#define HAVE_mdaddaccs (TARGET_MEDIA_REV2)
#define HAVE_mdsubaccs (TARGET_MEDIA_REV2)
#define HAVE_symGOT2reg 1
#define HAVE_symGOT2reg_i 1
#define HAVE_symGOT2reg_hilo 1
#define HAVE_symGOTOFF2reg_hilo 1
#define HAVE_symGOTOFF2reg 1
#define HAVE_symGOTOFF2reg_i 1
#define HAVE_symGPREL2reg 1
#define HAVE_symGPREL2reg_hilo 1
#define HAVE_tlsoff_hilo 1
extern rtx        gen_movhi_high             (rtx, rtx);
extern rtx        gen_movhi_lo_sum           (rtx, rtx);
extern rtx        gen_movsi_high             (rtx, rtx);
extern rtx        gen_movsi_lo_sum           (rtx, rtx);
extern rtx        gen_movsf_high             (rtx, rtx);
extern rtx        gen_movsf_lo_sum           (rtx, rtx);
extern rtx        gen_optional_membar_qi     (rtx, rtx, rtx);
extern rtx        gen_optional_membar_hi     (rtx, rtx, rtx);
extern rtx        gen_optional_membar_si     (rtx, rtx, rtx);
extern rtx        gen_optional_membar_di     (rtx, rtx, rtx);
extern rtx        gen_read_fcc               (rtx, rtx);
extern rtx        gen_update_fcc             (rtx, rtx, rtx, rtx);
extern rtx        gen_movcc_ccr              (rtx, rtx);
extern rtx        gen_extendqihi2            (rtx, rtx);
extern rtx        gen_extendqisi2            (rtx, rtx);
extern rtx        gen_extendhisi2            (rtx, rtx);
extern rtx        gen_zero_extendqihi2       (rtx, rtx);
extern rtx        gen_zero_extendqisi2       (rtx, rtx);
extern rtx        gen_zero_extendhisi2       (rtx, rtx);
extern rtx        gen_floatsisf2             (rtx, rtx);
extern rtx        gen_floatsidf2             (rtx, rtx);
extern rtx        gen_fix_truncsfsi2         (rtx, rtx);
extern rtx        gen_fix_truncdfsi2         (rtx, rtx);
extern rtx        gen_addsi3                 (rtx, rtx, rtx);
extern rtx        gen_subsi3                 (rtx, rtx, rtx);
extern rtx        gen_mulsidi3_const         (rtx, rtx, rtx);
extern rtx        gen_umulsidi3_const        (rtx, rtx, rtx);
extern rtx        gen_divsi3                 (rtx, rtx, rtx);
extern rtx        gen_udivsi3                (rtx, rtx, rtx);
extern rtx        gen_negsi2                 (rtx, rtx);
extern rtx        gen_adddi3                 (rtx, rtx, rtx);
extern rtx        gen_subdi3                 (rtx, rtx, rtx);
extern rtx        gen_adddi3_lower           (rtx, rtx, rtx, rtx);
extern rtx        gen_adddi3_upper           (rtx, rtx, rtx, rtx);
extern rtx        gen_subdi3_lower           (rtx, rtx, rtx, rtx);
extern rtx        gen_subdi3_upper           (rtx, rtx, rtx, rtx);
extern rtx        gen_negdi2                 (rtx, rtx);
extern rtx        gen_addsf3                 (rtx, rtx, rtx);
extern rtx        gen_subsf3                 (rtx, rtx, rtx);
extern rtx        gen_mulsf3                 (rtx, rtx, rtx);
extern rtx        gen_fmasf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_fmssf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_divsf3                 (rtx, rtx, rtx);
extern rtx        gen_negsf2                 (rtx, rtx);
extern rtx        gen_abssf2                 (rtx, rtx);
extern rtx        gen_sqrtsf2                (rtx, rtx);
extern rtx        gen_adddf3                 (rtx, rtx, rtx);
extern rtx        gen_subdf3                 (rtx, rtx, rtx);
extern rtx        gen_muldf3                 (rtx, rtx, rtx);
extern rtx        gen_divdf3                 (rtx, rtx, rtx);
extern rtx        gen_negdf2                 (rtx, rtx);
extern rtx        gen_absdf2                 (rtx, rtx);
extern rtx        gen_sqrtdf2                (rtx, rtx);
extern rtx        gen_ashlsi3                (rtx, rtx, rtx);
extern rtx        gen_ashrsi3                (rtx, rtx, rtx);
extern rtx        gen_lshrsi3                (rtx, rtx, rtx);
extern rtx        gen_andsi3_media           (rtx, rtx, rtx);
extern rtx        gen_andsi3_nomedia         (rtx, rtx, rtx);
extern rtx        gen_iorsi3_media           (rtx, rtx, rtx);
extern rtx        gen_iorsi3_nomedia         (rtx, rtx, rtx);
extern rtx        gen_xorsi3_media           (rtx, rtx, rtx);
extern rtx        gen_xorsi3_nomedia         (rtx, rtx, rtx);
extern rtx        gen_one_cmplsi2_media      (rtx, rtx);
extern rtx        gen_one_cmplsi2_nomedia    (rtx, rtx);
extern rtx        gen_cmpsi_cc               (rtx, rtx, rtx);
extern rtx        gen_cond_exec_ck           (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_call_internal          (rtx, rtx, rtx, rtx);
extern rtx        gen_movdi_ldd              (rtx, rtx);
extern rtx        gen_call_fdpicdi           (rtx, rtx, rtx);
extern rtx        gen_call_fdpicsi           (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_internal       (rtx, rtx, rtx);
extern rtx        gen_sibcall_fdpicdi        (rtx, rtx);
extern rtx        gen_call_value_internal    (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_call_value_fdpicdi     (rtx, rtx, rtx, rtx);
extern rtx        gen_call_value_fdpicsi     (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value_internal (rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value_fdpicdi  (rtx, rtx, rtx);
extern rtx        gen_stack_adjust           (rtx, rtx, rtx);
extern rtx        gen_jump                   (rtx);
extern rtx        gen_indirect_jump          (rtx);
extern rtx        gen_tablejump_insn         (rtx, rtx);
extern rtx        gen_pic_prologue           (rtx, rtx, rtx);
extern rtx        gen_nop                    (void);
extern rtx        gen_fnop                   (void);
extern rtx        gen_mnop                   (void);
extern rtx        gen_blockage               (void);
extern rtx        gen_mnot                   (rtx, rtx);
extern rtx        gen_maveh                  (rtx, rtx, rtx);
extern rtx        gen_mpackh                 (rtx, rtx, rtx);
extern rtx        gen_munpackh               (rtx, rtx);
extern rtx        gen_mdpackh                (rtx, rtx, rtx);
extern rtx        gen_mbtoh                  (rtx, rtx);
extern rtx        gen_mhtob                  (rtx, rtx);
extern rtx        gen_mexpdhw                (rtx, rtx, rtx);
extern rtx        gen_mexpdhd                (rtx, rtx, rtx);
extern rtx        gen_mwcut                  (rtx, rtx, rtx);
extern rtx        gen_mrdacc                 (rtx, rtx);
extern rtx        gen_mrdaccg                (rtx, rtx);
extern rtx        gen_mwtacc                 (rtx, rtx);
extern rtx        gen_mwtaccg                (rtx, rtx);
extern rtx        gen_mtrap                  (void);
extern rtx        gen_mclracc_internal       (rtx, rtx);
extern rtx        gen_mclracca8_internal     (rtx, rtx, rtx, rtx);
extern rtx        gen_mclracca4_internal     (rtx, rtx);
extern rtx        gen_mcop1                  (rtx, rtx, rtx);
extern rtx        gen_mcop2                  (rtx, rtx, rtx);
extern rtx        gen_mdunpackh              (rtx, rtx);
extern rtx        gen_mbtohe                 (rtx, rtx);
extern rtx        gen_masaccs                (rtx, rtx, rtx, rtx);
extern rtx        gen_mdasaccs               (rtx, rtx, rtx, rtx);
extern rtx        gen_mabshs                 (rtx, rtx);
extern rtx        gen_mdrotli                (rtx, rtx, rtx);
extern rtx        gen_mcplhi                 (rtx, rtx, rtx);
extern rtx        gen_mcpli                  (rtx, rtx, rtx);
extern rtx        gen_mdcutssi               (rtx, rtx, rtx, rtx);
extern rtx        gen_mqsaths                (rtx, rtx, rtx);
extern rtx        gen_mqlclrhs               (rtx, rtx, rtx);
extern rtx        gen_mqlmths                (rtx, rtx, rtx);
extern rtx        gen_mqsllhi                (rtx, rtx, rtx);
extern rtx        gen_mqsrahi                (rtx, rtx, rtx);
extern rtx        gen_mhsetlos               (rtx, rtx, rtx);
extern rtx        gen_mhsetloh               (rtx, rtx, rtx);
extern rtx        gen_mhsethis               (rtx, rtx, rtx);
extern rtx        gen_mhsethih               (rtx, rtx, rtx);
extern rtx        gen_mhdsets                (rtx, rtx);
extern rtx        gen_mhdseth                (rtx, rtx, rtx);
extern rtx        gen_smul                   (rtx, rtx, rtx);
extern rtx        gen_umul                   (rtx, rtx, rtx);
extern rtx        gen_smass                  (rtx, rtx);
extern rtx        gen_smsss                  (rtx, rtx);
extern rtx        gen_smu                    (rtx, rtx);
extern rtx        gen_addss                  (rtx, rtx, rtx);
extern rtx        gen_subss                  (rtx, rtx, rtx);
extern rtx        gen_slass                  (rtx, rtx, rtx);
extern rtx        gen_scan                   (rtx, rtx, rtx);
extern rtx        gen_scutss                 (rtx, rtx);
extern rtx        gen_frv_prefetch0          (rtx);
extern rtx        gen_frv_prefetch           (rtx);
static inline rtx gen_call_gettlsoff         (rtx, rtx, rtx);
static inline rtx
gen_call_gettlsoff(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_tls_load_gottlsoff12   (rtx, rtx, rtx);
static inline rtx
gen_tls_load_gottlsoff12(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_tls_tlsdesc_ldd        (rtx, rtx, rtx, rtx);
extern rtx        gen_tls_tlsoff_ld          (rtx, rtx, rtx, rtx);
extern rtx        gen_tls_lddi               (rtx, rtx, rtx);
extern rtx        gen_movqi                  (rtx, rtx);
extern rtx        gen_movhi                  (rtx, rtx);
extern rtx        gen_movsi                  (rtx, rtx);
extern rtx        gen_movdi                  (rtx, rtx);
extern rtx        gen_movsf                  (rtx, rtx);
extern rtx        gen_movdf                  (rtx, rtx);
extern rtx        gen_cpymemsi               (rtx, rtx, rtx, rtx);
extern rtx        gen_setmemsi               (rtx, rtx, rtx, rtx);
extern rtx        gen_movcc                  (rtx, rtx);
extern rtx        gen_movcc_uns              (rtx, rtx);
extern rtx        gen_movcc_nz               (rtx, rtx);
extern rtx        gen_movcc_fp               (rtx, rtx);
extern rtx        gen_reload_incc_fp         (rtx, rtx, rtx);
extern rtx        gen_reload_outcc_fp        (rtx, rtx, rtx);
extern rtx        gen_reload_incc_ccr        (rtx, rtx, rtx);
extern rtx        gen_reload_outcc_ccr       (rtx, rtx, rtx);
extern rtx        gen_mulsidi3               (rtx, rtx, rtx);
extern rtx        gen_umulsidi3              (rtx, rtx, rtx);
extern rtx        gen_andsi3                 (rtx, rtx, rtx);
extern rtx        gen_iorsi3                 (rtx, rtx, rtx);
extern rtx        gen_xorsi3                 (rtx, rtx, rtx);
extern rtx        gen_one_cmplsi2            (rtx, rtx);
extern rtx        gen_cbranchdf4             (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsf4             (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsi4             (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredf4              (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresf4              (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresi4              (rtx, rtx, rtx, rtx);
extern rtx        gen_andcr                  (rtx, rtx, rtx);
extern rtx        gen_orcr                   (rtx, rtx, rtx);
extern rtx        gen_xorcr                  (rtx, rtx, rtx);
extern rtx        gen_nandcr                 (rtx, rtx, rtx);
extern rtx        gen_norcr                  (rtx, rtx, rtx);
extern rtx        gen_andncr                 (rtx, rtx, rtx);
extern rtx        gen_orncr                  (rtx, rtx, rtx);
extern rtx        gen_nandncr                (rtx, rtx, rtx);
extern rtx        gen_norncr                 (rtx, rtx, rtx);
extern rtx        gen_notcr                  (rtx, rtx);
extern rtx        gen_movqicc                (rtx, rtx, rtx, rtx);
extern rtx        gen_movhicc                (rtx, rtx, rtx, rtx);
extern rtx        gen_movsicc                (rtx, rtx, rtx, rtx);
extern rtx        gen_movsfcc                (rtx, rtx, rtx, rtx);
extern rtx        gen_abssi2                 (rtx, rtx);
extern rtx        gen_sminsi3                (rtx, rtx, rtx);
extern rtx        gen_smaxsi3                (rtx, rtx, rtx);
extern rtx        gen_uminsi3                (rtx, rtx, rtx);
extern rtx        gen_umaxsi3                (rtx, rtx, rtx);
extern rtx        gen_sminsf3                (rtx, rtx, rtx);
extern rtx        gen_smaxsf3                (rtx, rtx, rtx);
extern rtx        gen_smindf3                (rtx, rtx, rtx);
extern rtx        gen_smaxdf3                (rtx, rtx, rtx);
extern rtx        gen_call                   (rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall                (rtx, rtx, rtx, rtx);
extern rtx        gen_call_value             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value          (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_return                 (void);
extern rtx        gen_epilogue_return        (rtx);
extern rtx        gen_tablejump              (rtx, rtx);
extern rtx        gen_casesi                 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_prologue               (void);
extern rtx        gen_epilogue               (void);
extern rtx        gen_sibcall_epilogue       (void);
extern rtx        gen_mand                   (rtx, rtx, rtx);
extern rtx        gen_mor                    (rtx, rtx, rtx);
extern rtx        gen_mxor                   (rtx, rtx, rtx);
extern rtx        gen_msaths                 (rtx, rtx, rtx);
extern rtx        gen_msathu                 (rtx, rtx, rtx);
extern rtx        gen_maddhss                (rtx, rtx, rtx);
extern rtx        gen_maddhus                (rtx, rtx, rtx);
extern rtx        gen_msubhss                (rtx, rtx, rtx);
extern rtx        gen_msubhus                (rtx, rtx, rtx);
extern rtx        gen_mqaddhss               (rtx, rtx, rtx);
extern rtx        gen_mqaddhus               (rtx, rtx, rtx);
extern rtx        gen_mqsubhss               (rtx, rtx, rtx);
extern rtx        gen_mqsubhus               (rtx, rtx, rtx);
extern rtx        gen_mrotli                 (rtx, rtx, rtx);
extern rtx        gen_mrotri                 (rtx, rtx, rtx);
extern rtx        gen_msllhi                 (rtx, rtx, rtx);
extern rtx        gen_msrlhi                 (rtx, rtx, rtx);
extern rtx        gen_msrahi                 (rtx, rtx, rtx);
extern rtx        gen_mmulhs                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mmulhu                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mmulxhs                (rtx, rtx, rtx, rtx);
extern rtx        gen_mmulxhu                (rtx, rtx, rtx, rtx);
extern rtx        gen_mmachs                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mmachu                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mmrdhs                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mmrdhu                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mqmulhs                (rtx, rtx, rtx, rtx);
extern rtx        gen_mqmulhu                (rtx, rtx, rtx, rtx);
extern rtx        gen_mqmulxhs               (rtx, rtx, rtx, rtx);
extern rtx        gen_mqmulxhu               (rtx, rtx, rtx, rtx);
extern rtx        gen_mqmachs                (rtx, rtx, rtx, rtx);
extern rtx        gen_mqmachu                (rtx, rtx, rtx, rtx);
extern rtx        gen_mcpxrs                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mcpxru                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mcpxis                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mcpxiu                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mqcpxrs                (rtx, rtx, rtx, rtx);
extern rtx        gen_mqcpxru                (rtx, rtx, rtx, rtx);
extern rtx        gen_mqcpxis                (rtx, rtx, rtx, rtx);
extern rtx        gen_mqcpxiu                (rtx, rtx, rtx, rtx);
extern rtx        gen_mcut                   (rtx, rtx, rtx, rtx);
extern rtx        gen_mcutss                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mclracc                (rtx);
extern rtx        gen_mclracca8              (void);
extern rtx        gen_mclracca4              (void);
extern rtx        gen_mqxmachs               (rtx, rtx, rtx, rtx);
extern rtx        gen_mqxmacxhs              (rtx, rtx, rtx, rtx);
extern rtx        gen_mqmacxhs               (rtx, rtx, rtx, rtx);
extern rtx        gen_maddaccs               (rtx, rtx, rtx, rtx);
extern rtx        gen_msubaccs               (rtx, rtx, rtx, rtx);
extern rtx        gen_mdaddaccs              (rtx, rtx, rtx, rtx);
extern rtx        gen_mdsubaccs              (rtx, rtx, rtx, rtx);
extern rtx        gen_symGOT2reg             (rtx, rtx, rtx, rtx);
extern rtx        gen_symGOT2reg_i           (rtx, rtx, rtx, rtx);
extern rtx        gen_symGOT2reg_hilo        (rtx, rtx, rtx, rtx);
extern rtx        gen_symGOTOFF2reg_hilo     (rtx, rtx, rtx, rtx);
extern rtx        gen_symGOTOFF2reg          (rtx, rtx, rtx, rtx);
extern rtx        gen_symGOTOFF2reg_i        (rtx, rtx, rtx, rtx);
extern rtx        gen_symGPREL2reg           (rtx, rtx, rtx, rtx);
extern rtx        gen_symGPREL2reg_hilo      (rtx, rtx, rtx, rtx);
static inline rtx gen_tls_indirect_call      (rtx, rtx, rtx, rtx);
static inline rtx
gen_tls_indirect_call(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_tlsoff_hilo            (rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
