/* Generated automatically by the program `genconstants'
   from the machine description file `md'.  */

#ifndef GCC_INSN_CONSTANTS_H
#define GCC_INSN_CONSTANTS_H

#define REG_FRAME 64
#define REG_A20 20
#define REG_A21 21
#define REG_A22 22
#define REG_A23 23
#define REG_B1 33
#define REG_B2 34
#define REG_A26 26
#define REG_A27 27
#define REG_A28 28
#define REG_A29 29
#define REG_A4 4
#define REG_B0 32
#define REG_A5 5
#define REG_A6 6
#define REG_B3 35
#define REG_A8 8
#define REG_B4 36
#define REG_B5 37
#define REG_B6 38
#define REG_B7 39
#define REG_B8 40
#define REG_B9 41
#define REG_SP 47
#define REG_ARGP 65
#define REG_B30 62
#define REG_A30 30
#define REG_A24 24
#define REG_A31 31
#define REG_A25 25
#define REG_B24 56
#define REG_B25 57
#define REG_B26 58
#define REG_B27 59
#define REG_B28 60
#define REG_B29 61
#define REG_A10 10
#define REG_A11 11
#define REG_A12 12
#define REG_A13 13
#define REG_A14 14
#define REG_A15 15
#define REG_A16 16
#define REG_A17 17
#define REG_A18 18
#define REG_A19 19
#define REG_A7 7
#define REG_A1 1
#define REG_A9 9
#define REG_A0 0
#define REG_A2 2
#define REG_B23 55
#define REG_A3 3
#define REG_B31 63
#define REG_ILC 66
#define REG_B20 52
#define REG_B21 53
#define REG_B22 54
#define REG_B10 42
#define REG_B11 43
#define REG_B12 44
#define REG_B13 45
#define REG_B14 46
#define REG_B15 47
#define REG_B16 48
#define REG_B17 49
#define REG_B18 50
#define REG_B19 51

enum unspec {
  UNSPEC_NOP = 0,
  UNSPEC_RCP = 1,
  UNSPEC_MISALIGNED_ACCESS = 2,
  UNSPEC_ADDKPC = 3,
  UNSPEC_SETUP_DSBT = 4,
  UNSPEC_LOAD_GOT = 5,
  UNSPEC_LOAD_SDATA = 6,
  UNSPEC_BITREV = 7,
  UNSPEC_GOTOFF = 8,
  UNSPEC_MVILC = 9,
  UNSPEC_REAL_JUMP = 10,
  UNSPEC_REAL_LOAD = 11,
  UNSPEC_REAL_MULT = 12,
  UNSPEC_JUMP_SHADOW = 13,
  UNSPEC_LOAD_SHADOW = 14,
  UNSPEC_MULT_SHADOW = 15,
  UNSPEC_EPILOGUE_BARRIER = 16,
  UNSPEC_ATOMIC = 17,
  UNSPEC_CLR = 18,
  UNSPEC_EXT = 19,
  UNSPEC_EXTU = 20,
  UNSPEC_SUBC = 21,
  UNSPEC_AVG = 22
};
#define NUM_UNSPEC_VALUES 23
extern const char *const unspec_strings[];

enum unspecv {
  UNSPECV_BLOCKAGE = 0,
  UNSPECV_SPLOOP = 1,
  UNSPECV_SPKERNEL = 2,
  UNSPECV_EH_RETURN = 3,
  UNSPECV_CAS = 4
};
#define NUM_UNSPECV_VALUES 5
extern const char *const unspecv_strings[];

#endif /* GCC_INSN_CONSTANTS_H */
