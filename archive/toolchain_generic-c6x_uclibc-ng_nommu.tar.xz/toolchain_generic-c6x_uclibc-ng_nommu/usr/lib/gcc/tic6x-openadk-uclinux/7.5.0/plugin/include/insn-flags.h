/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_nop 1
#define HAVE_nop_count 1
#define HAVE_movsi_lo_sum (reload_completed)
#define HAVE_movsi_high (reload_completed)
#define HAVE_movsi_gotoff_lo_sum (flag_pic == 2)
#define HAVE_movsi_gotoff_high (flag_pic == 2)
#define HAVE_load_got_gotoff (flag_pic == 2)
#define HAVE_load_sdata_pic (flag_pic)
#define HAVE_movqi_insn (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) == REG)
#define HAVE_movhi_insn (GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) == REG)
#define HAVE_movsi_insn ((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) == REG \
    || (GET_CODE (operands[1]) == SUBREG && REG_P (SUBREG_REG (operands[1])))))
#define HAVE_movsf_insn ((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) == REG \
    || (GET_CODE (operands[1]) == SUBREG && REG_P (SUBREG_REG (operands[1])))))
#define HAVE_movv2hi_insn ((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) == REG \
    || (GET_CODE (operands[1]) == SUBREG && REG_P (SUBREG_REG (operands[1])))))
#define HAVE_movv4qi_insn ((GET_CODE (operands[0]) != MEM || GET_CODE (operands[1]) == REG \
    || (GET_CODE (operands[1]) == SUBREG && REG_P (SUBREG_REG (operands[1])))))
#define HAVE_real_loadqi 1
#define HAVE_real_loadhi 1
#define HAVE_real_loadsi 1
#define HAVE_real_loadsf 1
#define HAVE_real_loadv2hi 1
#define HAVE_real_loadv4qi 1
#define HAVE_real_loaddi (TARGET_LDDW)
#define HAVE_real_loaddf (TARGET_LDDW)
#define HAVE_real_loadv2si (TARGET_LDDW)
#define HAVE_real_loadv4hi (TARGET_LDDW)
#define HAVE_real_loadv8qi (TARGET_LDDW)
#define HAVE_load_shadow 1
#define HAVE_mult_shadow 1
#define HAVE_movmisalignsi_store (TARGET_INSNS_64)
#define HAVE_movmisaligndi_store (TARGET_INSNS_64)
#define HAVE_movmisalignv2hi_store (TARGET_INSNS_64)
#define HAVE_movmisalignv4qi_store (TARGET_INSNS_64)
#define HAVE_movmisalignsi_load (TARGET_INSNS_64)
#define HAVE_movmisaligndi_load (TARGET_INSNS_64)
#define HAVE_movmisalignv2hi_load (TARGET_INSNS_64)
#define HAVE_movmisalignv4qi_load (TARGET_INSNS_64)
#define HAVE_zero_extendqisi2 1
#define HAVE_sign_extendqisi2 1
#define HAVE_zero_extendhisi2 1
#define HAVE_sign_extendhisi2 1
#define HAVE_real_zero_extendqi 1
#define HAVE_real_sign_extendqi 1
#define HAVE_real_zero_extendhi 1
#define HAVE_real_sign_extendhi 1
#define HAVE_clrr 1
#define HAVE_extr 1
#define HAVE_extru 1
#define HAVE_scmpsi_insn 1
#define HAVE_indirect_jump 1
#define HAVE_jump 1
#define HAVE_casesi_internal (flag_pic && TARGET_INSNS_64)
#define HAVE_br_true 1
#define HAVE_br_false 1
#define HAVE_eh_return 1
#define HAVE_mvilc (TARGET_INSNS_64PLUS)
#define HAVE_sploop (TARGET_INSNS_64PLUS)
#define HAVE_spkernel (TARGET_INSNS_64PLUS)
#define HAVE_loop_end (TARGET_INSNS_64PLUS && optimize)
#define HAVE_real_jump 1
#define HAVE_real_call 1
#define HAVE_real_ret 1
#define HAVE_indirect_jump_shadow 1
#define HAVE_indirect_call_value_shadow 1
#define HAVE_indirect_sibcall_shadow (SIBLING_CALL_P (insn))
#define HAVE_indirect_call_shadow 1
#define HAVE_call_value_shadow 1
#define HAVE_call_shadow (!SIBLING_CALL_P (insn))
#define HAVE_sibcall_shadow (SIBLING_CALL_P (insn))
#define HAVE_jump_shadow 1
#define HAVE_condjump_shadow 1
#define HAVE_return_shadow 1
#define HAVE_addsi3 1
#define HAVE_subsi3 1
#define HAVE_addsidi3_widen 1
#define HAVE_addsf3 (TARGET_FP)
#define HAVE_adddf3 (TARGET_FP)
#define HAVE_subsf3 (TARGET_FP)
#define HAVE_subdf3 (TARGET_FP)
#define HAVE_andsi3 1
#define HAVE_iorsi3 1
#define HAVE_xorsi3 1
#define HAVE_extendsfdf2 (TARGET_FP)
#define HAVE_truncdfsf2 (TARGET_FP)
#define HAVE_floatsisf2 (TARGET_FP)
#define HAVE_floatunssisf2 (TARGET_FP)
#define HAVE_floatsidf2 (TARGET_FP)
#define HAVE_floatunssidf2 (TARGET_FP)
#define HAVE_fix_truncsfsi2 (TARGET_FP)
#define HAVE_fix_truncdfsi2 (TARGET_FP)
#define HAVE_saddsi3 1
#define HAVE_ssubsi3 1
#define HAVE_subcsi3 1
#define HAVE_call_internal (!SIBLING_CALL_P (insn))
#define HAVE_call_value_internal 1
#define HAVE_sibcall_internal (SIBLING_CALL_P (insn))
#define HAVE_callp (!SIBLING_CALL_P (insn))
#define HAVE_callp_value (!SIBLING_CALL_P (insn))
#define HAVE_return_internal (reload_completed)
#define HAVE_addkpc (TARGET_INSNS_64)
#define HAVE_negsi2 1
#define HAVE_one_cmplsi2 1
#define HAVE_clrsbsi2 1
#define HAVE_clzsi2 1
#define HAVE_ssabssi2 1
#define HAVE_ss_ashlsi3 1
#define HAVE_ashlsi3 1
#define HAVE_ashrsi3 1
#define HAVE_lshrsi3 1
#define HAVE_rotrdi3_16 (TARGET_INSNS_64PLUS)
#define HAVE_shlmbsi3 (TARGET_INSNS_64)
#define HAVE_bswapv2hi2 (TARGET_INSNS_64)
#define HAVE_divsi3_insn 1
#define HAVE_divsi3_insn_indcall 1
#define HAVE_udivsi3_insn 1
#define HAVE_udivsi3_insn_indcall 1
#define HAVE_modsi3_insn 1
#define HAVE_modsi3_insn_indcall 1
#define HAVE_divmodsi4_insn 1
#define HAVE_divmodsi4_insn_indcall 1
#define HAVE_umodsi3_insn 1
#define HAVE_umodsi3_insn_indcall 1
#define HAVE_udivmodsi4_insn 1
#define HAVE_udivmodsi4_insn_indcall 1
#define HAVE_divmodsi4 1
#define HAVE_udivmodsi4 1
#define HAVE_mulsf3 (TARGET_FP)
#define HAVE_muldf3 (TARGET_FP)
#define HAVE_rcpsf2 (TARGET_FP)
#define HAVE_rcpdf2 (TARGET_FP)
#define HAVE_blockage 1
#define HAVE_push_rts (TARGET_INSNS_64PLUS)
#define HAVE_pop_rts (TARGET_INSNS_64PLUS)
#define HAVE_setup_dsbt (TARGET_DSBT)
#define HAVE_epilogue_barrier 1
#define HAVE_andv2hi3 1
#define HAVE_iorv2hi3 1
#define HAVE_xorv2hi3 1
#define HAVE_andv4qi3 1
#define HAVE_iorv4qi3 1
#define HAVE_xorv4qi3 1
#define HAVE_addv2hi3 1
#define HAVE_subv2hi3 1
#define HAVE_addv4qi3 (TARGET_INSNS_64)
#define HAVE_subv4qi3 (TARGET_INSNS_64)
#define HAVE_ss_addv2hi3 (TARGET_INSNS_64)
#define HAVE_ss_subv2hi3 (TARGET_INSNS_64)
#define HAVE_us_addv4qi3 (TARGET_INSNS_64)
#define HAVE_smaxhi3 (TARGET_INSNS_64)
#define HAVE_smaxv2hi3 (TARGET_INSNS_64)
#define HAVE_sminhi3 (TARGET_INSNS_64)
#define HAVE_sminv2hi3 (TARGET_INSNS_64)
#define HAVE_umaxqi3 (TARGET_INSNS_64)
#define HAVE_umaxv4qi3 (TARGET_INSNS_64)
#define HAVE_uminqi3 (TARGET_INSNS_64)
#define HAVE_uminv4qi3 (TARGET_INSNS_64)
#define HAVE_ashrv2hi3 (TARGET_INSNS_64)
#define HAVE_lshrv2hi3 (TARGET_INSNS_64)
#define HAVE_ssabsv2hi2 (TARGET_INSNS_64)
#define HAVE_movstricthi (TARGET_INSNS_64)
#define HAVE_rotlsi3 (TARGET_INSNS_64)
#define HAVE_bitrevsi2 (TARGET_INSNS_64)
#define HAVE_avgv2hi3 (TARGET_INSNS_64)
#define HAVE_uavgv4qi3 (TARGET_INSNS_64)
#define HAVE_mulhi3 1
#define HAVE_mulhisi3_const 1
#define HAVE_mulhisi3_lh 1
#define HAVE_mulhisi3_hl 1
#define HAVE_mulhisi3_hh 1
#define HAVE_umulhisi3 1
#define HAVE_umulhisi3_lh 1
#define HAVE_umulhisi3_hl 1
#define HAVE_umulhisi3_hh 1
#define HAVE_usmulhisi3_const 1
#define HAVE_usmulhisi3_lh 1
#define HAVE_usmulhisi3_hl 1
#define HAVE_usmulhisi3_hh 1
#define HAVE_mulsi3_insn (TARGET_MPY32)
#define HAVE_umulsidi3 (TARGET_MPY32)
#define HAVE_mulsidi3 (TARGET_MPY32)
#define HAVE_usmulsidi3 (TARGET_MPY32)
#define HAVE_mulv2hiv2si3 (TARGET_INSNS_64)
#define HAVE_umulv4qiv4hi3 (TARGET_INSNS_64)
#define HAVE_usmulv4qiv4hi3 (TARGET_INSNS_64)
#define HAVE_dotv2hi (TARGET_INSNS_64)
#define HAVE_mulv2hqv2sq3 1
#define HAVE_mulhqsq3 1
#define HAVE_mulhqsq3_lh 1
#define HAVE_mulhqsq3_hl 1
#define HAVE_mulhqsq3_hh 1
#define HAVE_rotlsi3_real (TARGET_INSNS_64)
#define HAVE_bitrevsi2_real (TARGET_INSNS_64)
#define HAVE_avgv2hi3_real (TARGET_INSNS_64)
#define HAVE_uavgv4qi3_real (TARGET_INSNS_64)
#define HAVE_mulhi3_real 1
#define HAVE_mulhisi3_const_real 1
#define HAVE_mulhisi3_lh_real 1
#define HAVE_mulhisi3_hl_real 1
#define HAVE_mulhisi3_hh_real 1
#define HAVE_umulhisi3_real 1
#define HAVE_umulhisi3_lh_real 1
#define HAVE_umulhisi3_hl_real 1
#define HAVE_umulhisi3_hh_real 1
#define HAVE_usmulhisi3_const_real 1
#define HAVE_usmulhisi3_lh_real 1
#define HAVE_usmulhisi3_hl_real 1
#define HAVE_usmulhisi3_hh_real 1
#define HAVE_mulsi3_insn_real (TARGET_MPY32)
#define HAVE_umulsidi3_real (TARGET_MPY32)
#define HAVE_mulsidi3_real (TARGET_MPY32)
#define HAVE_usmulsidi3_real (TARGET_MPY32)
#define HAVE_mulv2hiv2si3_real (TARGET_INSNS_64)
#define HAVE_umulv4qiv4hi3_real (TARGET_INSNS_64)
#define HAVE_usmulv4qiv4hi3_real (TARGET_INSNS_64)
#define HAVE_dotv2hi_real (TARGET_INSNS_64)
#define HAVE_mulv2hqv2sq3_real 1
#define HAVE_mulhqsq3_real 1
#define HAVE_mulhqsq3_lh_real 1
#define HAVE_mulhqsq3_hl_real 1
#define HAVE_mulhqsq3_hh_real 1
#define HAVE_sync_addsi_insn 1
#define HAVE_sync_subsi_insn 1
#define HAVE_sync_iorsi_insn 1
#define HAVE_sync_xorsi_insn 1
#define HAVE_sync_andsi_insn 1
#define HAVE_sync_old_addsi_insn 1
#define HAVE_sync_old_subsi_insn 1
#define HAVE_sync_old_iorsi_insn 1
#define HAVE_sync_old_xorsi_insn 1
#define HAVE_sync_old_andsi_insn 1
#define HAVE_sync_new_addsi_insn 1
#define HAVE_sync_new_subsi_insn 1
#define HAVE_sync_new_iorsi_insn 1
#define HAVE_sync_new_xorsi_insn 1
#define HAVE_sync_new_andsi_insn 1
#define HAVE_sync_nandsi_insn 1
#define HAVE_sync_old_nandsi_insn 1
#define HAVE_sync_new_nandsi_insn 1
#define HAVE_movqi 1
#define HAVE_movhi 1
#define HAVE_movsi 1
#define HAVE_movsf 1
#define HAVE_movdi 1
#define HAVE_movdf 1
#define HAVE_movv2hi 1
#define HAVE_movv4qi 1
#define HAVE_movv2si 1
#define HAVE_movv4hi 1
#define HAVE_movv8qi 1
#define HAVE_movmisalignsi (TARGET_INSNS_64)
#define HAVE_movmisaligndi (TARGET_INSNS_64)
#define HAVE_movmisalignv2hi (TARGET_INSNS_64)
#define HAVE_movmisalignv4qi (TARGET_INSNS_64)
#define HAVE_extzv 1
#define HAVE_extv 1
#define HAVE_cmpsi_and 1
#define HAVE_cmpsi_ior 1
#define HAVE_cmpsf_and (TARGET_FP)
#define HAVE_cmpsf_ior (TARGET_FP)
#define HAVE_cmpdf_and (TARGET_FP)
#define HAVE_cmpdf_ior (TARGET_FP)
#define HAVE_cstoresi4 1
#define HAVE_tablejump (!flag_pic || !TARGET_INSNS_64)
#define HAVE_casesi (flag_pic && TARGET_INSNS_64)
#define HAVE_cbranchsi4 1
#define HAVE_cbranchdi4 1
#define HAVE_cbranchsf4 1
#define HAVE_cbranchdf4 1
#define HAVE_return (reload_completed && get_frame_size () == 0 && c6x_nsaved_regs () == 0)
#define HAVE_doloop_end (TARGET_INSNS_64PLUS && optimize)
#define HAVE_adddi3 1
#define HAVE_call 1
#define HAVE_call_value 1
#define HAVE_sibcall 1
#define HAVE_sibcall_value 1
#define HAVE_ctzsi2 (TARGET_INSNS_64)
#define HAVE_ctzdi2 (TARGET_INSNS_64)
#define HAVE_ashldi3 (TARGET_INSNS_64)
#define HAVE_rotrdi3 (TARGET_INSNS_64PLUS)
#define HAVE_bswapsi2 (TARGET_INSNS_64)
#define HAVE_mulhisi3 1
#define HAVE_usmulhisi3 1
#define HAVE_mulsi3 1
#define HAVE_divsf3 (TARGET_FP && flag_reciprocal_math)
#define HAVE_divdf3 (TARGET_FP && flag_reciprocal_math)
#define HAVE_movmemsi 1
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_sdot_prodv2hi (TARGET_INSNS_64)
#define HAVE_sync_compare_and_swapsi 1
#define HAVE_sync_addsi 1
#define HAVE_sync_subsi 1
#define HAVE_sync_iorsi 1
#define HAVE_sync_xorsi 1
#define HAVE_sync_andsi 1
#define HAVE_sync_old_addsi 1
#define HAVE_sync_old_subsi 1
#define HAVE_sync_old_iorsi 1
#define HAVE_sync_old_xorsi 1
#define HAVE_sync_old_andsi 1
#define HAVE_sync_new_addsi 1
#define HAVE_sync_new_subsi 1
#define HAVE_sync_new_iorsi 1
#define HAVE_sync_new_xorsi 1
#define HAVE_sync_new_andsi 1
#define HAVE_sync_nandsi 1
#define HAVE_sync_old_nandsi 1
#define HAVE_sync_new_nandsi 1
extern rtx        gen_nop                        (void);
extern rtx        gen_nop_count                  (rtx);
extern rtx        gen_movsi_lo_sum               (rtx, rtx, rtx);
extern rtx        gen_movsi_high                 (rtx, rtx);
extern rtx        gen_movsi_gotoff_lo_sum        (rtx, rtx, rtx);
extern rtx        gen_movsi_gotoff_high          (rtx, rtx);
extern rtx        gen_load_got_gotoff            (rtx, rtx, rtx);
extern rtx        gen_load_sdata_pic             (rtx, rtx, rtx);
extern rtx        gen_movqi_insn                 (rtx, rtx);
extern rtx        gen_movhi_insn                 (rtx, rtx);
extern rtx        gen_movsi_insn                 (rtx, rtx);
extern rtx        gen_movsf_insn                 (rtx, rtx);
extern rtx        gen_movv2hi_insn               (rtx, rtx);
extern rtx        gen_movv4qi_insn               (rtx, rtx);
extern rtx        gen_real_loadqi                (rtx, rtx);
extern rtx        gen_real_loadhi                (rtx, rtx);
extern rtx        gen_real_loadsi                (rtx, rtx);
extern rtx        gen_real_loadsf                (rtx, rtx);
extern rtx        gen_real_loadv2hi              (rtx, rtx);
extern rtx        gen_real_loadv4qi              (rtx, rtx);
extern rtx        gen_real_loaddi                (rtx, rtx);
extern rtx        gen_real_loaddf                (rtx, rtx);
extern rtx        gen_real_loadv2si              (rtx, rtx);
extern rtx        gen_real_loadv4hi              (rtx, rtx);
extern rtx        gen_real_loadv8qi              (rtx, rtx);
extern rtx        gen_load_shadow                (rtx);
extern rtx        gen_mult_shadow                (rtx);
extern rtx        gen_movmisalignsi_store        (rtx, rtx);
extern rtx        gen_movmisaligndi_store        (rtx, rtx);
extern rtx        gen_movmisalignv2hi_store      (rtx, rtx);
extern rtx        gen_movmisalignv4qi_store      (rtx, rtx);
extern rtx        gen_movmisalignsi_load         (rtx, rtx);
extern rtx        gen_movmisaligndi_load         (rtx, rtx);
extern rtx        gen_movmisalignv2hi_load       (rtx, rtx);
extern rtx        gen_movmisalignv4qi_load       (rtx, rtx);
extern rtx        gen_zero_extendqisi2           (rtx, rtx);
extern rtx        gen_sign_extendqisi2           (rtx, rtx);
extern rtx        gen_zero_extendhisi2           (rtx, rtx);
extern rtx        gen_sign_extendhisi2           (rtx, rtx);
extern rtx        gen_real_zero_extendqi         (rtx, rtx);
extern rtx        gen_real_sign_extendqi         (rtx, rtx);
extern rtx        gen_real_zero_extendhi         (rtx, rtx);
extern rtx        gen_real_sign_extendhi         (rtx, rtx);
extern rtx        gen_clrr                       (rtx, rtx, rtx, rtx);
extern rtx        gen_extr                       (rtx, rtx, rtx);
extern rtx        gen_extru                      (rtx, rtx, rtx);
extern rtx        gen_scmpsi_insn                (rtx, rtx, rtx, rtx);
extern rtx        gen_indirect_jump              (rtx);
extern rtx        gen_jump                       (rtx);
extern rtx        gen_casesi_internal            (rtx, rtx);
extern rtx        gen_br_true                    (rtx, rtx, rtx);
extern rtx        gen_br_false                   (rtx, rtx, rtx);
extern rtx        gen_eh_return                  (rtx);
extern rtx        gen_mvilc                      (rtx);
extern rtx        gen_sploop                     (rtx);
extern rtx        gen_spkernel                   (rtx, rtx, rtx);
extern rtx        gen_loop_end                   (rtx, rtx, rtx, rtx);
extern rtx        gen_real_jump                  (rtx);
extern rtx        gen_real_call                  (rtx);
extern rtx        gen_real_ret                   (rtx);
extern rtx        gen_indirect_jump_shadow       (void);
extern rtx        gen_indirect_call_value_shadow (rtx);
extern rtx        gen_indirect_sibcall_shadow    (void);
extern rtx        gen_indirect_call_shadow       (void);
extern rtx        gen_call_value_shadow          (rtx, rtx);
extern rtx        gen_call_shadow                (rtx);
extern rtx        gen_sibcall_shadow             (rtx);
extern rtx        gen_jump_shadow                (rtx);
extern rtx        gen_condjump_shadow            (rtx);
extern rtx        gen_return_shadow              (void);
extern rtx        gen_addsi3                     (rtx, rtx, rtx);
extern rtx        gen_subsi3                     (rtx, rtx, rtx);
extern rtx        gen_addsidi3_widen             (rtx, rtx, rtx);
extern rtx        gen_addsf3                     (rtx, rtx, rtx);
extern rtx        gen_adddf3                     (rtx, rtx, rtx);
extern rtx        gen_subsf3                     (rtx, rtx, rtx);
extern rtx        gen_subdf3                     (rtx, rtx, rtx);
extern rtx        gen_andsi3                     (rtx, rtx, rtx);
extern rtx        gen_iorsi3                     (rtx, rtx, rtx);
extern rtx        gen_xorsi3                     (rtx, rtx, rtx);
extern rtx        gen_extendsfdf2                (rtx, rtx);
extern rtx        gen_truncdfsf2                 (rtx, rtx);
extern rtx        gen_floatsisf2                 (rtx, rtx);
extern rtx        gen_floatunssisf2              (rtx, rtx);
extern rtx        gen_floatsidf2                 (rtx, rtx);
extern rtx        gen_floatunssidf2              (rtx, rtx);
extern rtx        gen_fix_truncsfsi2             (rtx, rtx);
extern rtx        gen_fix_truncdfsi2             (rtx, rtx);
extern rtx        gen_saddsi3                    (rtx, rtx, rtx);
extern rtx        gen_ssubsi3                    (rtx, rtx, rtx);
extern rtx        gen_subcsi3                    (rtx, rtx, rtx);
extern rtx        gen_call_internal              (rtx);
extern rtx        gen_call_value_internal        (rtx, rtx);
extern rtx        gen_sibcall_internal           (rtx);
extern rtx        gen_callp                      (rtx);
extern rtx        gen_callp_value                (rtx, rtx);
extern rtx        gen_return_internal            (rtx);
extern rtx        gen_addkpc                     (rtx, rtx, rtx);
extern rtx        gen_negsi2                     (rtx, rtx);
extern rtx        gen_one_cmplsi2                (rtx, rtx);
extern rtx        gen_clrsbsi2                   (rtx, rtx);
extern rtx        gen_clzsi2                     (rtx, rtx);
extern rtx        gen_ssabssi2                   (rtx, rtx);
extern rtx        gen_ss_ashlsi3                 (rtx, rtx, rtx);
extern rtx        gen_ashlsi3                    (rtx, rtx, rtx);
extern rtx        gen_ashrsi3                    (rtx, rtx, rtx);
extern rtx        gen_lshrsi3                    (rtx, rtx, rtx);
extern rtx        gen_rotrdi3_16                 (rtx, rtx);
extern rtx        gen_shlmbsi3                   (rtx, rtx, rtx);
extern rtx        gen_bswapv2hi2                 (rtx, rtx);
extern rtx        gen_divsi3_insn                (void);
extern rtx        gen_divsi3_insn_indcall        (rtx);
extern rtx        gen_udivsi3_insn               (void);
extern rtx        gen_udivsi3_insn_indcall       (rtx);
extern rtx        gen_modsi3_insn                (void);
extern rtx        gen_modsi3_insn_indcall        (rtx);
extern rtx        gen_divmodsi4_insn             (void);
extern rtx        gen_divmodsi4_insn_indcall     (rtx);
extern rtx        gen_umodsi3_insn               (void);
extern rtx        gen_umodsi3_insn_indcall       (rtx);
extern rtx        gen_udivmodsi4_insn            (void);
extern rtx        gen_udivmodsi4_insn_indcall    (rtx);
extern rtx        gen_divmodsi4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_udivmodsi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mulsf3                     (rtx, rtx, rtx);
extern rtx        gen_muldf3                     (rtx, rtx, rtx);
extern rtx        gen_rcpsf2                     (rtx, rtx);
extern rtx        gen_rcpdf2                     (rtx, rtx);
extern rtx        gen_blockage                   (void);
extern rtx        gen_push_rts                   (void);
extern rtx        gen_pop_rts                    (void);
extern rtx        gen_setup_dsbt                 (rtx, rtx);
extern rtx        gen_epilogue_barrier           (rtx, rtx);
extern rtx        gen_andv2hi3                   (rtx, rtx, rtx);
extern rtx        gen_iorv2hi3                   (rtx, rtx, rtx);
extern rtx        gen_xorv2hi3                   (rtx, rtx, rtx);
extern rtx        gen_andv4qi3                   (rtx, rtx, rtx);
extern rtx        gen_iorv4qi3                   (rtx, rtx, rtx);
extern rtx        gen_xorv4qi3                   (rtx, rtx, rtx);
extern rtx        gen_addv2hi3                   (rtx, rtx, rtx);
extern rtx        gen_subv2hi3                   (rtx, rtx, rtx);
extern rtx        gen_addv4qi3                   (rtx, rtx, rtx);
extern rtx        gen_subv4qi3                   (rtx, rtx, rtx);
extern rtx        gen_ss_addv2hi3                (rtx, rtx, rtx);
extern rtx        gen_ss_subv2hi3                (rtx, rtx, rtx);
extern rtx        gen_us_addv4qi3                (rtx, rtx, rtx);
extern rtx        gen_smaxhi3                    (rtx, rtx, rtx);
extern rtx        gen_smaxv2hi3                  (rtx, rtx, rtx);
extern rtx        gen_sminhi3                    (rtx, rtx, rtx);
extern rtx        gen_sminv2hi3                  (rtx, rtx, rtx);
extern rtx        gen_umaxqi3                    (rtx, rtx, rtx);
extern rtx        gen_umaxv4qi3                  (rtx, rtx, rtx);
extern rtx        gen_uminqi3                    (rtx, rtx, rtx);
extern rtx        gen_uminv4qi3                  (rtx, rtx, rtx);
extern rtx        gen_ashrv2hi3                  (rtx, rtx, rtx);
extern rtx        gen_lshrv2hi3                  (rtx, rtx, rtx);
extern rtx        gen_ssabsv2hi2                 (rtx, rtx);
extern rtx        gen_movstricthi                (rtx, rtx);
extern rtx        gen_rotlsi3                    (rtx, rtx, rtx);
extern rtx        gen_bitrevsi2                  (rtx, rtx);
extern rtx        gen_avgv2hi3                   (rtx, rtx, rtx);
extern rtx        gen_uavgv4qi3                  (rtx, rtx, rtx);
extern rtx        gen_mulhi3                     (rtx, rtx, rtx);
extern rtx        gen_mulhisi3_const             (rtx, rtx, rtx);
extern rtx        gen_mulhisi3_lh                (rtx, rtx, rtx);
extern rtx        gen_mulhisi3_hl                (rtx, rtx, rtx);
extern rtx        gen_mulhisi3_hh                (rtx, rtx, rtx);
extern rtx        gen_umulhisi3                  (rtx, rtx, rtx);
extern rtx        gen_umulhisi3_lh               (rtx, rtx, rtx);
extern rtx        gen_umulhisi3_hl               (rtx, rtx, rtx);
extern rtx        gen_umulhisi3_hh               (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3_const           (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3_lh              (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3_hl              (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3_hh              (rtx, rtx, rtx);
extern rtx        gen_mulsi3_insn                (rtx, rtx, rtx);
extern rtx        gen_umulsidi3                  (rtx, rtx, rtx);
extern rtx        gen_mulsidi3                   (rtx, rtx, rtx);
extern rtx        gen_usmulsidi3                 (rtx, rtx, rtx);
extern rtx        gen_mulv2hiv2si3               (rtx, rtx, rtx);
extern rtx        gen_umulv4qiv4hi3              (rtx, rtx, rtx);
extern rtx        gen_usmulv4qiv4hi3             (rtx, rtx, rtx);
extern rtx        gen_dotv2hi                    (rtx, rtx, rtx);
extern rtx        gen_mulv2hqv2sq3               (rtx, rtx, rtx);
extern rtx        gen_mulhqsq3                   (rtx, rtx, rtx);
extern rtx        gen_mulhqsq3_lh                (rtx, rtx, rtx);
extern rtx        gen_mulhqsq3_hl                (rtx, rtx, rtx);
extern rtx        gen_mulhqsq3_hh                (rtx, rtx, rtx);
extern rtx        gen_rotlsi3_real               (rtx, rtx, rtx);
extern rtx        gen_bitrevsi2_real             (rtx, rtx);
extern rtx        gen_avgv2hi3_real              (rtx, rtx, rtx);
extern rtx        gen_uavgv4qi3_real             (rtx, rtx, rtx);
extern rtx        gen_mulhi3_real                (rtx, rtx, rtx);
extern rtx        gen_mulhisi3_const_real        (rtx, rtx, rtx);
extern rtx        gen_mulhisi3_lh_real           (rtx, rtx, rtx);
extern rtx        gen_mulhisi3_hl_real           (rtx, rtx, rtx);
extern rtx        gen_mulhisi3_hh_real           (rtx, rtx, rtx);
extern rtx        gen_umulhisi3_real             (rtx, rtx, rtx);
extern rtx        gen_umulhisi3_lh_real          (rtx, rtx, rtx);
extern rtx        gen_umulhisi3_hl_real          (rtx, rtx, rtx);
extern rtx        gen_umulhisi3_hh_real          (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3_const_real      (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3_lh_real         (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3_hl_real         (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3_hh_real         (rtx, rtx, rtx);
extern rtx        gen_mulsi3_insn_real           (rtx, rtx, rtx);
extern rtx        gen_umulsidi3_real             (rtx, rtx, rtx);
extern rtx        gen_mulsidi3_real              (rtx, rtx, rtx);
extern rtx        gen_usmulsidi3_real            (rtx, rtx, rtx);
extern rtx        gen_mulv2hiv2si3_real          (rtx, rtx, rtx);
extern rtx        gen_umulv4qiv4hi3_real         (rtx, rtx, rtx);
extern rtx        gen_usmulv4qiv4hi3_real        (rtx, rtx, rtx);
extern rtx        gen_dotv2hi_real               (rtx, rtx, rtx);
extern rtx        gen_mulv2hqv2sq3_real          (rtx, rtx, rtx);
extern rtx        gen_mulhqsq3_real              (rtx, rtx, rtx);
extern rtx        gen_mulhqsq3_lh_real           (rtx, rtx, rtx);
extern rtx        gen_mulhqsq3_hl_real           (rtx, rtx, rtx);
extern rtx        gen_mulhqsq3_hh_real           (rtx, rtx, rtx);
extern rtx        gen_sync_addsi_insn            (rtx, rtx);
extern rtx        gen_sync_subsi_insn            (rtx, rtx);
extern rtx        gen_sync_iorsi_insn            (rtx, rtx);
extern rtx        gen_sync_xorsi_insn            (rtx, rtx);
extern rtx        gen_sync_andsi_insn            (rtx, rtx);
extern rtx        gen_sync_old_addsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_old_subsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_old_iorsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_old_xorsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_old_andsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_new_addsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_new_subsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_new_iorsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_new_xorsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_new_andsi_insn        (rtx, rtx, rtx);
extern rtx        gen_sync_nandsi_insn           (rtx, rtx);
extern rtx        gen_sync_old_nandsi_insn       (rtx, rtx, rtx);
extern rtx        gen_sync_new_nandsi_insn       (rtx, rtx, rtx);
extern rtx        gen_movqi                      (rtx, rtx);
extern rtx        gen_movhi                      (rtx, rtx);
extern rtx        gen_movsi                      (rtx, rtx);
extern rtx        gen_movsf                      (rtx, rtx);
extern rtx        gen_movdi                      (rtx, rtx);
extern rtx        gen_movdf                      (rtx, rtx);
extern rtx        gen_movv2hi                    (rtx, rtx);
extern rtx        gen_movv4qi                    (rtx, rtx);
extern rtx        gen_movv2si                    (rtx, rtx);
extern rtx        gen_movv4hi                    (rtx, rtx);
extern rtx        gen_movv8qi                    (rtx, rtx);
extern rtx        gen_movmisalignsi              (rtx, rtx);
extern rtx        gen_movmisaligndi              (rtx, rtx);
extern rtx        gen_movmisalignv2hi            (rtx, rtx);
extern rtx        gen_movmisalignv4qi            (rtx, rtx);
extern rtx        gen_extzv                      (rtx, rtx, rtx, rtx);
extern rtx        gen_extv                       (rtx, rtx, rtx, rtx);
extern rtx        gen_cmpsi_and                  (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cmpsi_ior                  (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cmpsf_and                  (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cmpsf_ior                  (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cmpdf_and                  (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cmpdf_ior                  (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresi4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_tablejump                  (rtx, rtx);
extern rtx        gen_casesi                     (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_return                     (void);
extern rtx        gen_doloop_end                 (rtx, rtx);
extern rtx        gen_adddi3                     (rtx, rtx, rtx);
extern rtx        gen_call                       (rtx);
extern rtx        gen_call_value                 (rtx, rtx);
extern rtx        gen_sibcall                    (rtx);
extern rtx        gen_sibcall_value              (rtx, rtx);
extern rtx        gen_ctzsi2                     (rtx, rtx);
extern rtx        gen_ctzdi2                     (rtx, rtx);
extern rtx        gen_ashldi3                    (rtx, rtx, rtx);
extern rtx        gen_rotrdi3                    (rtx, rtx, rtx);
extern rtx        gen_bswapsi2                   (rtx, rtx);
extern rtx        gen_mulhisi3                   (rtx, rtx, rtx);
extern rtx        gen_usmulhisi3                 (rtx, rtx, rtx);
extern rtx        gen_mulsi3                     (rtx, rtx, rtx);
extern rtx        gen_divsf3                     (rtx, rtx, rtx);
extern rtx        gen_divdf3                     (rtx, rtx, rtx);
extern rtx        gen_movmemsi                   (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_prologue                   (void);
extern rtx        gen_epilogue                   (void);
extern rtx        gen_sibcall_epilogue           (void);
extern rtx        gen_sdot_prodv2hi              (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_compare_and_swapsi    (rtx, rtx, rtx, rtx);
extern rtx        gen_sync_addsi                 (rtx, rtx);
extern rtx        gen_sync_subsi                 (rtx, rtx);
extern rtx        gen_sync_iorsi                 (rtx, rtx);
extern rtx        gen_sync_xorsi                 (rtx, rtx);
extern rtx        gen_sync_andsi                 (rtx, rtx);
extern rtx        gen_sync_old_addsi             (rtx, rtx, rtx);
extern rtx        gen_sync_old_subsi             (rtx, rtx, rtx);
extern rtx        gen_sync_old_iorsi             (rtx, rtx, rtx);
extern rtx        gen_sync_old_xorsi             (rtx, rtx, rtx);
extern rtx        gen_sync_old_andsi             (rtx, rtx, rtx);
extern rtx        gen_sync_new_addsi             (rtx, rtx, rtx);
extern rtx        gen_sync_new_subsi             (rtx, rtx, rtx);
extern rtx        gen_sync_new_iorsi             (rtx, rtx, rtx);
extern rtx        gen_sync_new_xorsi             (rtx, rtx, rtx);
extern rtx        gen_sync_new_andsi             (rtx, rtx, rtx);
extern rtx        gen_sync_nandsi                (rtx, rtx);
extern rtx        gen_sync_old_nandsi            (rtx, rtx, rtx);
extern rtx        gen_sync_new_nandsi            (rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
