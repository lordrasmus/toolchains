/* Generated automatically. */
static const char configuration_arguments[] = "/home/ramin/entwicklung_hd/anderes/uclibc/openadk/toolchain_build_generic-c6x_uclibc-ng_nommu/w-gcc-7.5.0-1/gcc-7.5.0/configure --prefix=/home/ramin/entwicklung_hd/anderes/uclibc/openadk/toolchain_generic-c6x_uclibc-ng_nommu/usr --with-bugurl=https://openadk.org --build=x86_64-linux-gnu --host=x86_64-linux-gnu --target=tic6x-openadk-uclinux --with-gmp=/home/ramin/entwicklung_hd/anderes/uclibc/openadk/host_x86_64-linux-gnu/usr --with-mpfr=/home/ramin/entwicklung_hd/anderes/uclibc/openadk/host_x86_64-linux-gnu/usr --enable-__cxa_atexit --with-system-zlib --with-gnu-ld --with-gnu-as --disable-libsanitizer --disable-install-libiberty --disable-libitm --disable-libmudflap --disable-libgomp --disable-libcc1 --disable-libmpx --disable-libcilkrts --disable-libquadmath --disable-libquadmath-support --disable-decimal-float --disable-libstdcxx-pch --disable-ppl-version-check --disable-cloog-version-check --without-ppl --without-cloog --without-isl --disable-werror --disable-nls --enable-obsolete --disable-lto --with-arch=c674x --disable-tls --enable-languages=c --with-newlib --disable-shared --disable-threads --disable-multilib --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "arch", "c674x" } };
