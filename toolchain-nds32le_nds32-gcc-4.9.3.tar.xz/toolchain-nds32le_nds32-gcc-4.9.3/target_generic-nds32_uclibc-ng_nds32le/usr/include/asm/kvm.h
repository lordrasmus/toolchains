/*
 *  linux/arch/nds32/include/asm/kvm.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef __NDS32_KVM_H__
#define __NDS32_KVM_H__

#endif /* __NDS32_KVM_H__ */
