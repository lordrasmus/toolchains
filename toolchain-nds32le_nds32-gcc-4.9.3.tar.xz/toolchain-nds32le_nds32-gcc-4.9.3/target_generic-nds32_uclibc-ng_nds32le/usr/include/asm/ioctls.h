/*
 *  linux/arch/nds32/include/asm/ioctls.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef __ASM_NDS32_IOCTLS_H
#define __ASM_NDS32_IOCTLS_H

#define FIOQSIZE    0x545E

#include <asm-generic/ioctls.h>

#endif
