/*
 *  linux/arch/nds32/include/asm/statfs.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef _ASMNDS32_STATFS_H
#define _ASMNDS32_STATFS_H

#include <asm-generic/statfs.h>

#endif
