/*
 *  linux/arch/nds32/include/asm/errno.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef __NDS32_ERRNO_H__
#define __NDS32_ERRNO_H__

#include <asm-generic/errno.h>

#endif
