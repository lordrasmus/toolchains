/*
 *  linux/arch/nds32/include/asm/poll.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef __ASMNDS32_POLL_H
#define __ASMNDS32_POLL_H

#include <asm-generic/poll.h>

#endif
