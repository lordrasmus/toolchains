/*
 *  linux/arch/nds32/include/asm/auxvec.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef __NDS32_AUXVEC_H__
#define __NDS32_AUXVEC_H__

#endif /*__NDS32_AUXVEC_H__ */
