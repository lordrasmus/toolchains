/*
 *  linux/arch/nds32/include/asm/socket.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef _ASMNDS32_SOCKET_H
#define _ASMNDS32_SOCKET_H

#include <asm-generic/socket.h>

#endif /* _ASMNDS32_SOCKET_H */
