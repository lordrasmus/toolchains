/*
 *  linux/arch/nds32/include/asm/siginfo.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef _ASMNDS32_SIGINFO_H
#define _ASMNDS32_SIGINFO_H

#include <asm-generic/siginfo.h>

#endif
