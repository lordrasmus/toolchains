/*
 *  linux/arch/nds32/include/asm/sockios.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef __ARCH_NDS32_SOCKIOS_H
#define __ARCH_NDS32_SOCKIOS_H

/* Socket-level I/O control calls. */
#define FIOSETOWN 	0x8901
#define SIOCSPGRP	0x8902
#define FIOGETOWN	0x8903
#define SIOCGPGRP	0x8904
#define SIOCATMARK	0x8905
#define SIOCGSTAMP	0x8906		/* Get stamp */
#define SIOCGSTAMPNS    0x8907          /* Get stamp (timespec) */

#endif
