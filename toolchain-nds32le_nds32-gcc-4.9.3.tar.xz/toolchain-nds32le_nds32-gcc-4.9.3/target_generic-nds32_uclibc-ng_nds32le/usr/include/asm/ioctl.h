/*
 *  linux/arch/nds32/include/asm/ioctl.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef __NDS32_IOCTL_H__
#define __NDS32_IOCTL_H__

#include <asm-generic/ioctl.h>

#endif
