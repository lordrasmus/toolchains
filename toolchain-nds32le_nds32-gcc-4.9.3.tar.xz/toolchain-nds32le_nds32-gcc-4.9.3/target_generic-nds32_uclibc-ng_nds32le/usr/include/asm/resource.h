/*
 *  linux/arch/nds32/include/asm/resource.h
 *  Copyright (C) 2008 Andes Technology Corporation
 */

#ifndef __NDS32_RESOURCE_H__
#define __NDS32_RESOURCE_H__

#include <asm-generic/resource.h>

#endif
