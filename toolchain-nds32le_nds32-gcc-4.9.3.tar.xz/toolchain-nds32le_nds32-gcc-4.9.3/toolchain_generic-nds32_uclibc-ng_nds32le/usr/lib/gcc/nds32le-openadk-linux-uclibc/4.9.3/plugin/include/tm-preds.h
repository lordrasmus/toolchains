/* Generated automatically by the program 'build/genpreds'
   from the machine description file '/home/ramin/openadk/toolchain_build_generic-nds32_uclibc-ng_nds32le/w-gcc-4.9.3-1/gcc-4.9.3/gcc/config/nds32/nds32.md'.  */

#ifndef GCC_TM_PREDS_H
#define GCC_TM_PREDS_H

#ifdef HAVE_MACHINE_MODES
extern int general_operand (rtx, enum machine_mode);
extern int address_operand (rtx, enum machine_mode);
extern int register_operand (rtx, enum machine_mode);
extern int pmode_register_operand (rtx, enum machine_mode);
extern int scratch_operand (rtx, enum machine_mode);
extern int immediate_operand (rtx, enum machine_mode);
extern int const_int_operand (rtx, enum machine_mode);
extern int const_double_operand (rtx, enum machine_mode);
extern int nonimmediate_operand (rtx, enum machine_mode);
extern int nonmemory_operand (rtx, enum machine_mode);
extern int push_operand (rtx, enum machine_mode);
extern int pop_operand (rtx, enum machine_mode);
extern int memory_operand (rtx, enum machine_mode);
extern int indirect_operand (rtx, enum machine_mode);
extern int ordered_comparison_operator (rtx, enum machine_mode);
extern int comparison_operator (rtx, enum machine_mode);
extern int nds32_equality_comparison_operator (rtx, enum machine_mode);
extern int nds32_greater_less_comparison_operator (rtx, enum machine_mode);
extern int nds32_float_comparison_operator (rtx, enum machine_mode);
extern int nds32_movecc_comparison_operator (rtx, enum machine_mode);
extern int nds32_logical_binary_operator (rtx, enum machine_mode);
extern int nds32_conditional_call_comparison_operator (rtx, enum machine_mode);
extern int nds32_have_33_inst_operator (rtx, enum machine_mode);
extern int nds32_symbolic_operand (rtx, enum machine_mode);
extern int nds32_nonunspec_symbolic_operand (rtx, enum machine_mode);
extern int nds32_label_operand (rtx, enum machine_mode);
extern int nds32_reg_constant_operand (rtx, enum machine_mode);
extern int nds32_rimm15s_operand (rtx, enum machine_mode);
extern int nds32_rimm11s_operand (rtx, enum machine_mode);
extern int nds32_imm_0_1_operand (rtx, enum machine_mode);
extern int nds32_imm_1_2_operand (rtx, enum machine_mode);
extern int nds32_imm_1_2_4_8_operand (rtx, enum machine_mode);
extern int nds32_imm2u_operand (rtx, enum machine_mode);
extern int nds32_imm4u_operand (rtx, enum machine_mode);
extern int nds32_imm5u_operand (rtx, enum machine_mode);
extern int nds32_imm6u_operand (rtx, enum machine_mode);
extern int nds32_rimm4u_operand (rtx, enum machine_mode);
extern int nds32_rimm5u_operand (rtx, enum machine_mode);
extern int nds32_rimm6u_operand (rtx, enum machine_mode);
extern int nds32_move_operand (rtx, enum machine_mode);
extern int nds32_vmove_operand (rtx, enum machine_mode);
extern int nds32_and_operand (rtx, enum machine_mode);
extern int nds32_ior_operand (rtx, enum machine_mode);
extern int nds32_xor_operand (rtx, enum machine_mode);
extern int nds32_general_register_operand (rtx, enum machine_mode);
extern int nds32_insv_operand (rtx, enum machine_mode);
extern int nds32_lmw_smw_base_operand (rtx, enum machine_mode);
extern int float_even_register_operand (rtx, enum machine_mode);
extern int float_odd_register_operand (rtx, enum machine_mode);
extern int nds32_load_multiple_operation (rtx, enum machine_mode);
extern int nds32_load_multiple_and_update_address_operation (rtx, enum machine_mode);
extern int nds32_store_multiple_operation (rtx, enum machine_mode);
extern int nds32_store_multiple_and_update_address_operation (rtx, enum machine_mode);
extern int nds32_stack_push_operation (rtx, enum machine_mode);
extern int nds32_stack_pop_operation (rtx, enum machine_mode);
#endif /* HAVE_MACHINE_MODES */

#define CONSTRAINT_NUM_DEFINED_P 1
enum constraint_num
{
  CONSTRAINT__UNKNOWN = 0,
  CONSTRAINT_l,
  CONSTRAINT_d,
  CONSTRAINT_h,
  CONSTRAINT_t,
  CONSTRAINT_e,
  CONSTRAINT_k,
  CONSTRAINT_v,
  CONSTRAINT_x,
  CONSTRAINT_f,
  CONSTRAINT_A,
  CONSTRAINT_Iv00,
  CONSTRAINT_Iv01,
  CONSTRAINT_Iv02,
  CONSTRAINT_Iv04,
  CONSTRAINT_Iv08,
  CONSTRAINT_Iu01,
  CONSTRAINT_Iu02,
  CONSTRAINT_Iu03,
  CONSTRAINT_In03,
  CONSTRAINT_Iu04,
  CONSTRAINT_Is05,
  CONSTRAINT_Cs05,
  CONSTRAINT_Iu05,
  CONSTRAINT_In05,
  CONSTRAINT_Iu06,
  CONSTRAINT_Ip05,
  CONSTRAINT_IU06,
  CONSTRAINT_Iu08,
  CONSTRAINT_Iu09,
  CONSTRAINT_Is08,
  CONSTRAINT_Is10,
  CONSTRAINT_Is11,
  CONSTRAINT_Is14,
  CONSTRAINT_Is15,
  CONSTRAINT_Iu15,
  CONSTRAINT_Ic15,
  CONSTRAINT_Ie15,
  CONSTRAINT_It15,
  CONSTRAINT_Ii15,
  CONSTRAINT_Is16,
  CONSTRAINT_Is17,
  CONSTRAINT_Is19,
  CONSTRAINT_Is20,
  CONSTRAINT_Cs20,
  CONSTRAINT_Ihig,
  CONSTRAINT_Chig,
  CONSTRAINT_Izeb,
  CONSTRAINT_Izeh,
  CONSTRAINT_Ixls,
  CONSTRAINT_Ix11,
  CONSTRAINT_Ibms,
  CONSTRAINT_Ifex,
  CONSTRAINT_CVp5,
  CONSTRAINT_CVs5,
  CONSTRAINT_CVs2,
  CONSTRAINT_CVhi,
  CONSTRAINT_U33,
  CONSTRAINT_U45,
  CONSTRAINT_Ufe,
  CONSTRAINT_U37,
  CONSTRAINT_Umw,
  CONSTRAINT_Da,
  CONSTRAINT_Q,
  CONSTRAINT__LIMIT
};

extern enum constraint_num lookup_constraint (const char *);
extern bool constraint_satisfied_p (rtx, enum constraint_num);

static inline size_t
insn_constraint_len (char fc, const char *str ATTRIBUTE_UNUSED)
{
  switch (fc)
    {
    case 'C': return 4;
    case 'D': return 2;
    case 'I': return 4;
    case 'U': return 3;
    default: break;
    }
  return 1;
}

#define CONSTRAINT_LEN(c_,s_) insn_constraint_len (c_,s_)

extern enum reg_class regclass_for_constraint (enum constraint_num);
#define REG_CLASS_FROM_CONSTRAINT(c_,s_) \
    regclass_for_constraint (lookup_constraint (s_))
#define REG_CLASS_FOR_CONSTRAINT(x_) \
    regclass_for_constraint (x_)

extern bool insn_const_int_ok_for_constraint (HOST_WIDE_INT, enum constraint_num);
#define CONST_OK_FOR_CONSTRAINT_P(v_,c_,s_) \
    insn_const_int_ok_for_constraint (v_, lookup_constraint (s_))

#define CONST_DOUBLE_OK_FOR_CONSTRAINT_P(v_,c_,s_) 0

#define EXTRA_CONSTRAINT_STR(v_,c_,s_) \
    constraint_satisfied_p (v_, lookup_constraint (s_))

extern bool insn_extra_memory_constraint (enum constraint_num);
#define EXTRA_MEMORY_CONSTRAINT(c_,s_) insn_extra_memory_constraint (lookup_constraint (s_))

#define EXTRA_ADDRESS_CONSTRAINT(c_,s_) false

#endif /* tm-preds.h */
