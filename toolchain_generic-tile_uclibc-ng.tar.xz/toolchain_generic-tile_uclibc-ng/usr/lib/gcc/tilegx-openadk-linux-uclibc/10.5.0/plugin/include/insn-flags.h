/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_movstrictqi 1
#define HAVE_movstricthi 1
#define HAVE_movstrictsi 1
#define HAVE_insn_lnk_and_label_32bit 1
#define HAVE_insn_lnk_and_label 1
#define HAVE_mov_pcrel_step3_32bit (flag_pic)
#define HAVE_mov_pcrel_step3 (flag_pic)
#define HAVE_mov_large_pcrel_step4 (flag_pic)
#define HAVE_addsi3 1
#define HAVE_adddi3 1
#define HAVE_subsi3 1
#define HAVE_subdi3 1
#define HAVE_negsi2 1
#define HAVE_negdi2 1
#define HAVE_ssaddsi3 1
#define HAVE_sssubsi3 1
#define HAVE_ashlsi3 1
#define HAVE_ashldi3 1
#define HAVE_ashrsi3 1
#define HAVE_ashrdi3 1
#define HAVE_lshrsi3 1
#define HAVE_lshrdi3 1
#define HAVE_rotldi3 1
#define HAVE_insn_shl16insli 1
#define HAVE_insn_addr_shl16insli_32bit 1
#define HAVE_insn_addr_shl16insli 1
#define HAVE_insn_cmpne_sisi 1
#define HAVE_insn_cmpne_disi 1
#define HAVE_insn_cmpne_sidi 1
#define HAVE_insn_cmpne_didi 1
#define HAVE_insn_cmpeq_sisi 1
#define HAVE_insn_cmpeq_disi 1
#define HAVE_insn_cmpeq_sidi 1
#define HAVE_insn_cmpeq_didi 1
#define HAVE_insn_cmplts_sisi 1
#define HAVE_insn_cmplts_disi 1
#define HAVE_insn_cmplts_sidi 1
#define HAVE_insn_cmplts_didi 1
#define HAVE_insn_cmpltu_sisi 1
#define HAVE_insn_cmpltu_disi 1
#define HAVE_insn_cmpltu_sidi 1
#define HAVE_insn_cmpltu_didi 1
#define HAVE_insn_cmples_sisi 1
#define HAVE_insn_cmples_disi 1
#define HAVE_insn_cmples_sidi 1
#define HAVE_insn_cmples_didi 1
#define HAVE_insn_cmpleu_sisi 1
#define HAVE_insn_cmpleu_disi 1
#define HAVE_insn_cmpleu_sidi 1
#define HAVE_insn_cmpleu_didi 1
#define HAVE_andsi3 1
#define HAVE_andv8qi3 1
#define HAVE_andv4hi3 1
#define HAVE_andv2si3 1
#define HAVE_anddi3 1
#define HAVE_iorsi3 1
#define HAVE_iordi3 1
#define HAVE_iorv8qi3 1
#define HAVE_iorv4hi3 1
#define HAVE_iorv2si3 1
#define HAVE_xorsi3 1
#define HAVE_xordi3 1
#define HAVE_xorv8qi3 1
#define HAVE_xorv4hi3 1
#define HAVE_xorv2si3 1
#define HAVE_clzdi2 1
#define HAVE_ctzsi2 1
#define HAVE_ctzdi2 1
#define HAVE_popcountsi2 1
#define HAVE_popcountdi2 1
#define HAVE_bswapdi2 1
#define HAVE_one_cmplsi2 1
#define HAVE_one_cmpldi2 1
#define HAVE_one_cmplv8qi2 1
#define HAVE_one_cmplv4hi2 1
#define HAVE_one_cmplv2si2 1
#define HAVE_movcc_insn_sisi 1
#define HAVE_movcc_insn_sidi 1
#define HAVE_movcc_insn_disi 1
#define HAVE_movcc_insn_didi 1
#define HAVE_zero_extendqisi2 1
#define HAVE_zero_extendqidi2 1
#define HAVE_zero_extendhisi2 1
#define HAVE_zero_extendhidi2 1
#define HAVE_zero_extendsidi2 1
#define HAVE_extendqisi2 1
#define HAVE_extendqidi2 1
#define HAVE_extendhisi2 1
#define HAVE_extendhidi2 1
#define HAVE_extendsidi2 1
#define HAVE_truncdisi2 1
#define HAVE_truncdihi2 1
#define HAVE_truncdiqi2 1
#define HAVE_mulsi3 1
#define HAVE_mulsidi3 1
#define HAVE_umulsidi3 1
#define HAVE_usmulsidi3 1
#define HAVE_maddsidi4 1
#define HAVE_umaddsidi4 1
#define HAVE_jump 1
#define HAVE_indirect_jump 1
#define HAVE__return (reload_completed)
#define HAVE_tablejump_aux 1
#define HAVE_blockage 1
#define HAVE_sp_adjust 1
#define HAVE_sp_adjust_32bit 1
#define HAVE_sp_restore_32bit 1
#define HAVE_sp_restore 1
#define HAVE_nop 1
#define HAVE_trap 1
#define HAVE_prefetch 1
#define HAVE_insn_bfexts 1
#define HAVE_insn_bfextu 1
#define HAVE_insn_bfins 1
#define HAVE_insn_cmpexch4 1
#define HAVE_insn_cmpexch 1
#define HAVE_insn_cmul 1
#define HAVE_insn_cmula 1
#define HAVE_insn_cmulaf 1
#define HAVE_insn_cmulf 1
#define HAVE_insn_cmulfr 1
#define HAVE_insn_cmulh 1
#define HAVE_insn_cmulhr 1
#define HAVE_insn_crc32_32 1
#define HAVE_insn_crc32_8 1
#define HAVE_insn_dblalign 1
#define HAVE_insn_dblalign2 1
#define HAVE_insn_dblalign4 1
#define HAVE_insn_dblalign6 1
#define HAVE_insn_dtlbpr 1
#define HAVE_insn_exch4 1
#define HAVE_insn_exch 1
#define HAVE_insn_fdouble_add_flags 1
#define HAVE_insn_fdouble_addsub 1
#define HAVE_insn_fdouble_mul_flags 1
#define HAVE_insn_fdouble_pack1 1
#define HAVE_insn_fdouble_pack2 1
#define HAVE_insn_fdouble_sub_flags 1
#define HAVE_insn_fdouble_unpack_max 1
#define HAVE_insn_fdouble_unpack_min 1
#define HAVE_insn_fetchadd4 1
#define HAVE_insn_fetchadd 1
#define HAVE_insn_fetchaddgez4 1
#define HAVE_insn_fetchaddgez 1
#define HAVE_insn_fetchand4 1
#define HAVE_insn_fetchand 1
#define HAVE_insn_fetchor4 1
#define HAVE_insn_fetchor 1
#define HAVE_insn_finv 1
#define HAVE_insn_flush 1
#define HAVE_insn_flushwb 1
#define HAVE_insn_fnop 1
#define HAVE_insn_fsingle_add1 1
#define HAVE_insn_fsingle_addsub2 1
#define HAVE_insn_fsingle_mul1 1
#define HAVE_insn_fsingle_mul2 1
#define HAVE_insn_fsingle_pack1 1
#define HAVE_insn_fsingle_pack2 1
#define HAVE_insn_fsingle_sub1 1
#define HAVE_insn_drain 1
#define HAVE_insn_icoh 1
#define HAVE_insn_ill 1
#define HAVE_insn_info 1
#define HAVE_insn_infol 1
#define HAVE_insn_inv 1
#define HAVE_insn_ld_add_32bit 1
#define HAVE_insn_ld_add 1
#define HAVE_insn_ldna 1
#define HAVE_insn_ldna_add_32bit 1
#define HAVE_insn_ldna_add 1
#define HAVE_insn_ld1s_add_32bit 1
#define HAVE_insn_ld1u_add_32bit 1
#define HAVE_insn_ld1s_add 1
#define HAVE_insn_ld1u_add 1
#define HAVE_insn_ld2s_add_32bit 1
#define HAVE_insn_ld2u_add_32bit 1
#define HAVE_insn_ld2s_add 1
#define HAVE_insn_ld2u_add 1
#define HAVE_insn_ld4s_add_32bit 1
#define HAVE_insn_ld4u_add_32bit 1
#define HAVE_insn_ld4s_add 1
#define HAVE_insn_ld4u_add 1
#define HAVE_insn_ldnt 1
#define HAVE_insn_ldnt_add_32bit 1
#define HAVE_insn_ldnt_add 1
#define HAVE_insn_ldnt1s 1
#define HAVE_insn_ldnt1u 1
#define HAVE_insn_ldnt2s 1
#define HAVE_insn_ldnt2u 1
#define HAVE_insn_ldnt4s 1
#define HAVE_insn_ldnt4u 1
#define HAVE_insn_ldnt1s_add_32bit 1
#define HAVE_insn_ldnt1u_add_32bit 1
#define HAVE_insn_ldnt1s_add 1
#define HAVE_insn_ldnt1u_add 1
#define HAVE_insn_ldnt2s_add_32bit 1
#define HAVE_insn_ldnt2u_add_32bit 1
#define HAVE_insn_ldnt2s_add 1
#define HAVE_insn_ldnt2u_add 1
#define HAVE_insn_ldnt4s_add_32bit 1
#define HAVE_insn_ldnt4u_add_32bit 1
#define HAVE_insn_ldnt4s_add 1
#define HAVE_insn_ldnt4u_add 1
#define HAVE_insn_ld_L2 1
#define HAVE_insn_ld_add_L2_32bit 1
#define HAVE_insn_ld_add_L2 1
#define HAVE_insn_ldna_L2 1
#define HAVE_insn_ldna_add_L2_32bit 1
#define HAVE_insn_ldna_add_L2 1
#define HAVE_insn_ld1s_L2 1
#define HAVE_insn_ld1u_L2 1
#define HAVE_insn_ld2s_L2 1
#define HAVE_insn_ld2u_L2 1
#define HAVE_insn_ld4s_L2 1
#define HAVE_insn_ld4u_L2 1
#define HAVE_insn_ld1s_add_L2_32bit 1
#define HAVE_insn_ld1u_add_L2_32bit 1
#define HAVE_insn_ld1s_add_L2 1
#define HAVE_insn_ld1u_add_L2 1
#define HAVE_insn_ld2s_add_L2_32bit 1
#define HAVE_insn_ld2u_add_L2_32bit 1
#define HAVE_insn_ld2s_add_L2 1
#define HAVE_insn_ld2u_add_L2 1
#define HAVE_insn_ld4s_add_L2_32bit 1
#define HAVE_insn_ld4u_add_L2_32bit 1
#define HAVE_insn_ld4s_add_L2 1
#define HAVE_insn_ld4u_add_L2 1
#define HAVE_insn_ldnt_L2 1
#define HAVE_insn_ldnt_add_L2_32bit 1
#define HAVE_insn_ldnt_add_L2 1
#define HAVE_insn_ldnt1s_L2 1
#define HAVE_insn_ldnt1u_L2 1
#define HAVE_insn_ldnt2s_L2 1
#define HAVE_insn_ldnt2u_L2 1
#define HAVE_insn_ldnt4s_L2 1
#define HAVE_insn_ldnt4u_L2 1
#define HAVE_insn_ldnt1s_add_L2_32bit 1
#define HAVE_insn_ldnt1u_add_L2_32bit 1
#define HAVE_insn_ldnt1s_add_L2 1
#define HAVE_insn_ldnt1u_add_L2 1
#define HAVE_insn_ldnt2s_add_L2_32bit 1
#define HAVE_insn_ldnt2u_add_L2_32bit 1
#define HAVE_insn_ldnt2s_add_L2 1
#define HAVE_insn_ldnt2u_add_L2 1
#define HAVE_insn_ldnt4s_add_L2_32bit 1
#define HAVE_insn_ldnt4u_add_L2_32bit 1
#define HAVE_insn_ldnt4s_add_L2 1
#define HAVE_insn_ldnt4u_add_L2 1
#define HAVE_insn_ld_miss 1
#define HAVE_insn_ld_add_miss_32bit 1
#define HAVE_insn_ld_add_miss 1
#define HAVE_insn_ldna_miss 1
#define HAVE_insn_ldna_add_miss_32bit 1
#define HAVE_insn_ldna_add_miss 1
#define HAVE_insn_ld1s_miss 1
#define HAVE_insn_ld1u_miss 1
#define HAVE_insn_ld2s_miss 1
#define HAVE_insn_ld2u_miss 1
#define HAVE_insn_ld4s_miss 1
#define HAVE_insn_ld4u_miss 1
#define HAVE_insn_ld1s_add_miss_32bit 1
#define HAVE_insn_ld1u_add_miss_32bit 1
#define HAVE_insn_ld1s_add_miss 1
#define HAVE_insn_ld1u_add_miss 1
#define HAVE_insn_ld2s_add_miss_32bit 1
#define HAVE_insn_ld2u_add_miss_32bit 1
#define HAVE_insn_ld2s_add_miss 1
#define HAVE_insn_ld2u_add_miss 1
#define HAVE_insn_ld4s_add_miss_32bit 1
#define HAVE_insn_ld4u_add_miss_32bit 1
#define HAVE_insn_ld4s_add_miss 1
#define HAVE_insn_ld4u_add_miss 1
#define HAVE_insn_ldnt_miss 1
#define HAVE_insn_ldnt_add_miss_32bit 1
#define HAVE_insn_ldnt_add_miss 1
#define HAVE_insn_ldnt1s_miss 1
#define HAVE_insn_ldnt1u_miss 1
#define HAVE_insn_ldnt2s_miss 1
#define HAVE_insn_ldnt2u_miss 1
#define HAVE_insn_ldnt4s_miss 1
#define HAVE_insn_ldnt4u_miss 1
#define HAVE_insn_ldnt1s_add_miss_32bit 1
#define HAVE_insn_ldnt1u_add_miss_32bit 1
#define HAVE_insn_ldnt1s_add_miss 1
#define HAVE_insn_ldnt1u_add_miss 1
#define HAVE_insn_ldnt2s_add_miss_32bit 1
#define HAVE_insn_ldnt2u_add_miss_32bit 1
#define HAVE_insn_ldnt2s_add_miss 1
#define HAVE_insn_ldnt2u_add_miss 1
#define HAVE_insn_ldnt4s_add_miss_32bit 1
#define HAVE_insn_ldnt4u_add_miss_32bit 1
#define HAVE_insn_ldnt4s_add_miss 1
#define HAVE_insn_ldnt4u_add_miss 1
#define HAVE_insn_lnk 1
#define HAVE_insn_mfspr 1
#define HAVE_insn_mtspr 1
#define HAVE_insn_mm 1
#define HAVE_insn_mul_hs_hs 1
#define HAVE_insn_mul_hs_hu 1
#define HAVE_insn_mul_hs_ls 1
#define HAVE_insn_mul_hs_lu 1
#define HAVE_insn_mul_hu_hu 1
#define HAVE_insn_mul_hu_ls 1
#define HAVE_insn_mul_hu_lu 1
#define HAVE_insn_mul_ls_ls 1
#define HAVE_insn_mul_ls_lu 1
#define HAVE_insn_mul_lu_lu 1
#define HAVE_insn_mula_hs_hs 1
#define HAVE_insn_mula_hs_hu 1
#define HAVE_insn_mula_hs_ls 1
#define HAVE_insn_mula_hs_lu 1
#define HAVE_insn_mula_hu_hu 1
#define HAVE_insn_mula_hu_ls 1
#define HAVE_insn_mula_hu_lu 1
#define HAVE_insn_mula_ls_ls 1
#define HAVE_insn_mula_ls_lu 1
#define HAVE_insn_mula_lu_lu 1
#define HAVE_insn_mulax 1
#define HAVE_insn_nap 1
#define HAVE_insn_nor_si 1
#define HAVE_insn_nor_di 1
#define HAVE_insn_prefetch_l1_fault 1
#define HAVE_insn_prefetch_l2_fault 1
#define HAVE_insn_prefetch_l3_fault 1
#define HAVE_insn_revbits 1
#define HAVE_insn_shl1add 1
#define HAVE_insn_shl1addx 1
#define HAVE_insn_shl2add 1
#define HAVE_insn_shl2addx 1
#define HAVE_insn_shl3add 1
#define HAVE_insn_shl3addx 1
#define HAVE_insn_shufflebytes 1
#define HAVE_insn_shufflebytes1 1
#define HAVE_insn_st_add_32bit 1
#define HAVE_insn_st_add 1
#define HAVE_insn_stnt 1
#define HAVE_insn_stnt_add_32bit 1
#define HAVE_insn_stnt_add 1
#define HAVE_insn_tblidxb0 1
#define HAVE_insn_tblidxb1 1
#define HAVE_insn_tblidxb2 1
#define HAVE_insn_tblidxb3 1
#define HAVE_addv8qi3 1
#define HAVE_umaxv8qi3 1
#define HAVE_uminv8qi3 1
#define HAVE_seqv8qi3 1
#define HAVE_sltv8qi3 1
#define HAVE_sltuv8qi3 1
#define HAVE_ashlv8qi3 1
#define HAVE_ashrv8qi3 1
#define HAVE_lshrv8qi3 1
#define HAVE_addv4hi3 1
#define HAVE_smaxv4hi3 1
#define HAVE_sminv4hi3 1
#define HAVE_seqv4hi3 1
#define HAVE_sltv4hi3 1
#define HAVE_sltuv4hi3 1
#define HAVE_ashlv4hi3 1
#define HAVE_ashrv4hi3 1
#define HAVE_lshrv4hi3 1
#define HAVE_ussubv8qi3 1
#define HAVE_usaddv8qi3 1
#define HAVE_subv8qi3 1
#define HAVE_snev8qi3 1
#define HAVE_slev8qi3 1
#define HAVE_sleuv8qi3 1
#define HAVE_mulv8qi3 1
#define HAVE_sssubv4hi3 1
#define HAVE_ssaddv4hi3 1
#define HAVE_subv4hi3 1
#define HAVE_snev4hi3 1
#define HAVE_slev4hi3 1
#define HAVE_sleuv4hi3 1
#define HAVE_mulv4hi3 1
#define HAVE_ssashlv4hi3 1
#define HAVE_sssubv2si3 1
#define HAVE_ssaddv2si3 1
#define HAVE_subv2si3 1
#define HAVE_addv2si3 1
#define HAVE_ashlv2si3 1
#define HAVE_ashrv2si3 1
#define HAVE_lshrv2si3 1
#define HAVE_ssashlv2si3 1
#define HAVE_vec_interleave_highv8qi_be (BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_highv8qi_le (!BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_lowv8qi_be (BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_lowv8qi_le (!BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_highv4hi_be (BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_highv4hi_le (!BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_lowv4hi_be (BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_lowv4hi_le (!BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_highv2si_be (BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_highv2si_le (!BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_lowv2si_be (BYTES_BIG_ENDIAN)
#define HAVE_vec_interleave_lowv2si_le (!BYTES_BIG_ENDIAN)
#define HAVE_insn_mnz_v8qi 1
#define HAVE_insn_mz_v8qi 1
#define HAVE_insn_mnz_v4hi 1
#define HAVE_insn_mz_v4hi 1
#define HAVE_vec_widen_umult_lo_v8qi 1
#define HAVE_vec_widen_usmult_lo_v8qi 1
#define HAVE_vec_widen_smult_lo_v4qi 1
#define HAVE_vec_pack_trunc_v4hi 1
#define HAVE_vec_pack_usat_v4hi 1
#define HAVE_vec_pack_hipart_v4hi 1
#define HAVE_vec_pack_ssat_v2si 1
#define HAVE_insn_v1adiffu 1
#define HAVE_insn_v1avgu 1
#define HAVE_insn_v1ddotpu 1
#define HAVE_insn_v1ddotpua 1
#define HAVE_insn_v1ddotpus 1
#define HAVE_insn_v1ddotpusa 1
#define HAVE_insn_v1dotp 1
#define HAVE_insn_v1dotpa 1
#define HAVE_insn_v1dotpu 1
#define HAVE_insn_v1dotpua 1
#define HAVE_insn_v1dotpus 1
#define HAVE_insn_v1dotpusa 1
#define HAVE_insn_v1sadau 1
#define HAVE_insn_v1sadu 1
#define HAVE_insn_v2adiffs 1
#define HAVE_insn_v2avgs 1
#define HAVE_insn_v2dotp 1
#define HAVE_insn_v2dotpa 1
#define HAVE_insn_v2mulfsc 1
#define HAVE_insn_v2sadas 1
#define HAVE_insn_v2sadau 1
#define HAVE_insn_v2sads 1
#define HAVE_insn_v2sadu 1
#define HAVE_insn_wh64 1
#define HAVE_tilegx_network_barrier 1
#define HAVE_stack_protect_setsi 1
#define HAVE_stack_protect_setdi 1
#define HAVE_stack_protect_testsi 1
#define HAVE_stack_protect_testdi 1
#define HAVE_mtspr_cmpexchsi 1
#define HAVE_mtspr_cmpexchdi 1
#define HAVE_atomic_compare_and_swap_baresi 1
#define HAVE_atomic_compare_and_swap_baredi 1
#define HAVE_atomic_exchange_baresi 1
#define HAVE_atomic_exchange_baredi 1
#define HAVE_atomic_fetch_add_baresi 1
#define HAVE_atomic_fetch_or_baresi 1
#define HAVE_atomic_fetch_and_baresi 1
#define HAVE_atomic_fetch_add_baredi 1
#define HAVE_atomic_fetch_or_baredi 1
#define HAVE_atomic_fetch_and_baredi 1
#define HAVE_movqi 1
#define HAVE_movhi 1
#define HAVE_movsi 1
#define HAVE_movdi 1
#define HAVE_movmisalignv8qi 1
#define HAVE_movmisalignv4hi 1
#define HAVE_movmisalignv2si 1
#define HAVE_movsf 1
#define HAVE_movdf 1
#define HAVE_movv8qi 1
#define HAVE_movv4hi 1
#define HAVE_movv2si 1
#define HAVE_insv 1
#define HAVE_extv 1
#define HAVE_extzv 1
#define HAVE_mov_address_step1 1
#define HAVE_mov_address_step2 1
#define HAVE_mov_address_step3 1
#define HAVE_mov_address_32bit_step1 1
#define HAVE_mov_address_32bit_step2 1
#define HAVE_mov_pcrel_step1_32bit (flag_pic)
#define HAVE_mov_pcrel_step1 (flag_pic)
#define HAVE_mov_pcrel_step2_32bit (flag_pic)
#define HAVE_mov_pcrel_step2 (flag_pic)
#define HAVE_mov_large_pcrel_step1 (flag_pic)
#define HAVE_mov_large_pcrel_step2 (flag_pic)
#define HAVE_mov_large_pcrel_step3 (flag_pic)
#define HAVE_mov_plt_pcrel_step1 (flag_pic)
#define HAVE_mov_plt_pcrel_step2 (flag_pic)
#define HAVE_mov_plt_pcrel_step3 (flag_pic)
#define HAVE_mov_plt_pcrel_step1_32bit (flag_pic)
#define HAVE_mov_plt_pcrel_step2_32bit (flag_pic)
#define HAVE_add_got16_32bit (flag_pic == 1)
#define HAVE_add_got16 (flag_pic == 1)
#define HAVE_mov_got32_step1_32bit (flag_pic == 2)
#define HAVE_mov_got32_step1 (flag_pic == 2)
#define HAVE_mov_got32_step2_32bit (flag_pic == 2)
#define HAVE_mov_got32_step2 (flag_pic == 2)
#define HAVE_tls_gd_call_32bit 1
#define HAVE_tls_gd_call 1
#define HAVE_addsf3 1
#define HAVE_subsf3 1
#define HAVE_mulsf3 1
#define HAVE_adddf3 1
#define HAVE_subdf3 1
#define HAVE_muldf3 1
#define HAVE_cstoresf4 1
#define HAVE_cstoredf4 1
#define HAVE_cstoresi4 1
#define HAVE_cstoredi4 1
#define HAVE_clzsi2 1
#define HAVE_paritysi2 1
#define HAVE_paritydi2 1
#define HAVE_bswapsi2 1
#define HAVE_movsicc 1
#define HAVE_movdicc 1
#define HAVE_insn_mz 1
#define HAVE_insn_mnz 1
#define HAVE_insn_cmoveqz 1
#define HAVE_insn_cmovnez 1
#define HAVE_floatsisf2 1
#define HAVE_floatunssisf2 1
#define HAVE_floatsidf2 1
#define HAVE_floatunssidf2 1
#define HAVE_muldi3 1
#define HAVE_smulsi3_highpart 1
#define HAVE_umulsi3_highpart 1
#define HAVE_smuldi3_highpart 1
#define HAVE_umuldi3_highpart 1
#define HAVE_divsi3 1
#define HAVE_udivsi3 1
#define HAVE_doloop_end 1
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_allocate_stack 1
#define HAVE_call 1
#define HAVE_call_value 1
#define HAVE_sibcall 1
#define HAVE_sibcall_value 1
#define HAVE_return (tilegx_can_use_return_insn_p ())
#define HAVE_tablejump 1
#define HAVE_untyped_call 1
#define HAVE_cbranchsf4 1
#define HAVE_cbranchdf4 1
#define HAVE_cbranchsi4 1
#define HAVE_cbranchdi4 1
#define HAVE_memory_barrier 1
#define HAVE_insn_ld 1
#define HAVE_insn_ld1s 1
#define HAVE_insn_ld1u 1
#define HAVE_insn_ld2s 1
#define HAVE_insn_ld2u 1
#define HAVE_insn_ld4s 1
#define HAVE_insn_ld4u 1
#define HAVE_insn_prefetch_l1 1
#define HAVE_insn_prefetch_l2 1
#define HAVE_insn_prefetch_l3 1
#define HAVE_insn_st 1
#define HAVE_insn_st1 1
#define HAVE_insn_st2 1
#define HAVE_insn_st4 1
#define HAVE_insn_st1_add_32bit 1
#define HAVE_insn_st1_add 1
#define HAVE_insn_st2_add_32bit 1
#define HAVE_insn_st2_add 1
#define HAVE_insn_st4_add_32bit 1
#define HAVE_insn_st4_add 1
#define HAVE_insn_stnt1 1
#define HAVE_insn_stnt2 1
#define HAVE_insn_stnt4 1
#define HAVE_insn_stnt1_add_32bit 1
#define HAVE_insn_stnt1_add 1
#define HAVE_insn_stnt2_add_32bit 1
#define HAVE_insn_stnt2_add 1
#define HAVE_insn_stnt4_add_32bit 1
#define HAVE_insn_stnt4_add 1
#define HAVE_insn_v1add 1
#define HAVE_insn_v1maxu 1
#define HAVE_insn_v1minu 1
#define HAVE_insn_v1cmpeq 1
#define HAVE_insn_v1cmplts 1
#define HAVE_insn_v1cmpltu 1
#define HAVE_insn_v1addi 1
#define HAVE_insn_v1maxui 1
#define HAVE_insn_v1minui 1
#define HAVE_insn_v1cmpeqi 1
#define HAVE_insn_v1cmpltsi 1
#define HAVE_insn_v1cmpltui 1
#define HAVE_insn_v1shl 1
#define HAVE_insn_v1shrs 1
#define HAVE_insn_v1shru 1
#define HAVE_insn_v2add 1
#define HAVE_insn_v2maxs 1
#define HAVE_insn_v2mins 1
#define HAVE_insn_v2cmpeq 1
#define HAVE_insn_v2cmplts 1
#define HAVE_insn_v2cmpltu 1
#define HAVE_insn_v2addi 1
#define HAVE_insn_v2maxsi 1
#define HAVE_insn_v2minsi 1
#define HAVE_insn_v2cmpeqi 1
#define HAVE_insn_v2cmpltsi 1
#define HAVE_insn_v2cmpltui 1
#define HAVE_insn_v2shl 1
#define HAVE_insn_v2shrs 1
#define HAVE_insn_v2shru 1
#define HAVE_insn_v1subuc 1
#define HAVE_insn_v1adduc 1
#define HAVE_insn_v1sub 1
#define HAVE_insn_v1cmpne 1
#define HAVE_insn_v1cmples 1
#define HAVE_insn_v1cmpleu 1
#define HAVE_insn_v1multu 1
#define HAVE_insn_v2subsc 1
#define HAVE_insn_v2addsc 1
#define HAVE_insn_v2sub 1
#define HAVE_insn_v2cmpne 1
#define HAVE_insn_v2cmples 1
#define HAVE_insn_v2cmpleu 1
#define HAVE_insn_v2mults 1
#define HAVE_insn_v2shlsc 1
#define HAVE_insn_v4subsc 1
#define HAVE_insn_v4addsc 1
#define HAVE_insn_v4sub 1
#define HAVE_insn_v4add 1
#define HAVE_insn_v4shl 1
#define HAVE_insn_v4shrs 1
#define HAVE_insn_v4shru 1
#define HAVE_insn_v4shlsc 1
#define HAVE_vec_interleave_highv8qi 1
#define HAVE_insn_v1int_h 1
#define HAVE_vec_interleave_lowv8qi 1
#define HAVE_insn_v1int_l 1
#define HAVE_vec_interleave_highv4hi 1
#define HAVE_insn_v2int_h 1
#define HAVE_vec_interleave_lowv4hi 1
#define HAVE_insn_v2int_l 1
#define HAVE_vec_interleave_highv2si 1
#define HAVE_insn_v4int_h 1
#define HAVE_vec_interleave_lowv2si 1
#define HAVE_insn_v4int_l 1
#define HAVE_insn_v1mnz 1
#define HAVE_insn_v1mz 1
#define HAVE_insn_v2mnz 1
#define HAVE_insn_v2mz 1
#define HAVE_insn_v1mulu 1
#define HAVE_insn_v1mulus 1
#define HAVE_insn_v2muls 1
#define HAVE_insn_v2packl 1
#define HAVE_insn_v2packuc 1
#define HAVE_insn_v2packh 1
#define HAVE_insn_v4packsc 1
#define HAVE_tilegx_idn0_receive 1
#define HAVE_tilegx_idn1_receive 1
#define HAVE_tilegx_idn_send 1
#define HAVE_tilegx_udn0_receive 1
#define HAVE_tilegx_udn1_receive 1
#define HAVE_tilegx_udn2_receive 1
#define HAVE_tilegx_udn3_receive 1
#define HAVE_tilegx_udn_send 1
#define HAVE_stack_protect_set 1
#define HAVE_stack_protect_test 1
#define HAVE_atomic_compare_and_swapsi 1
#define HAVE_atomic_compare_and_swapdi 1
#define HAVE_atomic_exchangesi 1
#define HAVE_atomic_exchangedi 1
#define HAVE_atomic_fetch_addsi 1
#define HAVE_atomic_fetch_orsi 1
#define HAVE_atomic_fetch_andsi 1
#define HAVE_atomic_fetch_adddi 1
#define HAVE_atomic_fetch_ordi 1
#define HAVE_atomic_fetch_anddi 1
#define HAVE_atomic_fetch_subsi 1
#define HAVE_atomic_fetch_subdi 1
#define HAVE_atomic_test_and_set 1
extern rtx        gen_movstrictqi                    (rtx, rtx);
extern rtx        gen_movstricthi                    (rtx, rtx);
extern rtx        gen_movstrictsi                    (rtx, rtx);
extern rtx        gen_insn_lnk_and_label_32bit       (rtx, rtx);
extern rtx        gen_insn_lnk_and_label             (rtx, rtx);
extern rtx        gen_mov_pcrel_step3_32bit          (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_mov_pcrel_step3                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_mov_large_pcrel_step4          (rtx, rtx, rtx, rtx, rtx);
static inline rtx gen_tls_gd_add_32bit               (rtx, rtx, rtx);
static inline rtx
gen_tls_gd_add_32bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_tls_gd_add                     (rtx, rtx, rtx);
static inline rtx
gen_tls_gd_add(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_tls_add_32bit                  (rtx, rtx, rtx, rtx);
static inline rtx
gen_tls_add_32bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
static inline rtx gen_tls_add                        (rtx, rtx, rtx, rtx);
static inline rtx
gen_tls_add(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
static inline rtx gen_tls_ie_load_32bit              (rtx, rtx, rtx);
static inline rtx
gen_tls_ie_load_32bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_tls_ie_load                    (rtx, rtx, rtx);
static inline rtx
gen_tls_ie_load(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_addsi3                         (rtx, rtx, rtx);
extern rtx        gen_adddi3                         (rtx, rtx, rtx);
extern rtx        gen_subsi3                         (rtx, rtx, rtx);
extern rtx        gen_subdi3                         (rtx, rtx, rtx);
extern rtx        gen_negsi2                         (rtx, rtx);
extern rtx        gen_negdi2                         (rtx, rtx);
extern rtx        gen_ssaddsi3                       (rtx, rtx, rtx);
extern rtx        gen_sssubsi3                       (rtx, rtx, rtx);
extern rtx        gen_ashlsi3                        (rtx, rtx, rtx);
extern rtx        gen_ashldi3                        (rtx, rtx, rtx);
extern rtx        gen_ashrsi3                        (rtx, rtx, rtx);
extern rtx        gen_ashrdi3                        (rtx, rtx, rtx);
extern rtx        gen_lshrsi3                        (rtx, rtx, rtx);
extern rtx        gen_lshrdi3                        (rtx, rtx, rtx);
extern rtx        gen_rotldi3                        (rtx, rtx, rtx);
extern rtx        gen_insn_shl16insli                (rtx, rtx, rtx);
extern rtx        gen_insn_addr_shl16insli_32bit     (rtx, rtx, rtx);
extern rtx        gen_insn_addr_shl16insli           (rtx, rtx, rtx);
extern rtx        gen_insn_cmpne_sisi                (rtx, rtx, rtx);
extern rtx        gen_insn_cmpne_disi                (rtx, rtx, rtx);
extern rtx        gen_insn_cmpne_sidi                (rtx, rtx, rtx);
extern rtx        gen_insn_cmpne_didi                (rtx, rtx, rtx);
extern rtx        gen_insn_cmpeq_sisi                (rtx, rtx, rtx);
extern rtx        gen_insn_cmpeq_disi                (rtx, rtx, rtx);
extern rtx        gen_insn_cmpeq_sidi                (rtx, rtx, rtx);
extern rtx        gen_insn_cmpeq_didi                (rtx, rtx, rtx);
extern rtx        gen_insn_cmplts_sisi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmplts_disi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmplts_sidi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmplts_didi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmpltu_sisi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmpltu_disi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmpltu_sidi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmpltu_didi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmples_sisi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmples_disi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmples_sidi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmples_didi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmpleu_sisi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmpleu_disi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmpleu_sidi               (rtx, rtx, rtx);
extern rtx        gen_insn_cmpleu_didi               (rtx, rtx, rtx);
extern rtx        gen_andsi3                         (rtx, rtx, rtx);
extern rtx        gen_andv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_andv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_andv2si3                       (rtx, rtx, rtx);
extern rtx        gen_anddi3                         (rtx, rtx, rtx);
extern rtx        gen_iorsi3                         (rtx, rtx, rtx);
extern rtx        gen_iordi3                         (rtx, rtx, rtx);
extern rtx        gen_iorv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_iorv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_iorv2si3                       (rtx, rtx, rtx);
extern rtx        gen_xorsi3                         (rtx, rtx, rtx);
extern rtx        gen_xordi3                         (rtx, rtx, rtx);
extern rtx        gen_xorv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_xorv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_xorv2si3                       (rtx, rtx, rtx);
extern rtx        gen_clzdi2                         (rtx, rtx);
extern rtx        gen_ctzsi2                         (rtx, rtx);
extern rtx        gen_ctzdi2                         (rtx, rtx);
extern rtx        gen_popcountsi2                    (rtx, rtx);
extern rtx        gen_popcountdi2                    (rtx, rtx);
extern rtx        gen_bswapdi2                       (rtx, rtx);
extern rtx        gen_one_cmplsi2                    (rtx, rtx);
extern rtx        gen_one_cmpldi2                    (rtx, rtx);
extern rtx        gen_one_cmplv8qi2                  (rtx, rtx);
extern rtx        gen_one_cmplv4hi2                  (rtx, rtx);
extern rtx        gen_one_cmplv2si2                  (rtx, rtx);
extern rtx        gen_movcc_insn_sisi                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_movcc_insn_sidi                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_movcc_insn_disi                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_movcc_insn_didi                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_zero_extendqisi2               (rtx, rtx);
extern rtx        gen_zero_extendqidi2               (rtx, rtx);
extern rtx        gen_zero_extendhisi2               (rtx, rtx);
extern rtx        gen_zero_extendhidi2               (rtx, rtx);
extern rtx        gen_zero_extendsidi2               (rtx, rtx);
extern rtx        gen_extendqisi2                    (rtx, rtx);
extern rtx        gen_extendqidi2                    (rtx, rtx);
extern rtx        gen_extendhisi2                    (rtx, rtx);
extern rtx        gen_extendhidi2                    (rtx, rtx);
extern rtx        gen_extendsidi2                    (rtx, rtx);
extern rtx        gen_truncdisi2                     (rtx, rtx);
extern rtx        gen_truncdihi2                     (rtx, rtx);
extern rtx        gen_truncdiqi2                     (rtx, rtx);
extern rtx        gen_mulsi3                         (rtx, rtx, rtx);
extern rtx        gen_mulsidi3                       (rtx, rtx, rtx);
extern rtx        gen_umulsidi3                      (rtx, rtx, rtx);
extern rtx        gen_usmulsidi3                     (rtx, rtx, rtx);
extern rtx        gen_maddsidi4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_umaddsidi4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_jump                           (rtx);
extern rtx        gen_indirect_jump                  (rtx);
extern rtx        gen__return                        (void);
extern rtx        gen_tablejump_aux                  (rtx, rtx);
extern rtx        gen_blockage                       (void);
extern rtx        gen_sp_adjust                      (rtx, rtx, rtx);
extern rtx        gen_sp_adjust_32bit                (rtx, rtx, rtx);
extern rtx        gen_sp_restore_32bit               (rtx, rtx);
extern rtx        gen_sp_restore                     (rtx, rtx);
extern rtx        gen_nop                            (void);
extern rtx        gen_trap                           (void);
extern rtx        gen_prefetch                       (rtx, rtx, rtx);
extern rtx        gen_insn_bfexts                    (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_bfextu                    (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_bfins                     (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_insn_cmpexch4                  (rtx, rtx, rtx);
extern rtx        gen_insn_cmpexch                   (rtx, rtx, rtx);
extern rtx        gen_insn_cmul                      (rtx, rtx, rtx);
extern rtx        gen_insn_cmula                     (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_cmulaf                    (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_cmulf                     (rtx, rtx, rtx);
extern rtx        gen_insn_cmulfr                    (rtx, rtx, rtx);
extern rtx        gen_insn_cmulh                     (rtx, rtx, rtx);
extern rtx        gen_insn_cmulhr                    (rtx, rtx, rtx);
extern rtx        gen_insn_crc32_32                  (rtx, rtx, rtx);
extern rtx        gen_insn_crc32_8                   (rtx, rtx, rtx);
extern rtx        gen_insn_dblalign                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_dblalign2                 (rtx, rtx, rtx);
extern rtx        gen_insn_dblalign4                 (rtx, rtx, rtx);
extern rtx        gen_insn_dblalign6                 (rtx, rtx, rtx);
extern rtx        gen_insn_dtlbpr                    (rtx);
extern rtx        gen_insn_exch4                     (rtx, rtx, rtx);
extern rtx        gen_insn_exch                      (rtx, rtx, rtx);
extern rtx        gen_insn_fdouble_add_flags         (rtx, rtx, rtx);
extern rtx        gen_insn_fdouble_addsub            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_fdouble_mul_flags         (rtx, rtx, rtx);
extern rtx        gen_insn_fdouble_pack1             (rtx, rtx, rtx);
extern rtx        gen_insn_fdouble_pack2             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_fdouble_sub_flags         (rtx, rtx, rtx);
extern rtx        gen_insn_fdouble_unpack_max        (rtx, rtx, rtx);
extern rtx        gen_insn_fdouble_unpack_min        (rtx, rtx, rtx);
extern rtx        gen_insn_fetchadd4                 (rtx, rtx, rtx);
extern rtx        gen_insn_fetchadd                  (rtx, rtx, rtx);
extern rtx        gen_insn_fetchaddgez4              (rtx, rtx, rtx);
extern rtx        gen_insn_fetchaddgez               (rtx, rtx, rtx);
extern rtx        gen_insn_fetchand4                 (rtx, rtx, rtx);
extern rtx        gen_insn_fetchand                  (rtx, rtx, rtx);
extern rtx        gen_insn_fetchor4                  (rtx, rtx, rtx);
extern rtx        gen_insn_fetchor                   (rtx, rtx, rtx);
extern rtx        gen_insn_finv                      (rtx);
extern rtx        gen_insn_flush                     (rtx);
extern rtx        gen_insn_flushwb                   (void);
extern rtx        gen_insn_fnop                      (void);
extern rtx        gen_insn_fsingle_add1              (rtx, rtx, rtx);
extern rtx        gen_insn_fsingle_addsub2           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_fsingle_mul1              (rtx, rtx, rtx);
extern rtx        gen_insn_fsingle_mul2              (rtx, rtx, rtx);
extern rtx        gen_insn_fsingle_pack1             (rtx, rtx);
extern rtx        gen_insn_fsingle_pack2             (rtx, rtx, rtx);
extern rtx        gen_insn_fsingle_sub1              (rtx, rtx, rtx);
extern rtx        gen_insn_drain                     (void);
extern rtx        gen_insn_icoh                      (rtx);
extern rtx        gen_insn_ill                       (void);
extern rtx        gen_insn_info                      (rtx);
extern rtx        gen_insn_infol                     (rtx);
extern rtx        gen_insn_inv                       (rtx);
extern rtx        gen_insn_ld_add_32bit              (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld_add                    (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldna                      (rtx, rtx);
extern rtx        gen_insn_ldna_add_32bit            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldna_add                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1s_add_32bit            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1u_add_32bit            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1s_add                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1u_add                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2s_add_32bit            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2u_add_32bit            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2s_add                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2u_add                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4s_add_32bit            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4u_add_32bit            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4s_add                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4u_add                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt                      (rtx, rtx);
extern rtx        gen_insn_ldnt_add_32bit            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt_add                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1s                    (rtx, rtx);
extern rtx        gen_insn_ldnt1u                    (rtx, rtx);
extern rtx        gen_insn_ldnt2s                    (rtx, rtx);
extern rtx        gen_insn_ldnt2u                    (rtx, rtx);
extern rtx        gen_insn_ldnt4s                    (rtx, rtx);
extern rtx        gen_insn_ldnt4u                    (rtx, rtx);
extern rtx        gen_insn_ldnt1s_add_32bit          (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1u_add_32bit          (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1s_add                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1u_add                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2s_add_32bit          (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2u_add_32bit          (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2s_add                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2u_add                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4s_add_32bit          (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4u_add_32bit          (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4s_add                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4u_add                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld_L2                     (rtx, rtx);
extern rtx        gen_insn_ld_add_L2_32bit           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld_add_L2                 (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldna_L2                   (rtx, rtx);
extern rtx        gen_insn_ldna_add_L2_32bit         (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldna_add_L2               (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1s_L2                   (rtx, rtx);
extern rtx        gen_insn_ld1u_L2                   (rtx, rtx);
extern rtx        gen_insn_ld2s_L2                   (rtx, rtx);
extern rtx        gen_insn_ld2u_L2                   (rtx, rtx);
extern rtx        gen_insn_ld4s_L2                   (rtx, rtx);
extern rtx        gen_insn_ld4u_L2                   (rtx, rtx);
extern rtx        gen_insn_ld1s_add_L2_32bit         (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1u_add_L2_32bit         (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1s_add_L2               (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1u_add_L2               (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2s_add_L2_32bit         (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2u_add_L2_32bit         (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2s_add_L2               (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2u_add_L2               (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4s_add_L2_32bit         (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4u_add_L2_32bit         (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4s_add_L2               (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4u_add_L2               (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt_L2                   (rtx, rtx);
extern rtx        gen_insn_ldnt_add_L2_32bit         (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt_add_L2               (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1s_L2                 (rtx, rtx);
extern rtx        gen_insn_ldnt1u_L2                 (rtx, rtx);
extern rtx        gen_insn_ldnt2s_L2                 (rtx, rtx);
extern rtx        gen_insn_ldnt2u_L2                 (rtx, rtx);
extern rtx        gen_insn_ldnt4s_L2                 (rtx, rtx);
extern rtx        gen_insn_ldnt4u_L2                 (rtx, rtx);
extern rtx        gen_insn_ldnt1s_add_L2_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1u_add_L2_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1s_add_L2             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1u_add_L2             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2s_add_L2_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2u_add_L2_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2s_add_L2             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2u_add_L2             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4s_add_L2_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4u_add_L2_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4s_add_L2             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4u_add_L2             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld_miss                   (rtx, rtx);
extern rtx        gen_insn_ld_add_miss_32bit         (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld_add_miss               (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldna_miss                 (rtx, rtx);
extern rtx        gen_insn_ldna_add_miss_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldna_add_miss             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1s_miss                 (rtx, rtx);
extern rtx        gen_insn_ld1u_miss                 (rtx, rtx);
extern rtx        gen_insn_ld2s_miss                 (rtx, rtx);
extern rtx        gen_insn_ld2u_miss                 (rtx, rtx);
extern rtx        gen_insn_ld4s_miss                 (rtx, rtx);
extern rtx        gen_insn_ld4u_miss                 (rtx, rtx);
extern rtx        gen_insn_ld1s_add_miss_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1u_add_miss_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1s_add_miss             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld1u_add_miss             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2s_add_miss_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2u_add_miss_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2s_add_miss             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld2u_add_miss             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4s_add_miss_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4u_add_miss_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4s_add_miss             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ld4u_add_miss             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt_miss                 (rtx, rtx);
extern rtx        gen_insn_ldnt_add_miss_32bit       (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt_add_miss             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1s_miss               (rtx, rtx);
extern rtx        gen_insn_ldnt1u_miss               (rtx, rtx);
extern rtx        gen_insn_ldnt2s_miss               (rtx, rtx);
extern rtx        gen_insn_ldnt2u_miss               (rtx, rtx);
extern rtx        gen_insn_ldnt4s_miss               (rtx, rtx);
extern rtx        gen_insn_ldnt4u_miss               (rtx, rtx);
extern rtx        gen_insn_ldnt1s_add_miss_32bit     (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1u_add_miss_32bit     (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1s_add_miss           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt1u_add_miss           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2s_add_miss_32bit     (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2u_add_miss_32bit     (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2s_add_miss           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt2u_add_miss           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4s_add_miss_32bit     (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4u_add_miss_32bit     (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4s_add_miss           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_ldnt4u_add_miss           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_lnk                       (rtx);
extern rtx        gen_insn_mfspr                     (rtx, rtx);
extern rtx        gen_insn_mtspr                     (rtx, rtx);
extern rtx        gen_insn_mm                        (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mul_hs_hs                 (rtx, rtx, rtx);
extern rtx        gen_insn_mul_hs_hu                 (rtx, rtx, rtx);
extern rtx        gen_insn_mul_hs_ls                 (rtx, rtx, rtx);
extern rtx        gen_insn_mul_hs_lu                 (rtx, rtx, rtx);
extern rtx        gen_insn_mul_hu_hu                 (rtx, rtx, rtx);
extern rtx        gen_insn_mul_hu_ls                 (rtx, rtx, rtx);
extern rtx        gen_insn_mul_hu_lu                 (rtx, rtx, rtx);
extern rtx        gen_insn_mul_ls_ls                 (rtx, rtx, rtx);
extern rtx        gen_insn_mul_ls_lu                 (rtx, rtx, rtx);
extern rtx        gen_insn_mul_lu_lu                 (rtx, rtx, rtx);
extern rtx        gen_insn_mula_hs_hs                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mula_hs_hu                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mula_hs_ls                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mula_hs_lu                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mula_hu_hu                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mula_hu_ls                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mula_hu_lu                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mula_ls_ls                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mula_ls_lu                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mula_lu_lu                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mulax                     (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_nap                       (void);
extern rtx        gen_insn_nor_si                    (rtx, rtx, rtx);
extern rtx        gen_insn_nor_di                    (rtx, rtx, rtx);
extern rtx        gen_insn_prefetch_l1_fault         (rtx);
extern rtx        gen_insn_prefetch_l2_fault         (rtx);
extern rtx        gen_insn_prefetch_l3_fault         (rtx);
extern rtx        gen_insn_revbits                   (rtx, rtx);
extern rtx        gen_insn_shl1add                   (rtx, rtx, rtx);
extern rtx        gen_insn_shl1addx                  (rtx, rtx, rtx);
extern rtx        gen_insn_shl2add                   (rtx, rtx, rtx);
extern rtx        gen_insn_shl2addx                  (rtx, rtx, rtx);
extern rtx        gen_insn_shl3add                   (rtx, rtx, rtx);
extern rtx        gen_insn_shl3addx                  (rtx, rtx, rtx);
extern rtx        gen_insn_shufflebytes              (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_shufflebytes1             (rtx, rtx, rtx);
extern rtx        gen_insn_st_add_32bit              (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_st_add                    (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_stnt                      (rtx, rtx);
extern rtx        gen_insn_stnt_add_32bit            (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_stnt_add                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_tblidxb0                  (rtx, rtx, rtx);
extern rtx        gen_insn_tblidxb1                  (rtx, rtx, rtx);
extern rtx        gen_insn_tblidxb2                  (rtx, rtx, rtx);
extern rtx        gen_insn_tblidxb3                  (rtx, rtx, rtx);
extern rtx        gen_addv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_umaxv8qi3                      (rtx, rtx, rtx);
extern rtx        gen_uminv8qi3                      (rtx, rtx, rtx);
extern rtx        gen_seqv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_sltv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_sltuv8qi3                      (rtx, rtx, rtx);
extern rtx        gen_ashlv8qi3                      (rtx, rtx, rtx);
extern rtx        gen_ashrv8qi3                      (rtx, rtx, rtx);
extern rtx        gen_lshrv8qi3                      (rtx, rtx, rtx);
extern rtx        gen_addv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_smaxv4hi3                      (rtx, rtx, rtx);
extern rtx        gen_sminv4hi3                      (rtx, rtx, rtx);
extern rtx        gen_seqv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_sltv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_sltuv4hi3                      (rtx, rtx, rtx);
extern rtx        gen_ashlv4hi3                      (rtx, rtx, rtx);
extern rtx        gen_ashrv4hi3                      (rtx, rtx, rtx);
extern rtx        gen_lshrv4hi3                      (rtx, rtx, rtx);
extern rtx        gen_ussubv8qi3                     (rtx, rtx, rtx);
extern rtx        gen_usaddv8qi3                     (rtx, rtx, rtx);
extern rtx        gen_subv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_snev8qi3                       (rtx, rtx, rtx);
extern rtx        gen_slev8qi3                       (rtx, rtx, rtx);
extern rtx        gen_sleuv8qi3                      (rtx, rtx, rtx);
extern rtx        gen_mulv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_sssubv4hi3                     (rtx, rtx, rtx);
extern rtx        gen_ssaddv4hi3                     (rtx, rtx, rtx);
extern rtx        gen_subv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_snev4hi3                       (rtx, rtx, rtx);
extern rtx        gen_slev4hi3                       (rtx, rtx, rtx);
extern rtx        gen_sleuv4hi3                      (rtx, rtx, rtx);
extern rtx        gen_mulv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_ssashlv4hi3                    (rtx, rtx, rtx);
extern rtx        gen_sssubv2si3                     (rtx, rtx, rtx);
extern rtx        gen_ssaddv2si3                     (rtx, rtx, rtx);
extern rtx        gen_subv2si3                       (rtx, rtx, rtx);
extern rtx        gen_addv2si3                       (rtx, rtx, rtx);
extern rtx        gen_ashlv2si3                      (rtx, rtx, rtx);
extern rtx        gen_ashrv2si3                      (rtx, rtx, rtx);
extern rtx        gen_lshrv2si3                      (rtx, rtx, rtx);
extern rtx        gen_ssashlv2si3                    (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_highv8qi_be     (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_highv8qi_le     (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_lowv8qi_be      (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_lowv8qi_le      (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_highv4hi_be     (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_highv4hi_le     (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_lowv4hi_be      (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_lowv4hi_le      (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_highv2si_be     (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_highv2si_le     (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_lowv2si_be      (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_lowv2si_le      (rtx, rtx, rtx);
extern rtx        gen_insn_mnz_v8qi                  (rtx, rtx, rtx);
extern rtx        gen_insn_mz_v8qi                   (rtx, rtx, rtx);
extern rtx        gen_insn_mnz_v4hi                  (rtx, rtx, rtx);
extern rtx        gen_insn_mz_v4hi                   (rtx, rtx, rtx);
extern rtx        gen_vec_widen_umult_lo_v8qi        (rtx, rtx, rtx);
extern rtx        gen_vec_widen_usmult_lo_v8qi       (rtx, rtx, rtx);
extern rtx        gen_vec_widen_smult_lo_v4qi        (rtx, rtx, rtx);
extern rtx        gen_vec_pack_trunc_v4hi            (rtx, rtx, rtx);
extern rtx        gen_vec_pack_usat_v4hi             (rtx, rtx, rtx);
extern rtx        gen_vec_pack_hipart_v4hi           (rtx, rtx, rtx);
extern rtx        gen_vec_pack_ssat_v2si             (rtx, rtx, rtx);
extern rtx        gen_insn_v1adiffu                  (rtx, rtx, rtx);
extern rtx        gen_insn_v1avgu                    (rtx, rtx, rtx);
extern rtx        gen_insn_v1ddotpu                  (rtx, rtx, rtx);
extern rtx        gen_insn_v1ddotpua                 (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v1ddotpus                 (rtx, rtx, rtx);
extern rtx        gen_insn_v1ddotpusa                (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v1dotp                    (rtx, rtx, rtx);
extern rtx        gen_insn_v1dotpa                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v1dotpu                   (rtx, rtx, rtx);
extern rtx        gen_insn_v1dotpua                  (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v1dotpus                  (rtx, rtx, rtx);
extern rtx        gen_insn_v1dotpusa                 (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v1sadau                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v1sadu                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2adiffs                  (rtx, rtx, rtx);
extern rtx        gen_insn_v2avgs                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2dotp                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2dotpa                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v2mulfsc                  (rtx, rtx, rtx);
extern rtx        gen_insn_v2sadas                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v2sadau                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v2sads                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2sadu                    (rtx, rtx, rtx);
extern rtx        gen_insn_wh64                      (rtx);
extern rtx        gen_tilegx_network_barrier         (void);
extern rtx        gen_stack_protect_setsi            (rtx, rtx);
extern rtx        gen_stack_protect_setdi            (rtx, rtx);
extern rtx        gen_stack_protect_testsi           (rtx, rtx, rtx);
extern rtx        gen_stack_protect_testdi           (rtx, rtx, rtx);
extern rtx        gen_mtspr_cmpexchsi                (rtx);
extern rtx        gen_mtspr_cmpexchdi                (rtx);
extern rtx        gen_atomic_compare_and_swap_baresi (rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swap_baredi (rtx, rtx, rtx);
extern rtx        gen_atomic_exchange_baresi         (rtx, rtx, rtx);
extern rtx        gen_atomic_exchange_baredi         (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_add_baresi        (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_or_baresi         (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_and_baresi        (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_add_baredi        (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_or_baredi         (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_and_baredi        (rtx, rtx, rtx);
extern rtx        gen_movqi                          (rtx, rtx);
extern rtx        gen_movhi                          (rtx, rtx);
extern rtx        gen_movsi                          (rtx, rtx);
extern rtx        gen_movdi                          (rtx, rtx);
extern rtx        gen_movmisalignv8qi                (rtx, rtx);
extern rtx        gen_movmisalignv4hi                (rtx, rtx);
extern rtx        gen_movmisalignv2si                (rtx, rtx);
extern rtx        gen_movsf                          (rtx, rtx);
extern rtx        gen_movdf                          (rtx, rtx);
extern rtx        gen_movv8qi                        (rtx, rtx);
extern rtx        gen_movv4hi                        (rtx, rtx);
extern rtx        gen_movv2si                        (rtx, rtx);
extern rtx        gen_insv                           (rtx, rtx, rtx, rtx);
extern rtx        gen_extv                           (rtx, rtx, rtx, rtx);
extern rtx        gen_extzv                          (rtx, rtx, rtx, rtx);
extern rtx        gen_mov_address_step1              (rtx, rtx);
extern rtx        gen_mov_address_step2              (rtx, rtx, rtx);
extern rtx        gen_mov_address_step3              (rtx, rtx, rtx);
extern rtx        gen_mov_address_32bit_step1        (rtx, rtx);
extern rtx        gen_mov_address_32bit_step2        (rtx, rtx, rtx);
extern rtx        gen_mov_pcrel_step1_32bit          (rtx, rtx, rtx);
extern rtx        gen_mov_pcrel_step1                (rtx, rtx, rtx);
extern rtx        gen_mov_pcrel_step2_32bit          (rtx, rtx, rtx, rtx);
extern rtx        gen_mov_pcrel_step2                (rtx, rtx, rtx, rtx);
extern rtx        gen_mov_large_pcrel_step1          (rtx, rtx, rtx);
extern rtx        gen_mov_large_pcrel_step2          (rtx, rtx, rtx, rtx);
extern rtx        gen_mov_large_pcrel_step3          (rtx, rtx, rtx, rtx);
extern rtx        gen_mov_plt_pcrel_step1            (rtx, rtx, rtx);
extern rtx        gen_mov_plt_pcrel_step2            (rtx, rtx, rtx, rtx);
extern rtx        gen_mov_plt_pcrel_step3            (rtx, rtx, rtx, rtx);
extern rtx        gen_mov_plt_pcrel_step1_32bit      (rtx, rtx, rtx);
extern rtx        gen_mov_plt_pcrel_step2_32bit      (rtx, rtx, rtx, rtx);
extern rtx        gen_add_got16_32bit                (rtx, rtx, rtx);
extern rtx        gen_add_got16                      (rtx, rtx, rtx);
extern rtx        gen_mov_got32_step1_32bit          (rtx, rtx);
extern rtx        gen_mov_got32_step1                (rtx, rtx);
extern rtx        gen_mov_got32_step2_32bit          (rtx, rtx, rtx);
extern rtx        gen_mov_got32_step2                (rtx, rtx, rtx);
static inline rtx gen_mov_tls_gd_step1_32bit         (rtx, rtx);
static inline rtx
gen_mov_tls_gd_step1_32bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_mov_tls_gd_step1               (rtx, rtx);
static inline rtx
gen_mov_tls_gd_step1(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_mov_tls_gd_step2_32bit         (rtx, rtx, rtx);
static inline rtx
gen_mov_tls_gd_step2_32bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_mov_tls_gd_step2               (rtx, rtx, rtx);
static inline rtx
gen_mov_tls_gd_step2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_mov_tls_ie_step1_32bit         (rtx, rtx);
static inline rtx
gen_mov_tls_ie_step1_32bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_mov_tls_ie_step1               (rtx, rtx);
static inline rtx
gen_mov_tls_ie_step1(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_mov_tls_ie_step2_32bit         (rtx, rtx, rtx);
static inline rtx
gen_mov_tls_ie_step2_32bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_mov_tls_ie_step2               (rtx, rtx, rtx);
static inline rtx
gen_mov_tls_ie_step2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_mov_tls_le_step1_32bit         (rtx, rtx);
static inline rtx
gen_mov_tls_le_step1_32bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_mov_tls_le_step1               (rtx, rtx);
static inline rtx
gen_mov_tls_le_step1(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b))
{
  return 0;
}
static inline rtx gen_mov_tls_le_step2_32bit         (rtx, rtx, rtx);
static inline rtx
gen_mov_tls_le_step2_32bit(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
static inline rtx gen_mov_tls_le_step2               (rtx, rtx, rtx);
static inline rtx
gen_mov_tls_le_step2(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c))
{
  return 0;
}
extern rtx        gen_tls_gd_call_32bit              (rtx);
extern rtx        gen_tls_gd_call                    (rtx);
extern rtx        gen_addsf3                         (rtx, rtx, rtx);
extern rtx        gen_subsf3                         (rtx, rtx, rtx);
extern rtx        gen_mulsf3                         (rtx, rtx, rtx);
extern rtx        gen_adddf3                         (rtx, rtx, rtx);
extern rtx        gen_subdf3                         (rtx, rtx, rtx);
extern rtx        gen_muldf3                         (rtx, rtx, rtx);
extern rtx        gen_cstoresf4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredf4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresi4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredi4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_clzsi2                         (rtx, rtx);
extern rtx        gen_paritysi2                      (rtx, rtx);
extern rtx        gen_paritydi2                      (rtx, rtx);
extern rtx        gen_bswapsi2                       (rtx, rtx);
extern rtx        gen_movsicc                        (rtx, rtx, rtx, rtx);
extern rtx        gen_movdicc                        (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_mz                        (rtx, rtx, rtx);
extern rtx        gen_insn_mnz                       (rtx, rtx, rtx);
extern rtx        gen_insn_cmoveqz                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_cmovnez                   (rtx, rtx, rtx, rtx);
extern rtx        gen_floatsisf2                     (rtx, rtx);
extern rtx        gen_floatunssisf2                  (rtx, rtx);
extern rtx        gen_floatsidf2                     (rtx, rtx);
extern rtx        gen_floatunssidf2                  (rtx, rtx);
extern rtx        gen_muldi3                         (rtx, rtx, rtx);
extern rtx        gen_smulsi3_highpart               (rtx, rtx, rtx);
extern rtx        gen_umulsi3_highpart               (rtx, rtx, rtx);
extern rtx        gen_smuldi3_highpart               (rtx, rtx, rtx);
extern rtx        gen_umuldi3_highpart               (rtx, rtx, rtx);
extern rtx        gen_divsi3                         (rtx, rtx, rtx);
extern rtx        gen_udivsi3                        (rtx, rtx, rtx);
extern rtx        gen_doloop_end                     (rtx, rtx);
extern rtx        gen_prologue                       (void);
extern rtx        gen_epilogue                       (void);
extern rtx        gen_sibcall_epilogue               (void);
extern rtx        gen_allocate_stack                 (rtx, rtx);
extern rtx        gen_call                           (rtx, rtx);
extern rtx        gen_call_value                     (rtx, rtx, rtx);
extern rtx        gen_sibcall                        (rtx, rtx);
extern rtx        gen_sibcall_value                  (rtx, rtx, rtx);
extern rtx        gen_return                         (void);
extern rtx        gen_tablejump                      (rtx, rtx);
extern rtx        gen_untyped_call                   (rtx, rtx, rtx);
extern rtx        gen_cbranchsf4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdf4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsi4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdi4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_memory_barrier                 (void);
extern rtx        gen_insn_ld                        (rtx, rtx);
extern rtx        gen_insn_ld1s                      (rtx, rtx);
extern rtx        gen_insn_ld1u                      (rtx, rtx);
extern rtx        gen_insn_ld2s                      (rtx, rtx);
extern rtx        gen_insn_ld2u                      (rtx, rtx);
extern rtx        gen_insn_ld4s                      (rtx, rtx);
extern rtx        gen_insn_ld4u                      (rtx, rtx);
extern rtx        gen_insn_prefetch_l1               (rtx);
extern rtx        gen_insn_prefetch_l2               (rtx);
extern rtx        gen_insn_prefetch_l3               (rtx);
extern rtx        gen_insn_st                        (rtx, rtx);
extern rtx        gen_insn_st1                       (rtx, rtx);
extern rtx        gen_insn_st2                       (rtx, rtx);
extern rtx        gen_insn_st4                       (rtx, rtx);
extern rtx        gen_insn_st1_add_32bit             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_st1_add                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_st2_add_32bit             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_st2_add                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_st4_add_32bit             (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_st4_add                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_stnt1                     (rtx, rtx);
extern rtx        gen_insn_stnt2                     (rtx, rtx);
extern rtx        gen_insn_stnt4                     (rtx, rtx);
extern rtx        gen_insn_stnt1_add_32bit           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_stnt1_add                 (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_stnt2_add_32bit           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_stnt2_add                 (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_stnt4_add_32bit           (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_stnt4_add                 (rtx, rtx, rtx, rtx);
extern rtx        gen_insn_v1add                     (rtx, rtx, rtx);
extern rtx        gen_insn_v1maxu                    (rtx, rtx, rtx);
extern rtx        gen_insn_v1minu                    (rtx, rtx, rtx);
extern rtx        gen_insn_v1cmpeq                   (rtx, rtx, rtx);
extern rtx        gen_insn_v1cmplts                  (rtx, rtx, rtx);
extern rtx        gen_insn_v1cmpltu                  (rtx, rtx, rtx);
extern rtx        gen_insn_v1addi                    (rtx, rtx, rtx);
extern rtx        gen_insn_v1maxui                   (rtx, rtx, rtx);
extern rtx        gen_insn_v1minui                   (rtx, rtx, rtx);
extern rtx        gen_insn_v1cmpeqi                  (rtx, rtx, rtx);
extern rtx        gen_insn_v1cmpltsi                 (rtx, rtx, rtx);
extern rtx        gen_insn_v1cmpltui                 (rtx, rtx, rtx);
extern rtx        gen_insn_v1shl                     (rtx, rtx, rtx);
extern rtx        gen_insn_v1shrs                    (rtx, rtx, rtx);
extern rtx        gen_insn_v1shru                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2add                     (rtx, rtx, rtx);
extern rtx        gen_insn_v2maxs                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2mins                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2cmpeq                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2cmplts                  (rtx, rtx, rtx);
extern rtx        gen_insn_v2cmpltu                  (rtx, rtx, rtx);
extern rtx        gen_insn_v2addi                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2maxsi                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2minsi                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2cmpeqi                  (rtx, rtx, rtx);
extern rtx        gen_insn_v2cmpltsi                 (rtx, rtx, rtx);
extern rtx        gen_insn_v2cmpltui                 (rtx, rtx, rtx);
extern rtx        gen_insn_v2shl                     (rtx, rtx, rtx);
extern rtx        gen_insn_v2shrs                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2shru                    (rtx, rtx, rtx);
extern rtx        gen_insn_v1subuc                   (rtx, rtx, rtx);
extern rtx        gen_insn_v1adduc                   (rtx, rtx, rtx);
extern rtx        gen_insn_v1sub                     (rtx, rtx, rtx);
extern rtx        gen_insn_v1cmpne                   (rtx, rtx, rtx);
extern rtx        gen_insn_v1cmples                  (rtx, rtx, rtx);
extern rtx        gen_insn_v1cmpleu                  (rtx, rtx, rtx);
extern rtx        gen_insn_v1multu                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2subsc                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2addsc                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2sub                     (rtx, rtx, rtx);
extern rtx        gen_insn_v2cmpne                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2cmples                  (rtx, rtx, rtx);
extern rtx        gen_insn_v2cmpleu                  (rtx, rtx, rtx);
extern rtx        gen_insn_v2mults                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2shlsc                   (rtx, rtx, rtx);
extern rtx        gen_insn_v4subsc                   (rtx, rtx, rtx);
extern rtx        gen_insn_v4addsc                   (rtx, rtx, rtx);
extern rtx        gen_insn_v4sub                     (rtx, rtx, rtx);
extern rtx        gen_insn_v4add                     (rtx, rtx, rtx);
extern rtx        gen_insn_v4shl                     (rtx, rtx, rtx);
extern rtx        gen_insn_v4shrs                    (rtx, rtx, rtx);
extern rtx        gen_insn_v4shru                    (rtx, rtx, rtx);
extern rtx        gen_insn_v4shlsc                   (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_highv8qi        (rtx, rtx, rtx);
extern rtx        gen_insn_v1int_h                   (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_lowv8qi         (rtx, rtx, rtx);
extern rtx        gen_insn_v1int_l                   (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_highv4hi        (rtx, rtx, rtx);
extern rtx        gen_insn_v2int_h                   (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_lowv4hi         (rtx, rtx, rtx);
extern rtx        gen_insn_v2int_l                   (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_highv2si        (rtx, rtx, rtx);
extern rtx        gen_insn_v4int_h                   (rtx, rtx, rtx);
extern rtx        gen_vec_interleave_lowv2si         (rtx, rtx, rtx);
extern rtx        gen_insn_v4int_l                   (rtx, rtx, rtx);
extern rtx        gen_insn_v1mnz                     (rtx, rtx, rtx);
extern rtx        gen_insn_v1mz                      (rtx, rtx, rtx);
extern rtx        gen_insn_v2mnz                     (rtx, rtx, rtx);
extern rtx        gen_insn_v2mz                      (rtx, rtx, rtx);
extern rtx        gen_insn_v1mulu                    (rtx, rtx, rtx);
extern rtx        gen_insn_v1mulus                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2muls                    (rtx, rtx, rtx);
extern rtx        gen_insn_v2packl                   (rtx, rtx, rtx);
extern rtx        gen_insn_v2packuc                  (rtx, rtx, rtx);
extern rtx        gen_insn_v2packh                   (rtx, rtx, rtx);
extern rtx        gen_insn_v4packsc                  (rtx, rtx, rtx);
extern rtx        gen_tilegx_idn0_receive            (rtx);
extern rtx        gen_tilegx_idn1_receive            (rtx);
extern rtx        gen_tilegx_idn_send                (rtx);
extern rtx        gen_tilegx_udn0_receive            (rtx);
extern rtx        gen_tilegx_udn1_receive            (rtx);
extern rtx        gen_tilegx_udn2_receive            (rtx);
extern rtx        gen_tilegx_udn3_receive            (rtx);
extern rtx        gen_tilegx_udn_send                (rtx);
extern rtx        gen_stack_protect_set              (rtx, rtx);
extern rtx        gen_stack_protect_test             (rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapsi      (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapdi      (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangesi              (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangedi              (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addsi             (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orsi              (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andsi             (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_adddi             (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_ordi              (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_anddi             (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subsi             (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subdi             (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_test_and_set            (rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
