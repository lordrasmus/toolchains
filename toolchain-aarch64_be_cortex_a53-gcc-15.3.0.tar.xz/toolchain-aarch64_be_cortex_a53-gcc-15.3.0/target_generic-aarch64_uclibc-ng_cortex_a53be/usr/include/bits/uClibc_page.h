/*
 * Licensed under the LGPL v2.1 or later, see the file COPYING.LIB in this tarball.
 */

#ifndef _UCLIBC_PAGE_H
#define _UCLIBC_PAGE_H

/*
 * AARCH64 supports 4k, 16k, 64k pages (build time).
 */

#include <features.h>

#define PAGE_SHIFT		12


#endif /* _UCLIBC_PAGE_H */
