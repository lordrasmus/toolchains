/* Generated automatically by the program 'build/genpreds'
   from the machine description file '/home/ramin/openadk/toolchain_build_generic-alpha_uclibc-ng/w-gcc-11.4.0-1/gcc-11.4.0/gcc/config/alpha/alpha.md'.  */

#ifndef GCC_TM_PREDS_H
#define GCC_TM_PREDS_H

#ifdef HAVE_MACHINE_MODES
extern int general_operand (rtx, machine_mode);
extern int address_operand (rtx, machine_mode);
extern int register_operand (rtx, machine_mode);
extern int pmode_register_operand (rtx, machine_mode);
extern int scratch_operand (rtx, machine_mode);
extern int immediate_operand (rtx, machine_mode);
extern int const_int_operand (rtx, machine_mode);
extern int const_scalar_int_operand (rtx, machine_mode);
extern int const_double_operand (rtx, machine_mode);
extern int nonimmediate_operand (rtx, machine_mode);
extern int nonmemory_operand (rtx, machine_mode);
extern int push_operand (rtx, machine_mode);
extern int pop_operand (rtx, machine_mode);
extern int memory_operand (rtx, machine_mode);
extern int indirect_operand (rtx, machine_mode);
extern int ordered_comparison_operator (rtx, machine_mode);
extern int comparison_operator (rtx, machine_mode);
extern int const0_operand (rtx, machine_mode);
extern int reg_or_0_operand (rtx, machine_mode);
extern int reg_or_6bit_operand (rtx, machine_mode);
extern int cint8_operand (rtx, machine_mode);
extern int reg_or_8bit_operand (rtx, machine_mode);
extern int reg_or_cint_operand (rtx, machine_mode);
extern int add_operand (rtx, machine_mode);
extern int sext_add_operand (rtx, machine_mode);
extern int non_add_const_operand (rtx, machine_mode);
extern int non_zero_const_operand (rtx, machine_mode);
extern int const123_operand (rtx, machine_mode);
extern int const23_operand (rtx, machine_mode);
extern int const48_operand (rtx, machine_mode);
extern int and_operand (rtx, machine_mode);
extern int or_operand (rtx, machine_mode);
extern int mode_width_operand (rtx, machine_mode);
extern int mode_mask_operand (rtx, machine_mode);
extern int mul8_operand (rtx, machine_mode);
extern int hard_fp_register_operand (rtx, machine_mode);
extern int hard_int_register_operand (rtx, machine_mode);
extern int input_operand (rtx, machine_mode);
extern int samegp_function_operand (rtx, machine_mode);
extern int direct_call_operand (rtx, machine_mode);
extern int call_operand (rtx, machine_mode);
extern int local_symbolic_operand (rtx, machine_mode);
extern int small_symbolic_operand (rtx, machine_mode);
extern int global_symbolic_operand (rtx, machine_mode);
extern int symbolic_operand (rtx, machine_mode);
extern int dtp16_symbolic_operand (rtx, machine_mode);
extern int dtp32_symbolic_operand (rtx, machine_mode);
extern int gotdtp_symbolic_operand (rtx, machine_mode);
extern int tp16_symbolic_operand (rtx, machine_mode);
extern int tp32_symbolic_operand (rtx, machine_mode);
extern int gottp_symbolic_operand (rtx, machine_mode);
extern int aligned_memory_operand (rtx, machine_mode);
extern int unaligned_memory_operand (rtx, machine_mode);
extern int any_memory_operand (rtx, machine_mode);
extern int reg_not_elim_operand (rtx, machine_mode);
extern int reg_no_subreg_operand (rtx, machine_mode);
extern int alpha_cbranch_operator (rtx, machine_mode);
extern int alpha_comparison_operator (rtx, machine_mode);
extern int alpha_swapped_comparison_operator (rtx, machine_mode);
extern int alpha_zero_comparison_operator (rtx, machine_mode);
extern int signed_comparison_operator (rtx, machine_mode);
extern int alpha_fp_comparison_operator (rtx, machine_mode);
extern int divmod_operator (rtx, machine_mode);
extern int fix_operator (rtx, machine_mode);
extern int addition_operation (rtx, machine_mode);
extern int some_small_symbolic_operand (rtx, machine_mode);
extern int reg_or_bwx_memory_operand (rtx, machine_mode);
extern int mem_noofs_operand (rtx, machine_mode);
#endif /* HAVE_MACHINE_MODES */

#define CONSTRAINT_NUM_DEFINED_P 1
enum constraint_num
{
  CONSTRAINT__UNKNOWN = 0,
  CONSTRAINT_r,
  CONSTRAINT_a,
  CONSTRAINT_b,
  CONSTRAINT_c,
  CONSTRAINT_f,
  CONSTRAINT_v,
  CONSTRAINT_I,
  CONSTRAINT_J,
  CONSTRAINT_K,
  CONSTRAINT_L,
  CONSTRAINT_M,
  CONSTRAINT_N,
  CONSTRAINT_O,
  CONSTRAINT_P,
  CONSTRAINT_m,
  CONSTRAINT_o,
  CONSTRAINT_w,
  CONSTRAINT_Q,
  CONSTRAINT_p,
  CONSTRAINT_G,
  CONSTRAINT_R,
  CONSTRAINT_S,
  CONSTRAINT_T,
  CONSTRAINT_W,
  CONSTRAINT_V,
  CONSTRAINT__l,
  CONSTRAINT__g,
  CONSTRAINT_i,
  CONSTRAINT_s,
  CONSTRAINT_n,
  CONSTRAINT_E,
  CONSTRAINT_F,
  CONSTRAINT_X,
  CONSTRAINT__LIMIT
};

extern enum constraint_num lookup_constraint_1 (const char *);
extern const unsigned char lookup_constraint_array[];

/* Return the constraint at the beginning of P, or CONSTRAINT__UNKNOWN if it
   isn't recognized.  */

static inline enum constraint_num
lookup_constraint (const char *p)
{
  unsigned int index = lookup_constraint_array[(unsigned char) *p];
  return (index == UCHAR_MAX
          ? lookup_constraint_1 (p)
          : (enum constraint_num) index);
}

extern bool (*constraint_satisfied_p_array[]) (rtx);

/* Return true if X satisfies constraint C.  */

static inline bool
constraint_satisfied_p (rtx x, enum constraint_num c)
{
  int i = (int) c - (int) CONSTRAINT_I;
  return i >= 0 && constraint_satisfied_p_array[i] (x);
}

static inline bool
insn_extra_register_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_r && c <= CONSTRAINT_v;
}

static inline bool
insn_extra_memory_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_m && c <= CONSTRAINT_Q;
}

static inline bool
insn_extra_special_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_relaxed_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_address_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_p && c <= CONSTRAINT_p;
}

static inline void
insn_extra_constraint_allows_reg_mem (enum constraint_num c,
				      bool *allows_reg, bool *allows_mem)
{
  if (c >= CONSTRAINT_G && c <= CONSTRAINT_W)
    return;
  if (c >= CONSTRAINT_V && c <= CONSTRAINT__g)
    {
      *allows_mem = true;
      return;
    }
  (void) c;
  *allows_reg = true;
  *allows_mem = true;
}

#define CONSTRAINT_LEN(c_,s_) 1

extern enum reg_class reg_class_for_constraint_1 (enum constraint_num);

static inline enum reg_class
reg_class_for_constraint (enum constraint_num c)
{
  if (insn_extra_register_constraint (c))
    return reg_class_for_constraint_1 (c);
  return NO_REGS;
}

extern bool insn_const_int_ok_for_constraint (HOST_WIDE_INT, enum constraint_num);
#define CONST_OK_FOR_CONSTRAINT_P(v_,c_,s_) \
    insn_const_int_ok_for_constraint (v_, lookup_constraint (s_))

enum constraint_type
{
  CT_REGISTER,
  CT_CONST_INT,
  CT_MEMORY,
  CT_SPECIAL_MEMORY,
  CT_RELAXED_MEMORY,
  CT_ADDRESS,
  CT_FIXED_FORM
};

static inline enum constraint_type
get_constraint_type (enum constraint_num c)
{
  if (c >= CONSTRAINT_p)
    {
      if (c >= CONSTRAINT_G)
        return CT_FIXED_FORM;
      return CT_ADDRESS;
    }
  if (c >= CONSTRAINT_m)
    return CT_MEMORY;
  if (c >= CONSTRAINT_I)
    return CT_CONST_INT;
  return CT_REGISTER;
}
#endif /* tm-preds.h */
