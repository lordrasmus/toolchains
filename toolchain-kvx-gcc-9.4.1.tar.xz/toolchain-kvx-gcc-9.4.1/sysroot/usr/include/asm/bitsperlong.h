/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
/*
 * Copyright (C) 2017-2020 Kalray Inc.
 * Author: Clement Leger
 */

#ifndef _ASM_KVX_BITSPERLONG_H
#define _ASM_KVX_BITSPERLONG_H

#define __BITS_PER_LONG 64

#include <asm-generic/bitsperlong.h>

#endif /* _ASM_KVX_BITSPERLONG_H */
