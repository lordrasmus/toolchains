/* Generated automatically by the program 'build/genpreds'
   from the machine description file '/home/ramin/openadk/toolchain_build_generic-kvx_uclibc-ng/w-gcc-f98c17b1e78dd3a3da45c0ac1af7b105edf2bf66-1/gcc-f98c17b1e78dd3a3da45c0ac1af7b105edf2bf66/gcc/config/kvx/kvx.md'.  */

#ifndef GCC_TM_PREDS_H
#define GCC_TM_PREDS_H

#ifdef HAVE_MACHINE_MODES
extern int general_operand (rtx, machine_mode);
extern int address_operand (rtx, machine_mode);
extern int register_operand (rtx, machine_mode);
extern int pmode_register_operand (rtx, machine_mode);
extern int scratch_operand (rtx, machine_mode);
extern int immediate_operand (rtx, machine_mode);
extern int const_int_operand (rtx, machine_mode);
extern int const_double_operand (rtx, machine_mode);
extern int nonimmediate_operand (rtx, machine_mode);
extern int nonmemory_operand (rtx, machine_mode);
extern int push_operand (rtx, machine_mode);
extern int pop_operand (rtx, machine_mode);
extern int memory_operand (rtx, machine_mode);
extern int indirect_operand (rtx, machine_mode);
extern int ordered_comparison_operator (rtx, machine_mode);
extern int comparison_operator (rtx, machine_mode);
extern int const_zero_operand (rtx, machine_mode);
extern int const_mone_operand (rtx, machine_mode);
extern int const_float1_operand (rtx, machine_mode);
extern int reg_or_zero_operand (rtx, machine_mode);
extern int reg_or_float1_operand (rtx, machine_mode);
extern int kvx_mov_operand (rtx, machine_mode);
extern int rotate_operand (rtx, machine_mode);
extern int sat_shift_operand (rtx, machine_mode);
extern int sixbits_unsigned_operand (rtx, machine_mode);
extern int poweroftwo_6bits_immediate_operand (rtx, machine_mode);
extern int register_s32_operand (rtx, machine_mode);
extern int register_f32_operand (rtx, machine_mode);
extern int jump_operand (rtx, machine_mode);
extern int zero_comparison_operator (rtx, machine_mode);
extern int float_comparison_operator (rtx, machine_mode);
extern int kvx_r_s10_s37_s64_operand (rtx, machine_mode);
extern int kvx_r_any32_operand (rtx, machine_mode);
extern int symbolic_operand (rtx, machine_mode);
extern int kvx_symbol_operand (rtx, machine_mode);
extern int noxsaddr_operand (rtx, machine_mode);
extern int shouldbe_register_operand (rtx, machine_mode);
extern int system_register_operand (rtx, machine_mode);
extern int store_multiple_operation (rtx, machine_mode);
extern int load_multiple_operation (rtx, machine_mode);
extern int load_multiple_operation_uncached (rtx, machine_mode);
extern int kvx_register_pair_operand (rtx, machine_mode);
extern int kvx_nonimmediate_operand_pair (rtx, machine_mode);
extern int kvx_general_operand_pair (rtx, machine_mode);
extern int vec_or_scalar_immediate_operand (rtx, machine_mode);
extern int kvx_register_quad_operand (rtx, machine_mode);
extern int kvx_nonimmediate_operand_quad (rtx, machine_mode);
extern int kvx_general_operand_quad (rtx, machine_mode);
#endif /* HAVE_MACHINE_MODES */

#define CONSTRAINT_NUM_DEFINED_P 1
enum constraint_num
{
  CONSTRAINT__UNKNOWN = 0,
  CONSTRAINT_r,
  CONSTRAINT_RXX,
  CONSTRAINT_RYY,
  CONSTRAINT_I10,
  CONSTRAINT_I16,
  CONSTRAINT_I32,
  CONSTRAINT_I37,
  CONSTRAINT_I43,
  CONSTRAINT_m,
  CONSTRAINT_o,
  CONSTRAINT_a,
  CONSTRAINT_b,
  CONSTRAINT_u,
  CONSTRAINT_Cm,
  CONSTRAINT_Cb,
  CONSTRAINT_Ca,
  CONSTRAINT_Zm,
  CONSTRAINT_Zb,
  CONSTRAINT_Za,
  CONSTRAINT_p,
  CONSTRAINT_Aa,
  CONSTRAINT_Ab,
  CONSTRAINT_T,
  CONSTRAINT_U05,
  CONSTRAINT_U06,
  CONSTRAINT_H16,
  CONSTRAINT_H32,
  CONSTRAINT_H43,
  CONSTRAINT_v10,
  CONSTRAINT_v16,
  CONSTRAINT_v32,
  CONSTRAINT_v37,
  CONSTRAINT_v43,
  CONSTRAINT_vx2,
  CONSTRAINT_V,
  CONSTRAINT__l,
  CONSTRAINT__g,
  CONSTRAINT_i,
  CONSTRAINT_s,
  CONSTRAINT_n,
  CONSTRAINT_E,
  CONSTRAINT_F,
  CONSTRAINT_X,
  CONSTRAINT_S,
  CONSTRAINT_B32,
  CONSTRAINT_B37,
  CONSTRAINT__LIMIT
};

extern enum constraint_num lookup_constraint_1 (const char *);
extern const unsigned char lookup_constraint_array[];

/* Return the constraint at the beginning of P, or CONSTRAINT__UNKNOWN if it
   isn't recognized.  */

static inline enum constraint_num
lookup_constraint (const char *p)
{
  unsigned int index = lookup_constraint_array[(unsigned char) *p];
  return (index == UCHAR_MAX
          ? lookup_constraint_1 (p)
          : (enum constraint_num) index);
}

extern bool (*constraint_satisfied_p_array[]) (rtx);

/* Return true if X satisfies constraint C.  */

static inline bool
constraint_satisfied_p (rtx x, enum constraint_num c)
{
  int i = (int) c - (int) CONSTRAINT_I10;
  return i >= 0 && constraint_satisfied_p_array[i] (x);
}

static inline bool
insn_extra_register_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_r && c <= CONSTRAINT_RYY;
}

static inline bool
insn_extra_memory_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_m && c <= CONSTRAINT_Za;
}

static inline bool
insn_extra_special_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_address_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_p && c <= CONSTRAINT_Ab;
}

static inline void
insn_extra_constraint_allows_reg_mem (enum constraint_num c,
				      bool *allows_reg, bool *allows_mem)
{
  if (c >= CONSTRAINT_T && c <= CONSTRAINT_vx2)
    return;
  if (c >= CONSTRAINT_V && c <= CONSTRAINT__g)
    {
      *allows_mem = true;
      return;
    }
  (void) c;
  *allows_reg = true;
  *allows_mem = true;
}

static inline size_t
insn_constraint_len (char fc, const char *str ATTRIBUTE_UNUSED)
{
  switch (fc)
    {
    case 'A': return 2;
    case 'B': return 3;
    case 'C': return 2;
    case 'H': return 3;
    case 'I': return 3;
    case 'R': return 3;
    case 'U': return 3;
    case 'Z': return 2;
    case 'v': return 3;
    default: break;
    }
  return 1;
}

#define CONSTRAINT_LEN(c_,s_) insn_constraint_len (c_,s_)

extern enum reg_class reg_class_for_constraint_1 (enum constraint_num);

static inline enum reg_class
reg_class_for_constraint (enum constraint_num c)
{
  if (insn_extra_register_constraint (c))
    return reg_class_for_constraint_1 (c);
  return NO_REGS;
}

extern bool insn_const_int_ok_for_constraint (HOST_WIDE_INT, enum constraint_num);
#define CONST_OK_FOR_CONSTRAINT_P(v_,c_,s_) \
    insn_const_int_ok_for_constraint (v_, lookup_constraint (s_))

enum constraint_type
{
  CT_REGISTER,
  CT_CONST_INT,
  CT_MEMORY,
  CT_SPECIAL_MEMORY,
  CT_ADDRESS,
  CT_FIXED_FORM
};

static inline enum constraint_type
get_constraint_type (enum constraint_num c)
{
  if (c >= CONSTRAINT_p)
    {
      if (c >= CONSTRAINT_T)
        return CT_FIXED_FORM;
      return CT_ADDRESS;
    }
  if (c >= CONSTRAINT_m)
    return CT_MEMORY;
  if (c >= CONSTRAINT_I10)
    return CT_CONST_INT;
  return CT_REGISTER;
}
#endif /* tm-preds.h */
