/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_acswapw 1
#define HAVE_acswapd 1
#define HAVE_aladdw 1
#define HAVE_aladdd 1
#define HAVE_alclrw 1
#define HAVE_alclrd 1
#define HAVE_add_pcrel_si (Pmode == SImode)
#define HAVE_add_pcrel_di (Pmode == DImode)
#define HAVE_jump 1
#define HAVE_tablejump_real_si ((SImode == Pmode) && (Pmode == SImode))
#define HAVE_tablejump_real_di ((DImode == Pmode) && (Pmode == DImode))
#define HAVE_nop 1
#define HAVE_set_gotp_si (Pmode == SImode)
#define HAVE_set_gotp_di (Pmode == DImode)
#define HAVE_kvx_get 1
#define HAVE_kvx_wfxl 1
#define HAVE_kvx_wfxm 1
#define HAVE_kvx_syncgroup 1
#define HAVE_kvx_await 1
#define HAVE_kvx_barrier 1
#define HAVE_kvx_sleep 1
#define HAVE_kvx_stop 1
#define HAVE_kvx_waitit 1
#define HAVE_trap (kvx_have_stack_checking())
#define HAVE_ctrapsi4 (kvx_have_stack_checking())
#define HAVE_scall_si (Pmode == SImode)
#define HAVE_scall_di (Pmode == DImode)
#define HAVE_mos_dinval_scall 1
#define HAVE_mos_dflush_scall 1
#define HAVE_kvx_fence 1
#define HAVE_kvx_dinval 1
#define HAVE_kvx_iinval 1
#define HAVE_kvx_dinvall 1
#define HAVE_kvx_iinvals 1
#define HAVE_kvx_dtouchl 1
#define HAVE_prefetch 1
#define HAVE_kvx_dzerol_1 (KV3_1)
#define HAVE_kvx_tlbdinval 1
#define HAVE_kvx_tlbiinval 1
#define HAVE_kvx_tlbprobe 1
#define HAVE_kvx_tlbread 1
#define HAVE_kvx_tlbwrite 1
#define HAVE_lqu 1
#define HAVE_ldu 1
#define HAVE_lwzu 1
#define HAVE_lhsu 1
#define HAVE_lhzu 1
#define HAVE_lbsu 1
#define HAVE_lbzu 1
#define HAVE_extendqidi2 1
#define HAVE_extendhidi2 1
#define HAVE_extendsidi2 1
#define HAVE_zero_extendqidi2 1
#define HAVE_zero_extendhidi2 1
#define HAVE_zero_extendsidi2 1
#define HAVE_ret 1
#define HAVE_satd 1
#define HAVE_satud 1
#define HAVE_kvx_loopdo 1
#define HAVE_doloop_end_si 1
#define HAVE_doloop_end_di 1
#define HAVE_usaddsi3 1
#define HAVE_usadddi3 1
#define HAVE_ussubsi3 1
#define HAVE_ussubdi3 1
#define HAVE_ashlsi3 1
#define HAVE_ashldi3 1
#define HAVE_ssashlsi3 1
#define HAVE_ssashldi3 1
#define HAVE_usashlsi3 1
#define HAVE_usashldi3 1
#define HAVE_ashrsi3 1
#define HAVE_ashrdi3 1
#define HAVE_lshrsi3 1
#define HAVE_lshrdi3 1
#define HAVE_kvx_srsw 1
#define HAVE_kvx_srsd 1
#define HAVE_negsi2 1
#define HAVE_negdi2 1
#define HAVE_ssnegsi2 1
#define HAVE_ssnegdi2 1
#define HAVE_abssi2 1
#define HAVE_absdi2 1
#define HAVE_ssabssi2 1
#define HAVE_ssabsdi2 1
#define HAVE_abdsi3 1
#define HAVE_abddi3 1
#define HAVE_ssabdsi3 1
#define HAVE_ssabddi3 1
#define HAVE_extvsi 1
#define HAVE_extvdi 1
#define HAVE_extzvsi 1
#define HAVE_extzvdi 1
#define HAVE_insvsi 1
#define HAVE_insvdi 1
#define HAVE_addsi3 1
#define HAVE_ssaddsi3 1
#define HAVE_subsi3 1
#define HAVE_sssubsi3 1
#define HAVE_mulsi3 1
#define HAVE_mulsidi3 1
#define HAVE_umulsidi3 1
#define HAVE_usmulsidi3 1
#define HAVE_maddsisi4 1
#define HAVE_maddsidi4 1
#define HAVE_umaddsidi4 1
#define HAVE_usmaddsidi4 1
#define HAVE_msubsisi4 1
#define HAVE_msubsidi4 1
#define HAVE_umsubsidi4 1
#define HAVE_usmsubsidi4 1
#define HAVE_sminsi3 1
#define HAVE_smaxsi3 1
#define HAVE_uminsi3 1
#define HAVE_umaxsi3 1
#define HAVE_andsi3 1
#define HAVE_iorsi3 1
#define HAVE_xorsi3 1
#define HAVE_rotlsi3 1
#define HAVE_rotrsi3 1
#define HAVE_avgsi3_floor 1
#define HAVE_avgsi3_ceil 1
#define HAVE_uavgsi3_floor 1
#define HAVE_uavgsi3_ceil 1
#define HAVE_bswapsi2 1
#define HAVE_clrsbsi2 1
#define HAVE_clzsi2 1
#define HAVE_ctzsi2 1
#define HAVE_popcountsi2 1
#define HAVE_one_cmplsi2 1
#define HAVE_kvx_stsuw 1
#define HAVE_adddi3 1
#define HAVE_ssadddi3 1
#define HAVE_kvx_addcd 1
#define HAVE_subdi3 1
#define HAVE_sssubdi3 1
#define HAVE_kvx_sbfcd 1
#define HAVE_muldi3 1
#define HAVE_mulditi3 1
#define HAVE_umulditi3 1
#define HAVE_usmulditi3 1
#define HAVE_smuldi3_highpart 1
#define HAVE_umuldi3_highpart 1
#define HAVE_madddidi4 1
#define HAVE_maddditi4 1
#define HAVE_umaddditi4 1
#define HAVE_usmaddditi4 1
#define HAVE_msubdidi4 1
#define HAVE_msubditi4 1
#define HAVE_umsubditi4 1
#define HAVE_usmsubditi4 1
#define HAVE_smindi3 1
#define HAVE_smaxdi3 1
#define HAVE_umindi3 1
#define HAVE_umaxdi3 1
#define HAVE_anddi3 1
#define HAVE_iordi3 1
#define HAVE_xordi3 1
#define HAVE_rotldi3 1
#define HAVE_rotrdi3 1
#define HAVE_bswapdi2 1
#define HAVE_clrsbdi2 1
#define HAVE_clzdi2 1
#define HAVE_ctzdi2 1
#define HAVE_popcountdi2 1
#define HAVE_one_cmpldi2 1
#define HAVE_kvx_sbmm8 1
#define HAVE_kvx_sbmmt8 1
#define HAVE_kvx_stsud 1
#define HAVE_kvx_set 1
#define HAVE_addhf3 1
#define HAVE_kvx_faddh 1
#define HAVE_subhf3 1
#define HAVE_kvx_fsbfh 1
#define HAVE_mulhf3 1
#define HAVE_kvx_fmulh 1
#define HAVE_kvx_fmulhw 1
#define HAVE_fmahf4 1
#define HAVE_kvx_ffmah 1
#define HAVE_kvx_ffmahw 1
#define HAVE_fnmahf4 1
#define HAVE_kvx_ffmsh 1
#define HAVE_kvx_ffmshw 1
#define HAVE_fminhf3 1
#define HAVE_fmaxhf3 1
#define HAVE_neghf2 1
#define HAVE_abshf2 1
#define HAVE_kvx_getsignh 1
#define HAVE_kvx_setsignh 1
#define HAVE_extendhfsf2 1
#define HAVE_kvx_fwidenlhw 1
#define HAVE_kvx_fwidenmhw 1
#define HAVE_addsf3 1
#define HAVE_kvx_faddw 1
#define HAVE_subsf3 1
#define HAVE_kvx_fsbfw 1
#define HAVE_mulsf3 1
#define HAVE_kvx_fmulw 1
#define HAVE_kvx_fmulwd 1
#define HAVE_fmasf4 1
#define HAVE_kvx_ffmaw 1
#define HAVE_kvx_ffmawd 1
#define HAVE_fnmasf4 1
#define HAVE_kvx_ffmsw 1
#define HAVE_kvx_ffmswd 1
#define HAVE_fminsf3 1
#define HAVE_fmaxsf3 1
#define HAVE_negsf2 1
#define HAVE_abssf2 1
#define HAVE_kvx_getsignw 1
#define HAVE_kvx_setsignw 1
#define HAVE_floatsisf2 1
#define HAVE_kvx_floatw 1
#define HAVE_floatunssisf2 1
#define HAVE_kvx_floatuw 1
#define HAVE_fix_truncsfsi2 1
#define HAVE_kvx_fixedw 1
#define HAVE_fixuns_truncsfsi2 1
#define HAVE_kvx_fixeduw 1
#define HAVE_truncsfhf2 1
#define HAVE_kvx_fnarrowwh 1
#define HAVE_extendsfdf2 1
#define HAVE_kvx_frecw 1
#define HAVE_kvx_frsrw 1
#define HAVE_kvx_fcdivw_insn 1
#define HAVE_kvx_fsdivw_insn 1
#define HAVE_kvx_fsrecw 1
#define HAVE_kvx_fsrsrw 1
#define HAVE_adddf3 1
#define HAVE_kvx_faddd 1
#define HAVE_subdf3 1
#define HAVE_kvx_fsbfd 1
#define HAVE_muldf3 1
#define HAVE_kvx_fmuld 1
#define HAVE_fmadf4 1
#define HAVE_kvx_ffmad 1
#define HAVE_fnmadf4 1
#define HAVE_kvx_ffmsd 1
#define HAVE_fmindf3 1
#define HAVE_fmaxdf3 1
#define HAVE_negdf2 1
#define HAVE_absdf2 1
#define HAVE_kvx_getsignd 1
#define HAVE_kvx_setsignd 1
#define HAVE_floatdidf2 1
#define HAVE_kvx_floatd 1
#define HAVE_floatunsdidf2 1
#define HAVE_kvx_floatud 1
#define HAVE_fix_truncdfdi2 1
#define HAVE_kvx_fixedd 1
#define HAVE_fixuns_truncdfdi2 1
#define HAVE_kvx_fixedud 1
#define HAVE_truncdfsf2 1
#define HAVE_kvx_fcdivd_insn 1
#define HAVE_kvx_fsdivd_insn 1
#define HAVE_kvx_fsrecd 1
#define HAVE_kvx_fsrsrd 1
#define HAVE_kvx_lbz 1
#define HAVE_kvx_lbs 1
#define HAVE_kvx_lhz 1
#define HAVE_kvx_lhs 1
#define HAVE_kvx_lwz 1
#define HAVE_kvx_lws 1
#define HAVE_kvx_lhf 1
#define HAVE_kvx_lwf 1
#define HAVE_kvx_ld 1
#define HAVE_kvx_lq 1
#define HAVE_kvx_ldf 1
#define HAVE_kvx_selecthq 1
#define HAVE_kvx_selectwp 1
#define HAVE_addv4hi3 1
#define HAVE_addv2si3 1
#define HAVE_ssaddv4hi3 1
#define HAVE_ssaddv2si3 1
#define HAVE_usaddv4hi3 1
#define HAVE_usaddv2si3 1
#define HAVE_subv4hi3 1
#define HAVE_subv2si3 1
#define HAVE_sssubv4hi3 1
#define HAVE_sssubv2si3 1
#define HAVE_ussubv4hi3 1
#define HAVE_ussubv2si3 1
#define HAVE_mulv4hi3 1
#define HAVE_mulv2si3 1
#define HAVE_sminv4hi3 1
#define HAVE_sminv2si3 1
#define HAVE_smaxv4hi3 1
#define HAVE_smaxv2si3 1
#define HAVE_uminv4hi3 1
#define HAVE_uminv2si3 1
#define HAVE_umaxv4hi3 1
#define HAVE_umaxv2si3 1
#define HAVE_andv4hi3 1
#define HAVE_andv2si3 1
#define HAVE_iorv4hi3 1
#define HAVE_iorv2si3 1
#define HAVE_xorv4hi3 1
#define HAVE_xorv2si3 1
#define HAVE_maddv4hiv4hi4 1
#define HAVE_maddv2siv2si4 1
#define HAVE_msubv4hiv4hi4 1
#define HAVE_msubv2siv2si4 1
#define HAVE_ashlv4hi3 1
#define HAVE_ashlv2si3 1
#define HAVE_ssashlv4hi3 1
#define HAVE_ssashlv2si3 1
#define HAVE_usashlv4hi3 1
#define HAVE_usashlv2si3 1
#define HAVE_ashrv4hi3 1
#define HAVE_ashrv2si3 1
#define HAVE_lshrv4hi3 1
#define HAVE_lshrv2si3 1
#define HAVE_kvx_srshqs 1
#define HAVE_kvx_srswps 1
#define HAVE_avgv4hi3_floor 1
#define HAVE_avgv2si3_floor 1
#define HAVE_avgv4hi3_ceil 1
#define HAVE_avgv2si3_ceil 1
#define HAVE_uavgv4hi3_floor 1
#define HAVE_uavgv2si3_floor 1
#define HAVE_uavgv4hi3_ceil 1
#define HAVE_uavgv2si3_ceil 1
#define HAVE_negv4hi2 1
#define HAVE_negv2si2 1
#define HAVE_ssnegv4hi2 1
#define HAVE_ssnegv2si2 1
#define HAVE_absv4hi2 1
#define HAVE_absv2si2 1
#define HAVE_ssabsv4hi2 1
#define HAVE_ssabsv2si2 1
#define HAVE_clrsbv4hi2 1
#define HAVE_clrsbv2si2 1
#define HAVE_clzv4hi2 1
#define HAVE_clzv2si2 1
#define HAVE_ctzv4hi2 1
#define HAVE_ctzv2si2 1
#define HAVE_popcountv4hi2 1
#define HAVE_popcountv2si2 1
#define HAVE_one_cmplv4hi2 1
#define HAVE_one_cmplv2si2 1
#define HAVE_abdv4hi3 1
#define HAVE_abdv2si3 1
#define HAVE_ssabdv4hi3 1
#define HAVE_ssabdv2si3 1
#define HAVE__mulhwq 1
#define HAVE__mulwdp 1
#define HAVE__muluhwq 1
#define HAVE__muluwdp 1
#define HAVE__mulsuhwq 1
#define HAVE__mulsuwdp 1
#define HAVE__maddhwq 1
#define HAVE__maddwdp 1
#define HAVE__madduhwq 1
#define HAVE__madduwdp 1
#define HAVE__maddsuhwq 1
#define HAVE__maddsuwdp 1
#define HAVE__msbfhwq 1
#define HAVE__msbfwdp 1
#define HAVE__msbfuhwq 1
#define HAVE__msbfuwdp 1
#define HAVE__msbfsuhwq 1
#define HAVE__msbfsuwdp 1
#define HAVE_rotlv4hi3 1
#define HAVE_rotrv4hi3 1
#define HAVE_kvx_sxbho 1
#define HAVE_kvx_sxhwq 1
#define HAVE_maddv4hiv4si4 1
#define HAVE_umaddv4hiv4si4 1
#define HAVE_msubv4hiv4si4 1
#define HAVE_umsubv4hiv4si4 1
#define HAVE_rotlv2si3 1
#define HAVE_rotrv2si3 1
#define HAVE_kvx_conswp 1
#define HAVE_kvx_zxwdp 1
#define HAVE_kvx_sxwdp 1
#define HAVE_kvx_truncldw 1
#define HAVE_kvx_truncmdw 1
#define HAVE_kvx_fractldw 1
#define HAVE_kvx_selectho 1
#define HAVE_kvx_selectwq 1
#define HAVE_ashlv8hi3 1
#define HAVE_ashlv4si3 1
#define HAVE_ssashlv8hi3 1
#define HAVE_ssashlv4si3 1
#define HAVE_usashlv8hi3 1
#define HAVE_usashlv4si3 1
#define HAVE_ashrv8hi3 1
#define HAVE_ashrv4si3 1
#define HAVE_lshrv8hi3 1
#define HAVE_lshrv4si3 1
#define HAVE_kvx_srshos 1
#define HAVE_kvx_srswqs 1
#define HAVE_avgv8hi3_floor 1
#define HAVE_avgv4si3_floor 1
#define HAVE_avgv8hi3_ceil 1
#define HAVE_avgv4si3_ceil 1
#define HAVE_uavgv8hi3_floor 1
#define HAVE_uavgv4si3_floor 1
#define HAVE_uavgv8hi3_ceil 1
#define HAVE_uavgv4si3_ceil 1
#define HAVE__mulhwo 1
#define HAVE__mulwdq 1
#define HAVE__muluhwo 1
#define HAVE__muluwdq 1
#define HAVE__mulsuhwo 1
#define HAVE__mulsuwdq 1
#define HAVE__maddhwo 1
#define HAVE__maddwdq 1
#define HAVE__madduhwo 1
#define HAVE__madduwdq 1
#define HAVE__maddsuhwo 1
#define HAVE__maddsuwdq 1
#define HAVE__msbfhwo 1
#define HAVE__msbfwdq 1
#define HAVE__msbfuhwo 1
#define HAVE__msbfuwdq 1
#define HAVE__msbfsuhwo 1
#define HAVE__msbfsuwdq 1
#define HAVE_addv8hi3 1
#define HAVE_addv4si3 1
#define HAVE_addv2di3 1
#define HAVE_ssaddv8hi3 1
#define HAVE_ssaddv4si3 1
#define HAVE_ssaddv2di3 1
#define HAVE_usaddv8hi3 1
#define HAVE_usaddv4si3 1
#define HAVE_usaddv2di3 1
#define HAVE_subv8hi3 1
#define HAVE_subv4si3 1
#define HAVE_subv2di3 1
#define HAVE_sssubv8hi3 1
#define HAVE_sssubv4si3 1
#define HAVE_sssubv2di3 1
#define HAVE_ussubv8hi3 1
#define HAVE_ussubv4si3 1
#define HAVE_ussubv2di3 1
#define HAVE_sminv8hi3 1
#define HAVE_sminv4si3 1
#define HAVE_sminv2di3 1
#define HAVE_smaxv8hi3 1
#define HAVE_smaxv4si3 1
#define HAVE_smaxv2di3 1
#define HAVE_uminv8hi3 1
#define HAVE_uminv4si3 1
#define HAVE_uminv2di3 1
#define HAVE_umaxv8hi3 1
#define HAVE_umaxv4si3 1
#define HAVE_umaxv2di3 1
#define HAVE_andv8hi3 1
#define HAVE_andv4si3 1
#define HAVE_andv2di3 1
#define HAVE_iorv8hi3 1
#define HAVE_iorv4si3 1
#define HAVE_iorv2di3 1
#define HAVE_xorv8hi3 1
#define HAVE_xorv4si3 1
#define HAVE_xorv2di3 1
#define HAVE_maddv8hiv8hi4 1
#define HAVE_maddv4siv4si4 1
#define HAVE_maddv2div2di4 1
#define HAVE_msubv8hiv8hi4 1
#define HAVE_msubv4siv4si4 1
#define HAVE_msubv2div2di4 1
#define HAVE_negv8hi2 1
#define HAVE_negv4si2 1
#define HAVE_negv2di2 1
#define HAVE_ssnegv8hi2 1
#define HAVE_ssnegv4si2 1
#define HAVE_ssnegv2di2 1
#define HAVE_absv8hi2 1
#define HAVE_absv4si2 1
#define HAVE_absv2di2 1
#define HAVE_ssabsv8hi2 1
#define HAVE_ssabsv4si2 1
#define HAVE_ssabsv2di2 1
#define HAVE_clrsbv8hi2 1
#define HAVE_clrsbv4si2 1
#define HAVE_clrsbv2di2 1
#define HAVE_clzv8hi2 1
#define HAVE_clzv4si2 1
#define HAVE_clzv2di2 1
#define HAVE_ctzv8hi2 1
#define HAVE_ctzv4si2 1
#define HAVE_ctzv2di2 1
#define HAVE_popcountv8hi2 1
#define HAVE_popcountv4si2 1
#define HAVE_popcountv2di2 1
#define HAVE_one_cmplv8hi2 1
#define HAVE_one_cmplv4si2 1
#define HAVE_one_cmplv2di2 1
#define HAVE_abdv8hi3 1
#define HAVE_abdv4si3 1
#define HAVE_abdv2di3 1
#define HAVE_ssabdv8hi3 1
#define HAVE_ssabdv4si3 1
#define HAVE_ssabdv2di3 1
#define HAVE_mulv8hi3 1
#define HAVE_mulv2di3 1
#define HAVE_rotlv8hi3 1
#define HAVE_rotlv2di3 1
#define HAVE_rotrv8hi3 1
#define HAVE_rotrv2di3 1
#define HAVE_mulv4si3 1
#define HAVE_rotlv4si3 1
#define HAVE_rotrv4si3 1
#define HAVE_kvx_selectdp 1
#define HAVE_ashlv2di3 1
#define HAVE_ssashlv2di3 1
#define HAVE_usashlv2di3 1
#define HAVE_ashrv2di3 1
#define HAVE_lshrv2di3 1
#define HAVE_kvx_srsdps 1
#define HAVE_kvx_selecthx 1
#define HAVE_kvx_selectwo 1
#define HAVE_ashlv16hi3 1
#define HAVE_ashlv8si3 1
#define HAVE_ssashlv16hi3 1
#define HAVE_ssashlv8si3 1
#define HAVE_usashlv16hi3 1
#define HAVE_usashlv8si3 1
#define HAVE_ashrv16hi3 1
#define HAVE_ashrv8si3 1
#define HAVE_lshrv16hi3 1
#define HAVE_lshrv8si3 1
#define HAVE_kvx_srshxs 1
#define HAVE_kvx_srswos 1
#define HAVE_avgv16hi3_floor 1
#define HAVE_avgv8si3_floor 1
#define HAVE_avgv16hi3_ceil 1
#define HAVE_avgv8si3_ceil 1
#define HAVE_uavgv16hi3_floor 1
#define HAVE_uavgv8si3_floor 1
#define HAVE_uavgv16hi3_ceil 1
#define HAVE_uavgv8si3_ceil 1
#define HAVE_mulv16hi3 1
#define HAVE_mulv4di3 1
#define HAVE_addv16hi3 1
#define HAVE_addv8si3 1
#define HAVE_addv4di3 1
#define HAVE_ssaddv16hi3 1
#define HAVE_ssaddv8si3 1
#define HAVE_ssaddv4di3 1
#define HAVE_usaddv16hi3 1
#define HAVE_usaddv8si3 1
#define HAVE_usaddv4di3 1
#define HAVE_subv16hi3 1
#define HAVE_subv8si3 1
#define HAVE_subv4di3 1
#define HAVE_sssubv16hi3 1
#define HAVE_sssubv8si3 1
#define HAVE_sssubv4di3 1
#define HAVE_ussubv16hi3 1
#define HAVE_ussubv8si3 1
#define HAVE_ussubv4di3 1
#define HAVE_sminv16hi3 1
#define HAVE_sminv8si3 1
#define HAVE_sminv4di3 1
#define HAVE_smaxv16hi3 1
#define HAVE_smaxv8si3 1
#define HAVE_smaxv4di3 1
#define HAVE_uminv16hi3 1
#define HAVE_uminv8si3 1
#define HAVE_uminv4di3 1
#define HAVE_umaxv16hi3 1
#define HAVE_umaxv8si3 1
#define HAVE_umaxv4di3 1
#define HAVE_andv16hi3 1
#define HAVE_andv8si3 1
#define HAVE_andv4di3 1
#define HAVE_iorv16hi3 1
#define HAVE_iorv8si3 1
#define HAVE_iorv4di3 1
#define HAVE_xorv16hi3 1
#define HAVE_xorv8si3 1
#define HAVE_xorv4di3 1
#define HAVE_maddv16hiv16hi4 1
#define HAVE_maddv8siv8si4 1
#define HAVE_maddv4div4di4 1
#define HAVE_msubv16hiv16hi4 1
#define HAVE_msubv8siv8si4 1
#define HAVE_msubv4div4di4 1
#define HAVE_rotlv16hi3 1
#define HAVE_rotlv8si3 1
#define HAVE_rotlv4di3 1
#define HAVE_rotrv16hi3 1
#define HAVE_rotrv8si3 1
#define HAVE_rotrv4di3 1
#define HAVE_negv16hi2 1
#define HAVE_negv8si2 1
#define HAVE_negv4di2 1
#define HAVE_ssnegv16hi2 1
#define HAVE_ssnegv8si2 1
#define HAVE_ssnegv4di2 1
#define HAVE_absv16hi2 1
#define HAVE_absv8si2 1
#define HAVE_absv4di2 1
#define HAVE_ssabsv16hi2 1
#define HAVE_ssabsv8si2 1
#define HAVE_ssabsv4di2 1
#define HAVE_clrsbv16hi2 1
#define HAVE_clrsbv8si2 1
#define HAVE_clrsbv4di2 1
#define HAVE_clzv16hi2 1
#define HAVE_clzv8si2 1
#define HAVE_clzv4di2 1
#define HAVE_ctzv16hi2 1
#define HAVE_ctzv8si2 1
#define HAVE_ctzv4di2 1
#define HAVE_popcountv16hi2 1
#define HAVE_popcountv8si2 1
#define HAVE_popcountv4di2 1
#define HAVE_one_cmplv16hi2 1
#define HAVE_one_cmplv8si2 1
#define HAVE_one_cmplv4di2 1
#define HAVE_abdv16hi3 1
#define HAVE_abdv8si3 1
#define HAVE_abdv4di3 1
#define HAVE_ssabdv16hi3 1
#define HAVE_ssabdv8si3 1
#define HAVE_ssabdv4di3 1
#define HAVE_mulv8si3 1
#define HAVE_kvx_selectdq 1
#define HAVE_ashlv4di3 1
#define HAVE_ssashlv4di3 1
#define HAVE_usashlv4di3 1
#define HAVE_ashrv4di3 1
#define HAVE_lshrv4di3 1
#define HAVE_kvx_srsdqs 1
#define HAVE_kvx_selectfhq 1
#define HAVE_kvx_selectfwp 1
#define HAVE_addv4hf3 1
#define HAVE_addv2sf3 1
#define HAVE_kvx_faddhq 1
#define HAVE_kvx_faddwp 1
#define HAVE_subv4hf3 1
#define HAVE_subv2sf3 1
#define HAVE_kvx_fsbfhq 1
#define HAVE_kvx_fsbfwp 1
#define HAVE_mulv4hf3 1
#define HAVE_mulv2sf3 1
#define HAVE_kvx_fmulhq 1
#define HAVE_kvx_fmulwp 1
#define HAVE_fmav4hf4 1
#define HAVE_fmav2sf4 1
#define HAVE_kvx_ffmahq 1
#define HAVE_kvx_ffmawp 1
#define HAVE_fnmav4hf4 1
#define HAVE_fnmav2sf4 1
#define HAVE_kvx_ffmshq 1
#define HAVE_kvx_ffmswp 1
#define HAVE_fminv4hf3 1
#define HAVE_fminv2sf3 1
#define HAVE_fmaxv4hf3 1
#define HAVE_fmaxv2sf3 1
#define HAVE_negv4hf2 1
#define HAVE_negv2sf2 1
#define HAVE_absv4hf2 1
#define HAVE_absv2sf2 1
#define HAVE_kvx_fmulhwq 1
#define HAVE_kvx_fmulwdp 1
#define HAVE_kvx_ffmahwq 1
#define HAVE_kvx_ffmawdp 1
#define HAVE_kvx_ffmshwq 1
#define HAVE_kvx_ffmswdp 1
#define HAVE_kvx_fwidenhwq 1
#define HAVE_kvx_fwidenwdp 1
#define HAVE_kvx_fnarrowwhq 1
#define HAVE_kvx_fnarrowdwp 1
#define HAVE_kvx_fdot2w 1
#define HAVE_kvx_fdot2wd 1
#define HAVE_kvx_fdot2wdp 1
#define HAVE_kvx_fdot2wzp 1
#define HAVE_kvx_fmulwc 1
#define HAVE_floatv2siv2sf2 1
#define HAVE_kvx_floatwp 1
#define HAVE_floatunsv2siv2sf2 1
#define HAVE_kvx_floatuwp 1
#define HAVE_fix_truncv2sfv2si2 1
#define HAVE_kvx_fixedwp 1
#define HAVE_fixuns_truncv2sfv2si2 1
#define HAVE_kvx_fixeduwp 1
#define HAVE_extendv2sfv2df2 1
#define HAVE_kvx_fcdivwp_insn 1
#define HAVE_kvx_fsdivwp_insn 1
#define HAVE_kvx_fsrecwp 1
#define HAVE_kvx_fsrsrwp 1
#define HAVE_kvx_fconjwc 1
#define HAVE_kvx_fmm212w 1
#define HAVE_kvx_fmma212w 1
#define HAVE_kvx_fmms212w 1
#define HAVE_kvx_consfwp 1
#define HAVE_kvx_selectfho 1
#define HAVE_kvx_selectfwq 1
#define HAVE_fmav8hf4_1 (KV3_1)
#define HAVE_fmav4sf4_1 (KV3_1)
#define HAVE_fmav8hf4_2 (KV3_2)
#define HAVE_fmav4sf4_2 (KV3_2)
#define HAVE_kvx_ffmaho_1 (KV3_1)
#define HAVE_kvx_ffmawq_1 (KV3_1)
#define HAVE_kvx_ffmaho_2 (KV3_2)
#define HAVE_kvx_ffmawq_2 (KV3_2)
#define HAVE_fnmav8hf4_1 (KV3_1)
#define HAVE_fnmav4sf4_1 (KV3_1)
#define HAVE_fnmav8hf4_2 (KV3_2)
#define HAVE_fnmav4sf4_2 (KV3_2)
#define HAVE_kvx_ffmsho_1 (KV3_1)
#define HAVE_kvx_ffmswq_1 (KV3_1)
#define HAVE_kvx_ffmsho_2 (KV3_2)
#define HAVE_kvx_ffmswq_2 (KV3_2)
#define HAVE_fminv8hf3 1
#define HAVE_fminv4sf3 1
#define HAVE_fminv2df3 1
#define HAVE_fmaxv8hf3 1
#define HAVE_fmaxv4sf3 1
#define HAVE_fmaxv2df3 1
#define HAVE_negv8hf2 1
#define HAVE_negv4sf2 1
#define HAVE_negv2df2 1
#define HAVE_absv8hf2 1
#define HAVE_absv4sf2 1
#define HAVE_absv2df2 1
#define HAVE_kvx_fmulhwo 1
#define HAVE_kvx_fmulwdq 1
#define HAVE_kvx_ffmahwo 1
#define HAVE_kvx_ffmawdq 1
#define HAVE_kvx_ffmshwo 1
#define HAVE_kvx_ffmswdq 1
#define HAVE_addv8hf3_1 (KV3_1)
#define HAVE_addv8hf3_2 (KV3_2)
#define HAVE_kvx_faddho_1 (KV3_1)
#define HAVE_kvx_faddho_2 (KV3_2)
#define HAVE_subv8hf3_1 (KV3_1)
#define HAVE_subv8hf3_2 (KV3_2)
#define HAVE_kvx_fsbfho_1 (KV3_1)
#define HAVE_kvx_fsbfho_2 (KV3_2)
#define HAVE_mulv8hf3_1 (KV3_1)
#define HAVE_mulv8hf3_2 (KV3_2)
#define HAVE_kvx_fmulho_1 (KV3_1)
#define HAVE_kvx_fmulho_2 (KV3_2)
#define HAVE_kvx_fmulwcp_1 (KV3_1)
#define HAVE_kvx_fmulwcp_2 (KV3_2)
#define HAVE_addv4sf3 1
#define HAVE_kvx_faddwq 1
#define HAVE_subv4sf3 1
#define HAVE_kvx_fsbfwq 1
#define HAVE_mulv4sf3 1
#define HAVE_kvx_fmulwq 1
#define HAVE_floatv4siv4sf2 1
#define HAVE_kvx_floatwq 1
#define HAVE_floatunsv4siv4sf2 1
#define HAVE_kvx_floatuwq 1
#define HAVE_fix_truncv4sfv4si2 1
#define HAVE_kvx_fixedwq 1
#define HAVE_fixuns_truncv4sfv4si2 1
#define HAVE_kvx_fixeduwq 1
#define HAVE_kvx_fconjwcp 1
#define HAVE_kvx_selectfdp 1
#define HAVE_addv2df3 1
#define HAVE_kvx_fadddp 1
#define HAVE_subv2df3 1
#define HAVE_kvx_fsbfdp 1
#define HAVE_mulv2df3 1
#define HAVE_kvx_fmuldp 1
#define HAVE_fmav2df4 1
#define HAVE_kvx_ffmadp 1
#define HAVE_fnmav2df4 1
#define HAVE_kvx_ffmsdp 1
#define HAVE_floatv2div2df2 1
#define HAVE_kvx_floatdp 1
#define HAVE_floatunsv2div2df2 1
#define HAVE_kvx_floatudp 1
#define HAVE_fix_truncv2dfv2di2 1
#define HAVE_kvx_fixeddp 1
#define HAVE_fixuns_truncv2dfv2di2 1
#define HAVE_kvx_fixedudp 1
#define HAVE_kvx_fconjdc 1
#define HAVE_kvx_selectfhx 1
#define HAVE_kvx_selectfwo 1
#define HAVE_fmav16hf4 1
#define HAVE_fmav8sf4 1
#define HAVE_kvx_ffmahx 1
#define HAVE_kvx_ffmawo 1
#define HAVE_fnmav16hf4 1
#define HAVE_fnmav8sf4 1
#define HAVE_kvx_ffmshx 1
#define HAVE_kvx_ffmswo 1
#define HAVE_fminv16hf3 1
#define HAVE_fminv8sf3 1
#define HAVE_fminv4df3 1
#define HAVE_fmaxv16hf3 1
#define HAVE_fmaxv8sf3 1
#define HAVE_fmaxv4df3 1
#define HAVE_negv16hf2 1
#define HAVE_negv8sf2 1
#define HAVE_negv4df2 1
#define HAVE_absv16hf2 1
#define HAVE_absv8sf2 1
#define HAVE_absv4df2 1
#define HAVE_addv16hf3 1
#define HAVE_kvx_faddhx 1
#define HAVE_subv16hf3 1
#define HAVE_kvx_fsbfhx 1
#define HAVE_mulv16hf3 1
#define HAVE_kvx_fmulhx 1
#define HAVE_kvx_fmulwcq 1
#define HAVE_addv8sf3 1
#define HAVE_kvx_faddwo 1
#define HAVE_subv8sf3 1
#define HAVE_kvx_fsbfwo 1
#define HAVE_mulv8sf3 1
#define HAVE_kvx_fmulwo 1
#define HAVE_floatv8siv8sf2 1
#define HAVE_kvx_floatwo 1
#define HAVE_floatunsv8siv8sf2 1
#define HAVE_kvx_floatuwo 1
#define HAVE_fix_truncv8sfv8si2 1
#define HAVE_kvx_fixedwo 1
#define HAVE_fixuns_truncv8sfv8si2 1
#define HAVE_kvx_fixeduwo 1
#define HAVE_kvx_fconjwcq 1
#define HAVE_kvx_selectfdq 1
#define HAVE_addv4df3 1
#define HAVE_kvx_fadddq 1
#define HAVE_subv4df3 1
#define HAVE_kvx_fsbfdq 1
#define HAVE_mulv4df3 1
#define HAVE_kvx_fmuldq 1
#define HAVE_fmav4df4 1
#define HAVE_kvx_ffmadq 1
#define HAVE_fnmav4df4 1
#define HAVE_kvx_ffmsdq 1
#define HAVE_floatv4div4df2 1
#define HAVE_kvx_floatdq 1
#define HAVE_floatunsv4div4df2 1
#define HAVE_kvx_floatudq 1
#define HAVE_fix_truncv4dfv4di2 1
#define HAVE_kvx_fixeddq 1
#define HAVE_fixuns_truncv4dfv4di2 1
#define HAVE_kvx_fixedudq 1
#define HAVE_kvx_fconjdcp 1
#define HAVE_kvx_consbx 1
#define HAVE_kvx_consho 1
#define HAVE_kvx_conswq 1
#define HAVE_kvx_consfho 1
#define HAVE_kvx_consfwq 1
#define HAVE_kvx_consdp 1
#define HAVE_kvx_consfdp 1
#define HAVE_kvx_consbv 1
#define HAVE_kvx_conshx 1
#define HAVE_kvx_conswo 1
#define HAVE_kvx_consfhx 1
#define HAVE_kvx_consfwo 1
#define HAVE_kvx_consdq 1
#define HAVE_kvx_consfdq 1
#define HAVE_kvx_lbo 1
#define HAVE_kvx_lhq 1
#define HAVE_kvx_lfhq 1
#define HAVE_kvx_lwp 1
#define HAVE_kvx_lfwp 1
#define HAVE_kvx_sbo 1
#define HAVE_kvx_shq 1
#define HAVE_kvx_sfhq 1
#define HAVE_kvx_swp 1
#define HAVE_kvx_sfwp 1
#define HAVE_kvx_lbx 1
#define HAVE_kvx_lho 1
#define HAVE_kvx_lfho 1
#define HAVE_kvx_lwq 1
#define HAVE_kvx_ldp 1
#define HAVE_kvx_lfwq 1
#define HAVE_kvx_lfdp 1
#define HAVE_kvx_sbx 1
#define HAVE_kvx_sho 1
#define HAVE_kvx_sfho 1
#define HAVE_kvx_swq 1
#define HAVE_kvx_sdp 1
#define HAVE_kvx_sfwq 1
#define HAVE_kvx_sfdp 1
#define HAVE_kvx_lbv 1
#define HAVE_kvx_lhx 1
#define HAVE_kvx_lfhx 1
#define HAVE_kvx_lwo 1
#define HAVE_kvx_ldq 1
#define HAVE_kvx_lfwo 1
#define HAVE_kvx_lfdq 1
#define HAVE_kvx_sbv 1
#define HAVE_kvx_shx 1
#define HAVE_kvx_sfhx 1
#define HAVE_kvx_swo 1
#define HAVE_kvx_sdq 1
#define HAVE_kvx_sfwo 1
#define HAVE_kvx_sfdq 1
#define HAVE_kvx_lvo 1
#define HAVE_kvx_lvbv 1
#define HAVE_kvx_lvhx 1
#define HAVE_kvx_lvfhx 1
#define HAVE_kvx_lvwo 1
#define HAVE_kvx_lvdq 1
#define HAVE_kvx_lvfwo 1
#define HAVE_kvx_lvfdq 1
#define HAVE_kvx_svo 1
#define HAVE_kvx_svbv 1
#define HAVE_kvx_svhx 1
#define HAVE_kvx_svfhx 1
#define HAVE_kvx_svwo 1
#define HAVE_kvx_svdq 1
#define HAVE_kvx_svfwo 1
#define HAVE_kvx_svfdq 1
#define HAVE_kvx_movetoo 1
#define HAVE_kvx_movetobv 1
#define HAVE_kvx_movetohx 1
#define HAVE_kvx_movetofhx 1
#define HAVE_kvx_movetowo 1
#define HAVE_kvx_movetodq 1
#define HAVE_kvx_movetofwo 1
#define HAVE_kvx_movetofdq 1
#define HAVE_kvx_movefoo 1
#define HAVE_kvx_movefobv 1
#define HAVE_kvx_movefohx 1
#define HAVE_kvx_movefofhx 1
#define HAVE_kvx_movefowo 1
#define HAVE_kvx_movefodq 1
#define HAVE_kvx_movefofwo 1
#define HAVE_kvx_movefofdq 1
#define HAVE_kvx_swapvoo 1
#define HAVE_kvx_swapvobv 1
#define HAVE_kvx_swapvohx 1
#define HAVE_kvx_swapvofhx 1
#define HAVE_kvx_swapvowo 1
#define HAVE_kvx_swapvodq 1
#define HAVE_kvx_swapvofwo 1
#define HAVE_kvx_swapvofdq 1
#define HAVE_kvx_alignoo 1
#define HAVE_kvx_alignobv 1
#define HAVE_kvx_alignohx 1
#define HAVE_kvx_alignofhx 1
#define HAVE_kvx_alignowo 1
#define HAVE_kvx_alignodq 1
#define HAVE_kvx_alignofwo 1
#define HAVE_kvx_alignofdq 1
#define HAVE_kvx_alignv 1
#define HAVE_kvx_copyv 1
#define HAVE_kvx_mt4x4d 1
#define HAVE_kvx_mm4abw 1
#define HAVE_kvx_fmm4ahw0 1
#define HAVE_kvx_fmm4ahw1 1
#define HAVE_kvx_fmm4ahw2 1
#define HAVE_kvx_fmm4ahw3 1
#define HAVE_cstoresi4 1
#define HAVE_cstoredi4 1
#define HAVE_atomic_compare_and_swapsi 1
#define HAVE_atomic_compare_and_swapdi 1
#define HAVE_atomic_loadqi 1
#define HAVE_atomic_loadhi 1
#define HAVE_atomic_loadsi 1
#define HAVE_atomic_loaddi 1
#define HAVE_atomic_loadti 1
#define HAVE_atomic_storeqi 1
#define HAVE_atomic_storehi 1
#define HAVE_atomic_storesi 1
#define HAVE_atomic_storedi 1
#define HAVE_atomic_storeti 1
#define HAVE_atomic_exchangesi 1
#define HAVE_atomic_exchangedi 1
#define HAVE_atomic_addsi 1
#define HAVE_atomic_orsi 1
#define HAVE_atomic_xorsi 1
#define HAVE_atomic_subsi 1
#define HAVE_atomic_andsi 1
#define HAVE_atomic_nandsi 1
#define HAVE_atomic_adddi 1
#define HAVE_atomic_ordi 1
#define HAVE_atomic_xordi 1
#define HAVE_atomic_subdi 1
#define HAVE_atomic_anddi 1
#define HAVE_atomic_nanddi 1
#define HAVE_atomic_fetch_addsi 1
#define HAVE_atomic_fetch_orsi 1
#define HAVE_atomic_fetch_xorsi 1
#define HAVE_atomic_fetch_subsi 1
#define HAVE_atomic_fetch_andsi 1
#define HAVE_atomic_fetch_nandsi 1
#define HAVE_atomic_fetch_adddi 1
#define HAVE_atomic_fetch_ordi 1
#define HAVE_atomic_fetch_xordi 1
#define HAVE_atomic_fetch_subdi 1
#define HAVE_atomic_fetch_anddi 1
#define HAVE_atomic_fetch_nanddi 1
#define HAVE_atomic_add_fetchsi 1
#define HAVE_atomic_or_fetchsi 1
#define HAVE_atomic_xor_fetchsi 1
#define HAVE_atomic_sub_fetchsi 1
#define HAVE_atomic_and_fetchsi 1
#define HAVE_atomic_nand_fetchsi 1
#define HAVE_atomic_add_fetchdi 1
#define HAVE_atomic_or_fetchdi 1
#define HAVE_atomic_xor_fetchdi 1
#define HAVE_atomic_sub_fetchdi 1
#define HAVE_atomic_and_fetchdi 1
#define HAVE_atomic_nand_fetchdi 1
#define HAVE_atomic_test_and_set 1
#define HAVE_mem_thread_fence 1
#define HAVE_mem_signal_fence 1
#define HAVE_store_multiple 1
#define HAVE_load_multiple 1
#define HAVE_movqi 1
#define HAVE_movhi 1
#define HAVE_movhf 1
#define HAVE_movsi 1
#define HAVE_movsf 1
#define HAVE_movdi 1
#define HAVE_movdf 1
#define HAVE_indirect_jump 1
#define HAVE_tablejump (can_create_pseudo_p ())
#define HAVE_kvx_dzerol 1
#define HAVE_memory_barrier 1
#define HAVE_call 1
#define HAVE_call_value 1
#define HAVE_sibcall_value 1
#define HAVE_sibcall 1
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_untyped_call 1
#define HAVE_doloop_end (TARGET_HWLOOP)
#define HAVE_reload_in_gotoff_si ((flag_pic) && (Pmode == SImode))
#define HAVE_reload_in_gotoff_di ((flag_pic) && (Pmode == DImode))
#define HAVE_kvx_addw 1
#define HAVE_kvx_addd 1
#define HAVE_kvx_sbfw 1
#define HAVE_kvx_sbfd 1
#define HAVE_kvx_shlw 1
#define HAVE_kvx_shld 1
#define HAVE_kvx_shrw 1
#define HAVE_kvx_shrd 1
#define HAVE_kvx_negw 1
#define HAVE_kvx_negd 1
#define HAVE_kvx_absw 1
#define HAVE_kvx_absd 1
#define HAVE_kvx_abdw 1
#define HAVE_kvx_abdd 1
#define HAVE_kvx_bitcntw 1
#define HAVE_kvx_bitcntd 1
#define HAVE_divsi3 1
#define HAVE_kvx_avgw 1
#define HAVE_divdi3 1
#define HAVE_addti3 1
#define HAVE_subti3 1
#define HAVE_multi3 1
#define HAVE_divhf3 1
#define HAVE_copysignhf3 1
#define HAVE_floatsihf2 1
#define HAVE_floatdihf2 1
#define HAVE_floatunssihf2 1
#define HAVE_floatunsdihf2 1
#define HAVE_extendhfdf2 1
#define HAVE_divsf3 (flag_reciprocal_math || flag_unsafe_math_optimizations)
#define HAVE_copysignsf3 1
#define HAVE_sqrtsf2 (flag_reciprocal_math)
#define HAVE_recipsf2 1
#define HAVE_rsqrtsf2 1
#define HAVE_kvx_fcdivw 1
#define HAVE_kvx_fsdivw 1
#define HAVE_copysigndf3 1
#define HAVE_truncdfhf2 1
#define HAVE_kvx_fcdivd 1
#define HAVE_kvx_fsdivd 1
#define HAVE_movv8qi 1
#define HAVE_movv4hi 1
#define HAVE_movv4hf 1
#define HAVE_movv2si 1
#define HAVE_movv2sf 1
#define HAVE_movti 1
#define HAVE_movv16qi 1
#define HAVE_movv8hi 1
#define HAVE_movv8hf 1
#define HAVE_movv4si 1
#define HAVE_movv2di 1
#define HAVE_movv4sf 1
#define HAVE_movv2df 1
#define HAVE_movoi 1
#define HAVE_movv32qi 1
#define HAVE_movv16hi 1
#define HAVE_movv16hf 1
#define HAVE_movv8si 1
#define HAVE_movv4di 1
#define HAVE_movv8sf 1
#define HAVE_movv4df 1
#define HAVE_vec_setv8qi 1
#define HAVE_vec_setv4hi 1
#define HAVE_vec_setv4hf 1
#define HAVE_vec_setv2si 1
#define HAVE_vec_setv2sf 1
#define HAVE_vec_setv16qi 1
#define HAVE_vec_setv8hi 1
#define HAVE_vec_setv8hf 1
#define HAVE_vec_setv4si 1
#define HAVE_vec_setv2di 1
#define HAVE_vec_setv4sf 1
#define HAVE_vec_setv2df 1
#define HAVE_vec_setv32qi 1
#define HAVE_vec_setv16hi 1
#define HAVE_vec_setv16hf 1
#define HAVE_vec_setv8si 1
#define HAVE_vec_setv4di 1
#define HAVE_vec_setv8sf 1
#define HAVE_vec_setv4df 1
#define HAVE_vec_extractv8qi 1
#define HAVE_vec_extractv4hi 1
#define HAVE_vec_extractv4hf 1
#define HAVE_vec_extractv2si 1
#define HAVE_vec_extractv2sf 1
#define HAVE_vec_extractv16qi 1
#define HAVE_vec_extractv8hi 1
#define HAVE_vec_extractv8hf 1
#define HAVE_vec_extractv4si 1
#define HAVE_vec_extractv2di 1
#define HAVE_vec_extractv4sf 1
#define HAVE_vec_extractv2df 1
#define HAVE_vec_extractv32qi 1
#define HAVE_vec_extractv16hi 1
#define HAVE_vec_extractv16hf 1
#define HAVE_vec_extractv8si 1
#define HAVE_vec_extractv4di 1
#define HAVE_vec_extractv8sf 1
#define HAVE_vec_extractv4df 1
#define HAVE_vec_initv8qi 1
#define HAVE_vec_initv4hi 1
#define HAVE_vec_initv4hf 1
#define HAVE_vec_initv2si 1
#define HAVE_vec_initv2sf 1
#define HAVE_vec_initv16qi 1
#define HAVE_vec_initv8hi 1
#define HAVE_vec_initv8hf 1
#define HAVE_vec_initv4si 1
#define HAVE_vec_initv2di 1
#define HAVE_vec_initv4sf 1
#define HAVE_vec_initv2df 1
#define HAVE_vec_initv32qi 1
#define HAVE_vec_initv16hi 1
#define HAVE_vec_initv16hf 1
#define HAVE_vec_initv8si 1
#define HAVE_vec_initv4di 1
#define HAVE_vec_initv8sf 1
#define HAVE_vec_initv4df 1
#define HAVE_vec_cmpv4hiv4hi 1
#define HAVE_vec_cmpv4hfv4hi 1
#define HAVE_vec_cmpv2siv2si 1
#define HAVE_vec_cmpv2sfv2si 1
#define HAVE_vec_cmpv8hiv8hi 1
#define HAVE_vec_cmpv8hfv8hi 1
#define HAVE_vec_cmpv4siv4si 1
#define HAVE_vec_cmpv2div2di 1
#define HAVE_vec_cmpv4sfv4si 1
#define HAVE_vec_cmpv2dfv2di 1
#define HAVE_vec_cmpv16hiv16hi 1
#define HAVE_vec_cmpv16hfv16hi 1
#define HAVE_vec_cmpv8siv8si 1
#define HAVE_vec_cmpv4div4di 1
#define HAVE_vec_cmpv8sfv8si 1
#define HAVE_vec_cmpv4dfv4di 1
#define HAVE_vec_cmpuv4hiv4hi 1
#define HAVE_vec_cmpuv4hfv4hi 1
#define HAVE_vec_cmpuv2siv2si 1
#define HAVE_vec_cmpuv2sfv2si 1
#define HAVE_vec_cmpuv8hiv8hi 1
#define HAVE_vec_cmpuv8hfv8hi 1
#define HAVE_vec_cmpuv4siv4si 1
#define HAVE_vec_cmpuv2div2di 1
#define HAVE_vec_cmpuv4sfv4si 1
#define HAVE_vec_cmpuv2dfv2di 1
#define HAVE_vec_cmpuv16hiv16hi 1
#define HAVE_vec_cmpuv16hfv16hi 1
#define HAVE_vec_cmpuv8siv8si 1
#define HAVE_vec_cmpuv4div4di 1
#define HAVE_vec_cmpuv8sfv8si 1
#define HAVE_vec_cmpuv4dfv4di 1
#define HAVE_vcondv4hiv4hi ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv4hiv4hf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv4hiv2si ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv4hiv2sf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv4hiv8hi ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv4hiv8hf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv4hiv4si ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv4hiv2di ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv4hiv4sf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv4hiv2df ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv4hiv16hi ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv4hiv16hf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv4hiv8si ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv4hiv4di ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv4hiv8sf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv4hiv4df ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv4hfv4hi ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv4hfv4hf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv4hfv2si ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv4hfv2sf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv4hfv8hi ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv4hfv8hf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv4hfv4si ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv4hfv2di ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv4hfv4sf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv4hfv2df ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv4hfv16hi ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv4hfv16hf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv4hfv8si ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv4hfv4di ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv4hfv8sf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv4hfv4df ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv2siv4hi ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv2siv4hf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv2siv2si ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv2siv2sf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv2siv8hi ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv2siv8hf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv2siv4si ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv2siv2di ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv2siv4sf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv2siv2df ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv2siv16hi ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv2siv16hf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv2siv8si ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv2siv4di ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv2siv8sf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv2siv4df ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv2sfv4hi ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv2sfv4hf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv2sfv2si ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv2sfv2sf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv2sfv8hi ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv2sfv8hf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv2sfv4si ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv2sfv2di ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv2sfv4sf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv2sfv2df ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv2sfv16hi ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv2sfv16hf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv2sfv8si ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv2sfv4di ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv2sfv8sf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv2sfv4df ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv8hiv4hi ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv8hiv4hf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv8hiv2si ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv8hiv2sf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv8hiv8hi ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv8hiv8hf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv8hiv4si ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv8hiv2di ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv8hiv4sf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv8hiv2df ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv8hiv16hi ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv8hiv16hf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv8hiv8si ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv8hiv4di ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv8hiv8sf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv8hiv4df ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv8hfv4hi ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv8hfv4hf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv8hfv2si ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv8hfv2sf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv8hfv8hi ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv8hfv8hf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv8hfv4si ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv8hfv2di ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv8hfv4sf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv8hfv2df ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv8hfv16hi ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv8hfv16hf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv8hfv8si ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv8hfv4di ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv8hfv8sf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv8hfv4df ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv4siv4hi ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv4siv4hf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv4siv2si ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv4siv2sf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv4siv8hi ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv4siv8hf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv4siv4si ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv4siv2di ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv4siv4sf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv4siv2df ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv4siv16hi ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv4siv16hf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv4siv8si ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv4siv4di ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv4siv8sf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv4siv4df ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv2div4hi ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv2div4hf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv2div2si ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv2div2sf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv2div8hi ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv2div8hf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv2div4si ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv2div2di ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv2div4sf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv2div2df ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv2div16hi ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv2div16hf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv2div8si ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv2div4di ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv2div8sf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv2div4df ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv4sfv4hi ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv4sfv4hf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv4sfv2si ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv4sfv2sf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv4sfv8hi ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv4sfv8hf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv4sfv4si ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv4sfv2di ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv4sfv4sf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv4sfv2df ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv4sfv16hi ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv4sfv16hf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv4sfv8si ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv4sfv4di ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv4sfv8sf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv4sfv4df ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv2dfv4hi ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv2dfv4hf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv2dfv2si ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv2dfv2sf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv2dfv8hi ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv2dfv8hf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv2dfv4si ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv2dfv2di ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv2dfv4sf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv2dfv2df ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv2dfv16hi ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv2dfv16hf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv2dfv8si ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv2dfv4di ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv2dfv8sf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv2dfv4df ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv16hiv4hi ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv16hiv4hf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv16hiv2si ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv16hiv2sf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv16hiv8hi ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv16hiv8hf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv16hiv4si ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv16hiv2di ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv16hiv4sf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv16hiv2df ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv16hiv16hi ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv16hiv16hf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv16hiv8si ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv16hiv4di ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv16hiv8sf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv16hiv4df ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv16hfv4hi ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv16hfv4hf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv16hfv2si ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv16hfv2sf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv16hfv8hi ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv16hfv8hf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv16hfv4si ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv16hfv2di ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv16hfv4sf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv16hfv2df ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv16hfv16hi ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv16hfv16hf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv16hfv8si ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv16hfv4di ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv16hfv8sf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv16hfv4df ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv8siv4hi ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv8siv4hf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv8siv2si ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv8siv2sf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv8siv8hi ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv8siv8hf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv8siv4si ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv8siv2di ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv8siv4sf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv8siv2df ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv8siv16hi ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv8siv16hf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv8siv8si ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv8siv4di ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv8siv8sf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv8siv4df ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv4div4hi ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv4div4hf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv4div2si ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv4div2sf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv4div8hi ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv4div8hf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv4div4si ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv4div2di ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv4div4sf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv4div2df ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv4div16hi ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv4div16hf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv4div8si ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv4div4di ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv4div8sf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv4div4df ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv8sfv4hi ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv8sfv4hf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv8sfv2si ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv8sfv2sf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv8sfv8hi ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv8sfv8hf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv8sfv4si ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv8sfv2di ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv8sfv4sf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv8sfv2df ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv8sfv16hi ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv8sfv16hf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv8sfv8si ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv8sfv4di ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv8sfv8sf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv8sfv4df ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcondv4dfv4hi ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vcondv4dfv4hf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vcondv4dfv2si ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vcondv4dfv2sf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vcondv4dfv8hi ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vcondv4dfv8hf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vcondv4dfv4si ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vcondv4dfv2di ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vcondv4dfv4sf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vcondv4dfv2df ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vcondv4dfv16hi ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vcondv4dfv16hf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vcondv4dfv8si ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vcondv4dfv4di ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vcondv4dfv8sf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vcondv4dfv4df ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv4hiv4hi ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv4hiv4hf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv4hiv2si ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv4hiv2sf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv4hiv8hi ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv4hiv8hf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv4hiv4si ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv4hiv2di ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv4hiv4sf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv4hiv2df ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv4hiv16hi ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv4hiv16hf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv4hiv8si ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv4hiv4di ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv4hiv8sf ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv4hiv4df ((GET_MODE_NUNITS (V4HImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv4hfv4hi ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv4hfv4hf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv4hfv2si ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv4hfv2sf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv4hfv8hi ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv4hfv8hf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv4hfv4si ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv4hfv2di ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv4hfv4sf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv4hfv2df ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv4hfv16hi ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv4hfv16hf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv4hfv8si ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv4hfv4di ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv4hfv8sf ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv4hfv4df ((GET_MODE_NUNITS (V4HFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv2siv4hi ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv2siv4hf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv2siv2si ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv2siv2sf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv2siv8hi ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv2siv8hf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv2siv4si ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv2siv2di ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv2siv4sf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv2siv2df ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv2siv16hi ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv2siv16hf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv2siv8si ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv2siv4di ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv2siv8sf ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv2siv4df ((GET_MODE_NUNITS (V2SImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv2sfv4hi ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv2sfv4hf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv2sfv2si ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv2sfv2sf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv2sfv8hi ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv2sfv8hf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv2sfv4si ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv2sfv2di ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv2sfv4sf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv2sfv2df ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv2sfv16hi ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv2sfv16hf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv2sfv8si ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv2sfv4di ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv2sfv8sf ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv2sfv4df ((GET_MODE_NUNITS (V2SFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv8hiv4hi ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv8hiv4hf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv8hiv2si ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv8hiv2sf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv8hiv8hi ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv8hiv8hf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv8hiv4si ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv8hiv2di ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv8hiv4sf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv8hiv2df ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv8hiv16hi ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv8hiv16hf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv8hiv8si ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv8hiv4di ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv8hiv8sf ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv8hiv4df ((GET_MODE_NUNITS (V8HImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv8hfv4hi ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv8hfv4hf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv8hfv2si ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv8hfv2sf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv8hfv8hi ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv8hfv8hf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv8hfv4si ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv8hfv2di ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv8hfv4sf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv8hfv2df ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv8hfv16hi ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv8hfv16hf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv8hfv8si ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv8hfv4di ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv8hfv8sf ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv8hfv4df ((GET_MODE_NUNITS (V8HFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv4siv4hi ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv4siv4hf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv4siv2si ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv4siv2sf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv4siv8hi ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv4siv8hf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv4siv4si ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv4siv2di ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv4siv4sf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv4siv2df ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv4siv16hi ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv4siv16hf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv4siv8si ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv4siv4di ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv4siv8sf ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv4siv4df ((GET_MODE_NUNITS (V4SImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv2div4hi ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv2div4hf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv2div2si ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv2div2sf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv2div8hi ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv2div8hf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv2div4si ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv2div2di ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv2div4sf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv2div2df ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv2div16hi ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv2div16hf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv2div8si ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv2div4di ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv2div8sf ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv2div4df ((GET_MODE_NUNITS (V2DImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv4sfv4hi ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv4sfv4hf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv4sfv2si ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv4sfv2sf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv4sfv8hi ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv4sfv8hf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv4sfv4si ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv4sfv2di ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv4sfv4sf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv4sfv2df ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv4sfv16hi ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv4sfv16hf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv4sfv8si ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv4sfv4di ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv4sfv8sf ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv4sfv4df ((GET_MODE_NUNITS (V4SFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv2dfv4hi ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv2dfv4hf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv2dfv2si ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv2dfv2sf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv2dfv8hi ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv2dfv8hf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv2dfv4si ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv2dfv2di ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv2dfv4sf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv2dfv2df ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv2dfv16hi ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv2dfv16hf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv2dfv8si ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv2dfv4di ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv2dfv8sf ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv2dfv4df ((GET_MODE_NUNITS (V2DFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv16hiv4hi ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv16hiv4hf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv16hiv2si ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv16hiv2sf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv16hiv8hi ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv16hiv8hf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv16hiv4si ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv16hiv2di ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv16hiv4sf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv16hiv2df ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv16hiv16hi ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv16hiv16hf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv16hiv8si ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv16hiv4di ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv16hiv8sf ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv16hiv4df ((GET_MODE_NUNITS (V16HImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv16hfv4hi ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv16hfv4hf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv16hfv2si ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv16hfv2sf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv16hfv8hi ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv16hfv8hf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv16hfv4si ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv16hfv2di ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv16hfv4sf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv16hfv2df ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv16hfv16hi ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv16hfv16hf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv16hfv8si ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv16hfv4di ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv16hfv8sf ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv16hfv4df ((GET_MODE_NUNITS (V16HFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv8siv4hi ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv8siv4hf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv8siv2si ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv8siv2sf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv8siv8hi ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv8siv8hf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv8siv4si ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv8siv2di ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv8siv4sf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv8siv2df ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv8siv16hi ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv8siv16hf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv8siv8si ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv8siv4di ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv8siv8sf ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv8siv4df ((GET_MODE_NUNITS (V8SImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv4div4hi ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv4div4hf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv4div2si ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv4div2sf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv4div8hi ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv4div8hf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv4div4si ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv4div2di ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv4div4sf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv4div2df ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv4div16hi ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv4div16hf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv4div8si ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv4div4di ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv4div8sf ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv4div4df ((GET_MODE_NUNITS (V4DImode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv8sfv4hi ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv8sfv4hf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv8sfv2si ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv8sfv2sf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv8sfv8hi ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv8sfv8hf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv8sfv4si ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv8sfv2di ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv8sfv4sf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv8sfv2df ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv8sfv16hi ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv8sfv16hf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv8sfv8si ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv8sfv4di ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv8sfv8sf ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv8sfv4df ((GET_MODE_NUNITS (V8SFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vconduv4dfv4hi ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4HImode)))
#define HAVE_vconduv4dfv4hf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4HFmode)))
#define HAVE_vconduv4dfv2si ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V2SImode)))
#define HAVE_vconduv4dfv2sf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V2SFmode)))
#define HAVE_vconduv4dfv8hi ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V8HImode)))
#define HAVE_vconduv4dfv8hf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V8HFmode)))
#define HAVE_vconduv4dfv4si ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4SImode)))
#define HAVE_vconduv4dfv2di ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V2DImode)))
#define HAVE_vconduv4dfv4sf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4SFmode)))
#define HAVE_vconduv4dfv2df ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V2DFmode)))
#define HAVE_vconduv4dfv16hi ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V16HImode)))
#define HAVE_vconduv4dfv16hf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V16HFmode)))
#define HAVE_vconduv4dfv8si ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V8SImode)))
#define HAVE_vconduv4dfv4di ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4DImode)))
#define HAVE_vconduv4dfv8sf ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V8SFmode)))
#define HAVE_vconduv4dfv4df ((GET_MODE_NUNITS (V4DFmode) == GET_MODE_NUNITS (V4DFmode)))
#define HAVE_vcond_mask_v4hiv4hi 1
#define HAVE_vcond_mask_v4hfv4hi 1
#define HAVE_vcond_mask_v2siv2si 1
#define HAVE_vcond_mask_v2sfv2si 1
#define HAVE_vcond_mask_v8hiv8hi 1
#define HAVE_vcond_mask_v8hfv8hi 1
#define HAVE_vcond_mask_v4siv4si 1
#define HAVE_vcond_mask_v2div2di 1
#define HAVE_vcond_mask_v4sfv4si 1
#define HAVE_vcond_mask_v2dfv2di 1
#define HAVE_vcond_mask_v16hiv16hi 1
#define HAVE_vcond_mask_v16hfv16hi 1
#define HAVE_vcond_mask_v8siv8si 1
#define HAVE_vcond_mask_v4div4di 1
#define HAVE_vcond_mask_v8sfv8si 1
#define HAVE_vcond_mask_v4dfv4di 1
#define HAVE_vec_shr_v8qi 1
#define HAVE_vec_shr_v4hi 1
#define HAVE_vec_shr_v4hf 1
#define HAVE_vec_shr_v2si 1
#define HAVE_vec_shr_v2sf 1
#define HAVE_vec_shr_v16qi 1
#define HAVE_vec_shr_v8hi 1
#define HAVE_vec_shr_v8hf 1
#define HAVE_vec_shr_v4si 1
#define HAVE_vec_shr_v2di 1
#define HAVE_vec_shr_v4sf 1
#define HAVE_vec_shr_v2df 1
#define HAVE_vec_shr_v32qi 1
#define HAVE_vec_shr_v16hi 1
#define HAVE_vec_shr_v16hf 1
#define HAVE_vec_shr_v8si 1
#define HAVE_vec_shr_v4di 1
#define HAVE_vec_shr_v8sf 1
#define HAVE_vec_shr_v4df 1
#define HAVE_kvx_addhq 1
#define HAVE_kvx_addwp 1
#define HAVE_kvx_sbfhq 1
#define HAVE_kvx_sbfwp 1
#define HAVE_kvx_shlhqs 1
#define HAVE_kvx_shlwps 1
#define HAVE_kvx_shrhqs 1
#define HAVE_kvx_shrwps 1
#define HAVE_kvx_avghq 1
#define HAVE_kvx_avgwp 1
#define HAVE_kvx_neghq 1
#define HAVE_kvx_negwp 1
#define HAVE_kvx_abshq 1
#define HAVE_kvx_abswp 1
#define HAVE_kvx_bitcnthq 1
#define HAVE_kvx_bitcntwp 1
#define HAVE_kvx_abdhq 1
#define HAVE_kvx_abdwp 1
#define HAVE_kvx_mulhwq 1
#define HAVE_kvx_mulwdp 1
#define HAVE_kvx_maddhwq 1
#define HAVE_kvx_maddwdp 1
#define HAVE_kvx_msbfhwq 1
#define HAVE_kvx_msbfwdp 1
#define HAVE_kvx_zxbho 1
#define HAVE_kvx_zxhwq 1
#define HAVE_kvx_qxbho 1
#define HAVE_kvx_qxhwq 1
#define HAVE_kvx_widenbho 1
#define HAVE_kvx_widenhwq 1
#define HAVE_kvx_trunchbo 1
#define HAVE_kvx_truncwhq 1
#define HAVE_kvx_fracthbo 1
#define HAVE_kvx_fractwhq 1
#define HAVE_kvx_sathbo 1
#define HAVE_kvx_satwhq 1
#define HAVE_kvx_satuhbo 1
#define HAVE_kvx_satuwhq 1
#define HAVE_kvx_narrowhbo 1
#define HAVE_kvx_narrowwhq 1
#define HAVE_kvx_qxwdp 1
#define HAVE_kvx_widenwdp 1
#define HAVE_kvx_truncdwp 1
#define HAVE_kvx_fractdwp 1
#define HAVE_kvx_satdwp 1
#define HAVE_kvx_satudwp 1
#define HAVE_kvx_narrowdwp 1
#define HAVE_kvx_fractmdw 1
#define HAVE_kvx_satldw 1
#define HAVE_kvx_satmdw 1
#define HAVE_kvx_satuldw 1
#define HAVE_kvx_satumdw 1
#define HAVE_kvx_avgho 1
#define HAVE_kvx_avgwq 1
#define HAVE_kvx_mulhwo 1
#define HAVE_kvx_mulwdq 1
#define HAVE_kvx_maddhwo 1
#define HAVE_kvx_maddwdq 1
#define HAVE_kvx_msbfhwo 1
#define HAVE_kvx_msbfwdq 1
#define HAVE_kvx_addho 1
#define HAVE_kvx_addwq 1
#define HAVE_kvx_adddp 1
#define HAVE_kvx_sbfho 1
#define HAVE_kvx_sbfwq 1
#define HAVE_kvx_sbfdp 1
#define HAVE_kvx_negho 1
#define HAVE_kvx_negwq 1
#define HAVE_kvx_negdp 1
#define HAVE_kvx_absho 1
#define HAVE_kvx_abswq 1
#define HAVE_kvx_absdp 1
#define HAVE_kvx_bitcntho 1
#define HAVE_kvx_bitcntwq 1
#define HAVE_kvx_bitcntdp 1
#define HAVE_kvx_abdho 1
#define HAVE_kvx_abdwq 1
#define HAVE_kvx_abddp 1
#define HAVE_kvx_zxbhx 1
#define HAVE_kvx_zxhwo 1
#define HAVE_kvx_zxwdq 1
#define HAVE_kvx_sxbhx 1
#define HAVE_kvx_sxhwo 1
#define HAVE_kvx_sxwdq 1
#define HAVE_kvx_qxbhx 1
#define HAVE_kvx_qxhwo 1
#define HAVE_kvx_qxwdq 1
#define HAVE_kvx_widenbhx 1
#define HAVE_kvx_widenhwo 1
#define HAVE_kvx_widenwdq 1
#define HAVE_kvx_trunchbx 1
#define HAVE_kvx_truncwho 1
#define HAVE_kvx_truncdwq 1
#define HAVE_kvx_fracthbx 1
#define HAVE_kvx_fractwho 1
#define HAVE_kvx_fractdwq 1
#define HAVE_kvx_sathbx 1
#define HAVE_kvx_satwho 1
#define HAVE_kvx_satdwq 1
#define HAVE_kvx_satuhbx 1
#define HAVE_kvx_satuwho 1
#define HAVE_kvx_satudwq 1
#define HAVE_kvx_narrowhbx 1
#define HAVE_kvx_narrowwho 1
#define HAVE_kvx_narrowdwq 1
#define HAVE_kvx_shlhos 1
#define HAVE_kvx_shlwqs 1
#define HAVE_kvx_shldps 1
#define HAVE_kvx_shrhos 1
#define HAVE_kvx_shrwqs 1
#define HAVE_kvx_shrdps 1
#define HAVE_kvx_avghx 1
#define HAVE_kvx_avgwo 1
#define HAVE_kvx_addhx 1
#define HAVE_kvx_addwo 1
#define HAVE_kvx_adddq 1
#define HAVE_kvx_sbfhx 1
#define HAVE_kvx_sbfwo 1
#define HAVE_kvx_sbfdq 1
#define HAVE_kvx_neghx 1
#define HAVE_kvx_negwo 1
#define HAVE_kvx_negdq 1
#define HAVE_kvx_abshx 1
#define HAVE_kvx_abswo 1
#define HAVE_kvx_absdq 1
#define HAVE_kvx_bitcnthx 1
#define HAVE_kvx_bitcntwo 1
#define HAVE_kvx_bitcntdq 1
#define HAVE_kvx_abdhx 1
#define HAVE_kvx_abdwo 1
#define HAVE_kvx_abddq 1
#define HAVE_kvx_shlhxs 1
#define HAVE_kvx_shlwos 1
#define HAVE_kvx_shldqs 1
#define HAVE_kvx_shrhxs 1
#define HAVE_kvx_shrwos 1
#define HAVE_kvx_shrdqs 1
#define HAVE_copysignv4hf3 1
#define HAVE_copysignv2sf3 1
#define HAVE_kvx_ffdmaw 1
#define HAVE_kvx_ffdmsw 1
#define HAVE_kvx_ffdmdaw 1
#define HAVE_kvx_ffdmsaw 1
#define HAVE_kvx_ffdmdsw 1
#define HAVE_kvx_ffdmasw 1
#define HAVE_kvx_ffmawc 1
#define HAVE_kvx_ffmswc 1
#define HAVE_kvx_frecwp 1
#define HAVE_kvx_frsrwp 1
#define HAVE_kvx_fcdivwp 1
#define HAVE_kvx_fsdivwp 1
#define HAVE_divv2sf3 (flag_reciprocal_math || flag_unsafe_math_optimizations)
#define HAVE_divv4sf3 (flag_reciprocal_math || flag_unsafe_math_optimizations)
#define HAVE_divv8sf3 (flag_reciprocal_math || flag_unsafe_math_optimizations)
#define HAVE_sqrtv2sf2 (flag_reciprocal_math)
#define HAVE_sqrtv4sf2 (flag_reciprocal_math)
#define HAVE_sqrtv8sf2 (flag_reciprocal_math)
#define HAVE_recipv2sf2 1
#define HAVE_recipv4sf2 1
#define HAVE_recipv8sf2 1
#define HAVE_rsqrtv2sf2 1
#define HAVE_rsqrtv4sf2 1
#define HAVE_rsqrtv8sf2 1
#define HAVE_fmav8hf4 1
#define HAVE_fmav4sf4 1
#define HAVE_kvx_ffmaho 1
#define HAVE_kvx_ffmawq 1
#define HAVE_fnmav8hf4 1
#define HAVE_fnmav4sf4 1
#define HAVE_kvx_ffmsho 1
#define HAVE_kvx_ffmswq 1
#define HAVE_copysignv8hf3 1
#define HAVE_copysignv4sf3 1
#define HAVE_kvx_fwidenhwo 1
#define HAVE_kvx_fwidenwdq 1
#define HAVE_kvx_fnarrowwho 1
#define HAVE_kvx_fnarrowdwq 1
#define HAVE_addv8hf3 1
#define HAVE_kvx_faddho 1
#define HAVE_subv8hf3 1
#define HAVE_kvx_fsbfho 1
#define HAVE_mulv8hf3 1
#define HAVE_kvx_fmulho 1
#define HAVE_kvx_fmt22w 1
#define HAVE_kvx_fmm222w 1
#define HAVE_kvx_fmma222w 1
#define HAVE_kvx_fmms222w 1
#define HAVE_kvx_ffdmawp 1
#define HAVE_kvx_ffdmswp 1
#define HAVE_kvx_ffdmdawp 1
#define HAVE_kvx_ffdmsawp 1
#define HAVE_kvx_ffdmdswp 1
#define HAVE_kvx_ffdmaswp 1
#define HAVE_kvx_fmulwcp 1
#define HAVE_kvx_ffmawcp 1
#define HAVE_kvx_ffmswcp 1
#define HAVE_kvx_frecwq 1
#define HAVE_kvx_frsrwq 1
#define HAVE_kvx_fcdivwq 1
#define HAVE_kvx_fsdivwq 1
#define HAVE_kvx_fsrecwq 1
#define HAVE_kvx_fsrsrwq 1
#define HAVE_kvx_fmuldc 1
#define HAVE_kvx_ffmadc 1
#define HAVE_kvx_ffmsdc 1
#define HAVE_copysignv2df3 1
#define HAVE_kvx_fcdivdp 1
#define HAVE_kvx_fsdivdp 1
#define HAVE_kvx_fsrecdp 1
#define HAVE_kvx_fsrsrdp 1
#define HAVE_copysignv16hf3 1
#define HAVE_copysignv8sf3 1
#define HAVE_kvx_ffdmawq 1
#define HAVE_kvx_ffdmswq 1
#define HAVE_kvx_ffdmdawq 1
#define HAVE_kvx_ffdmsawq 1
#define HAVE_kvx_ffdmdswq 1
#define HAVE_kvx_ffdmaswq 1
#define HAVE_kvx_ffmawcq 1
#define HAVE_kvx_ffmswcq 1
#define HAVE_kvx_frecwo 1
#define HAVE_kvx_frsrwo 1
#define HAVE_kvx_fcdivwo 1
#define HAVE_kvx_fsdivwo 1
#define HAVE_kvx_fsrecwo 1
#define HAVE_kvx_fsrsrwo 1
#define HAVE_kvx_fmuldcp 1
#define HAVE_kvx_ffmadcp 1
#define HAVE_kvx_ffmsdcp 1
#define HAVE_copysignv4df3 1
#define HAVE_kvx_fcdivdq 1
#define HAVE_kvx_fsdivdq 1
#define HAVE_kvx_fsrecdq 1
#define HAVE_kvx_fsrsrdq 1
#define HAVE_kvx_shiftbo 1
#define HAVE_kvx_shifthq 1
#define HAVE_kvx_shiftwp 1
#define HAVE_kvx_shiftfhq 1
#define HAVE_kvx_shiftfwp 1
#define HAVE_kvx_shiftbx 1
#define HAVE_kvx_shiftho 1
#define HAVE_kvx_shiftwq 1
#define HAVE_kvx_shiftfho 1
#define HAVE_kvx_shiftfwq 1
#define HAVE_kvx_shiftdp 1
#define HAVE_kvx_shiftfdp 1
#define HAVE_kvx_shiftbv 1
#define HAVE_kvx_shifthx 1
#define HAVE_kvx_shiftwo 1
#define HAVE_kvx_shiftfhx 1
#define HAVE_kvx_shiftfwo 1
#define HAVE_kvx_shiftdq 1
#define HAVE_kvx_shiftfdq 1
#define HAVE_cstoresf4 1
#define HAVE_cstoredf4 1
#define HAVE_cbranchsi4 1
#define HAVE_cbranchsf4 1
#define HAVE_cbranchdi4 1
#define HAVE_cbranchdf4 1
#define HAVE_movqicc 1
#define HAVE_movhicc 1
#define HAVE_movhfcc 1
#define HAVE_movsicc 1
#define HAVE_movsfcc 1
#define HAVE_movdicc 1
#define HAVE_movdfcc 1
#define HAVE_movticc 1
#define HAVE_movoicc 1
#define HAVE_movv8qicc 1
#define HAVE_movv4hicc 1
#define HAVE_movv4hfcc 1
#define HAVE_movv2sicc 1
#define HAVE_movv2sfcc 1
#define HAVE_movv16qicc 1
#define HAVE_movv8hicc 1
#define HAVE_movv8hfcc 1
#define HAVE_movv4sicc 1
#define HAVE_movv2dicc 1
#define HAVE_movv4sfcc 1
#define HAVE_movv2dfcc 1
#define HAVE_movv32qicc 1
#define HAVE_movv16hicc 1
#define HAVE_movv16hfcc 1
#define HAVE_movv8sicc 1
#define HAVE_movv4dicc 1
#define HAVE_movv8sfcc 1
#define HAVE_movv4dfcc 1
extern rtx        gen_acswapw                   (rtx, rtx);
extern rtx        gen_acswapd                   (rtx, rtx);
extern rtx        gen_aladdw                    (rtx, rtx, rtx);
extern rtx        gen_aladdd                    (rtx, rtx, rtx);
extern rtx        gen_alclrw                    (rtx, rtx);
extern rtx        gen_alclrd                    (rtx, rtx);
extern rtx        gen_add_pcrel_si              (rtx, rtx);
extern rtx        gen_add_pcrel_di              (rtx, rtx);
extern rtx        gen_jump                      (rtx);
extern rtx        gen_tablejump_real_si         (rtx, rtx);
extern rtx        gen_tablejump_real_di         (rtx, rtx);
extern rtx        gen_nop                       (void);
extern rtx        gen_set_gotp_si               (rtx);
extern rtx        gen_set_gotp_di               (rtx);
extern rtx        gen_kvx_get                   (rtx, rtx, rtx);
extern rtx        gen_kvx_wfxl                  (rtx, rtx, rtx);
extern rtx        gen_kvx_wfxm                  (rtx, rtx, rtx);
extern rtx        gen_kvx_syncgroup             (rtx, rtx);
extern rtx        gen_kvx_await                 (rtx);
extern rtx        gen_kvx_barrier               (rtx);
extern rtx        gen_kvx_sleep                 (rtx);
extern rtx        gen_kvx_stop                  (rtx);
extern rtx        gen_kvx_waitit                (rtx, rtx, rtx);
extern rtx        gen_trap                      (void);
extern rtx        gen_ctrapsi4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_scall_si                  (rtx, rtx, rtx);
extern rtx        gen_scall_di                  (rtx, rtx, rtx);
extern rtx        gen_mos_dinval_scall          (void);
extern rtx        gen_mos_dflush_scall          (void);
extern rtx        gen_kvx_fence                 (rtx);
extern rtx        gen_kvx_dinval                (rtx);
extern rtx        gen_kvx_iinval                (rtx);
extern rtx        gen_kvx_dinvall               (rtx);
extern rtx        gen_kvx_iinvals               (rtx);
extern rtx        gen_kvx_dtouchl               (rtx);
extern rtx        gen_prefetch                  (rtx, rtx, rtx);
extern rtx        gen_kvx_dzerol_1              (rtx);
extern rtx        gen_kvx_tlbdinval             (rtx);
extern rtx        gen_kvx_tlbiinval             (rtx);
extern rtx        gen_kvx_tlbprobe              (rtx);
extern rtx        gen_kvx_tlbread               (rtx);
extern rtx        gen_kvx_tlbwrite              (rtx);
extern rtx        gen_lqu                       (rtx, rtx);
extern rtx        gen_ldu                       (rtx, rtx);
extern rtx        gen_lwzu                      (rtx, rtx);
extern rtx        gen_lhsu                      (rtx, rtx);
extern rtx        gen_lhzu                      (rtx, rtx);
extern rtx        gen_lbsu                      (rtx, rtx);
extern rtx        gen_lbzu                      (rtx, rtx);
extern rtx        gen_extendqidi2               (rtx, rtx);
extern rtx        gen_extendhidi2               (rtx, rtx);
extern rtx        gen_extendsidi2               (rtx, rtx);
extern rtx        gen_zero_extendqidi2          (rtx, rtx);
extern rtx        gen_zero_extendhidi2          (rtx, rtx);
extern rtx        gen_zero_extendsidi2          (rtx, rtx);
extern rtx        gen_ret                       (void);
extern rtx        gen_satd                      (rtx, rtx, rtx);
extern rtx        gen_satud                     (rtx, rtx, rtx);
extern rtx        gen_kvx_loopdo                (rtx, rtx);
extern rtx        gen_doloop_end_si             (rtx, rtx);
extern rtx        gen_doloop_end_di             (rtx, rtx);
extern rtx        gen_usaddsi3                  (rtx, rtx, rtx);
extern rtx        gen_usadddi3                  (rtx, rtx, rtx);
extern rtx        gen_ussubsi3                  (rtx, rtx, rtx);
extern rtx        gen_ussubdi3                  (rtx, rtx, rtx);
extern rtx        gen_ashlsi3                   (rtx, rtx, rtx);
extern rtx        gen_ashldi3                   (rtx, rtx, rtx);
extern rtx        gen_ssashlsi3                 (rtx, rtx, rtx);
extern rtx        gen_ssashldi3                 (rtx, rtx, rtx);
extern rtx        gen_usashlsi3                 (rtx, rtx, rtx);
extern rtx        gen_usashldi3                 (rtx, rtx, rtx);
extern rtx        gen_ashrsi3                   (rtx, rtx, rtx);
extern rtx        gen_ashrdi3                   (rtx, rtx, rtx);
extern rtx        gen_lshrsi3                   (rtx, rtx, rtx);
extern rtx        gen_lshrdi3                   (rtx, rtx, rtx);
extern rtx        gen_kvx_srsw                  (rtx, rtx, rtx);
extern rtx        gen_kvx_srsd                  (rtx, rtx, rtx);
extern rtx        gen_negsi2                    (rtx, rtx);
extern rtx        gen_negdi2                    (rtx, rtx);
extern rtx        gen_ssnegsi2                  (rtx, rtx);
extern rtx        gen_ssnegdi2                  (rtx, rtx);
extern rtx        gen_abssi2                    (rtx, rtx);
extern rtx        gen_absdi2                    (rtx, rtx);
extern rtx        gen_ssabssi2                  (rtx, rtx);
extern rtx        gen_ssabsdi2                  (rtx, rtx);
extern rtx        gen_abdsi3                    (rtx, rtx, rtx);
extern rtx        gen_abddi3                    (rtx, rtx, rtx);
extern rtx        gen_ssabdsi3                  (rtx, rtx, rtx);
extern rtx        gen_ssabddi3                  (rtx, rtx, rtx);
extern rtx        gen_extvsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_extvdi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_extzvsi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_extzvdi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_insvsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_insvdi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_addsi3                    (rtx, rtx, rtx);
extern rtx        gen_ssaddsi3                  (rtx, rtx, rtx);
extern rtx        gen_subsi3                    (rtx, rtx, rtx);
extern rtx        gen_sssubsi3                  (rtx, rtx, rtx);
extern rtx        gen_mulsi3                    (rtx, rtx, rtx);
extern rtx        gen_mulsidi3                  (rtx, rtx, rtx);
extern rtx        gen_umulsidi3                 (rtx, rtx, rtx);
extern rtx        gen_usmulsidi3                (rtx, rtx, rtx);
extern rtx        gen_maddsisi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_maddsidi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_umaddsidi4                (rtx, rtx, rtx, rtx);
extern rtx        gen_usmaddsidi4               (rtx, rtx, rtx, rtx);
extern rtx        gen_msubsisi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_msubsidi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_umsubsidi4                (rtx, rtx, rtx, rtx);
extern rtx        gen_usmsubsidi4               (rtx, rtx, rtx, rtx);
extern rtx        gen_sminsi3                   (rtx, rtx, rtx);
extern rtx        gen_smaxsi3                   (rtx, rtx, rtx);
extern rtx        gen_uminsi3                   (rtx, rtx, rtx);
extern rtx        gen_umaxsi3                   (rtx, rtx, rtx);
extern rtx        gen_andsi3                    (rtx, rtx, rtx);
extern rtx        gen_iorsi3                    (rtx, rtx, rtx);
extern rtx        gen_xorsi3                    (rtx, rtx, rtx);
extern rtx        gen_rotlsi3                   (rtx, rtx, rtx);
extern rtx        gen_rotrsi3                   (rtx, rtx, rtx);
extern rtx        gen_avgsi3_floor              (rtx, rtx, rtx);
extern rtx        gen_avgsi3_ceil               (rtx, rtx, rtx);
extern rtx        gen_uavgsi3_floor             (rtx, rtx, rtx);
extern rtx        gen_uavgsi3_ceil              (rtx, rtx, rtx);
extern rtx        gen_bswapsi2                  (rtx, rtx);
extern rtx        gen_clrsbsi2                  (rtx, rtx);
extern rtx        gen_clzsi2                    (rtx, rtx);
extern rtx        gen_ctzsi2                    (rtx, rtx);
extern rtx        gen_popcountsi2               (rtx, rtx);
extern rtx        gen_one_cmplsi2               (rtx, rtx);
extern rtx        gen_kvx_stsuw                 (rtx, rtx, rtx);
extern rtx        gen_adddi3                    (rtx, rtx, rtx);
extern rtx        gen_ssadddi3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_addcd                 (rtx, rtx, rtx, rtx);
extern rtx        gen_subdi3                    (rtx, rtx, rtx);
extern rtx        gen_sssubdi3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_sbfcd                 (rtx, rtx, rtx, rtx);
extern rtx        gen_muldi3                    (rtx, rtx, rtx);
extern rtx        gen_mulditi3                  (rtx, rtx, rtx);
extern rtx        gen_umulditi3                 (rtx, rtx, rtx);
extern rtx        gen_usmulditi3                (rtx, rtx, rtx);
extern rtx        gen_smuldi3_highpart          (rtx, rtx, rtx);
extern rtx        gen_umuldi3_highpart          (rtx, rtx, rtx);
extern rtx        gen_madddidi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_maddditi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_umaddditi4                (rtx, rtx, rtx, rtx);
extern rtx        gen_usmaddditi4               (rtx, rtx, rtx, rtx);
extern rtx        gen_msubdidi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_msubditi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_umsubditi4                (rtx, rtx, rtx, rtx);
extern rtx        gen_usmsubditi4               (rtx, rtx, rtx, rtx);
extern rtx        gen_smindi3                   (rtx, rtx, rtx);
extern rtx        gen_smaxdi3                   (rtx, rtx, rtx);
extern rtx        gen_umindi3                   (rtx, rtx, rtx);
extern rtx        gen_umaxdi3                   (rtx, rtx, rtx);
extern rtx        gen_anddi3                    (rtx, rtx, rtx);
extern rtx        gen_iordi3                    (rtx, rtx, rtx);
extern rtx        gen_xordi3                    (rtx, rtx, rtx);
extern rtx        gen_rotldi3                   (rtx, rtx, rtx);
extern rtx        gen_rotrdi3                   (rtx, rtx, rtx);
extern rtx        gen_bswapdi2                  (rtx, rtx);
extern rtx        gen_clrsbdi2                  (rtx, rtx);
extern rtx        gen_clzdi2                    (rtx, rtx);
extern rtx        gen_ctzdi2                    (rtx, rtx);
extern rtx        gen_popcountdi2               (rtx, rtx);
extern rtx        gen_one_cmpldi2               (rtx, rtx);
extern rtx        gen_kvx_sbmm8                 (rtx, rtx, rtx);
extern rtx        gen_kvx_sbmmt8                (rtx, rtx, rtx);
extern rtx        gen_kvx_stsud                 (rtx, rtx, rtx);
extern rtx        gen_kvx_set                   (rtx, rtx, rtx);
extern rtx        gen_addhf3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_faddh                 (rtx, rtx, rtx, rtx);
extern rtx        gen_subhf3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfh                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mulhf3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_fmulh                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulhw                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmahf4                    (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmah                 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmahw                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fnmahf4                   (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsh                 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmshw                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fminhf3                   (rtx, rtx, rtx);
extern rtx        gen_fmaxhf3                   (rtx, rtx, rtx);
extern rtx        gen_neghf2                    (rtx, rtx);
extern rtx        gen_abshf2                    (rtx, rtx);
extern rtx        gen_kvx_getsignh              (rtx, rtx);
extern rtx        gen_kvx_setsignh              (rtx, rtx, rtx);
extern rtx        gen_extendhfsf2               (rtx, rtx);
extern rtx        gen_kvx_fwidenlhw             (rtx, rtx);
extern rtx        gen_kvx_fwidenmhw             (rtx, rtx);
extern rtx        gen_addsf3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_faddw                 (rtx, rtx, rtx, rtx);
extern rtx        gen_subsf3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfw                 (rtx, rtx, rtx, rtx);
extern rtx        gen_mulsf3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_fmulw                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwd                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmasf4                    (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmaw                 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawd                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fnmasf4                   (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsw                 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswd                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fminsf3                   (rtx, rtx, rtx);
extern rtx        gen_fmaxsf3                   (rtx, rtx, rtx);
extern rtx        gen_negsf2                    (rtx, rtx);
extern rtx        gen_abssf2                    (rtx, rtx);
extern rtx        gen_kvx_getsignw              (rtx, rtx);
extern rtx        gen_kvx_setsignw              (rtx, rtx, rtx);
extern rtx        gen_floatsisf2                (rtx, rtx);
extern rtx        gen_kvx_floatw                (rtx, rtx, rtx, rtx);
extern rtx        gen_floatunssisf2             (rtx, rtx);
extern rtx        gen_kvx_floatuw               (rtx, rtx, rtx, rtx);
extern rtx        gen_fix_truncsfsi2            (rtx, rtx);
extern rtx        gen_kvx_fixedw                (rtx, rtx, rtx, rtx);
extern rtx        gen_fixuns_truncsfsi2         (rtx, rtx);
extern rtx        gen_kvx_fixeduw               (rtx, rtx, rtx, rtx);
extern rtx        gen_truncsfhf2                (rtx, rtx);
extern rtx        gen_kvx_fnarrowwh             (rtx, rtx);
extern rtx        gen_extendsfdf2               (rtx, rtx);
extern rtx        gen_kvx_frecw                 (rtx, rtx, rtx);
extern rtx        gen_kvx_frsrw                 (rtx, rtx, rtx);
extern rtx        gen_kvx_fcdivw_insn           (rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivw_insn           (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrecw                (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrsrw                (rtx, rtx, rtx);
extern rtx        gen_adddf3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_faddd                 (rtx, rtx, rtx, rtx);
extern rtx        gen_subdf3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfd                 (rtx, rtx, rtx, rtx);
extern rtx        gen_muldf3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_fmuld                 (rtx, rtx, rtx, rtx);
extern rtx        gen_fmadf4                    (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmad                 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fnmadf4                   (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsd                 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fmindf3                   (rtx, rtx, rtx);
extern rtx        gen_fmaxdf3                   (rtx, rtx, rtx);
extern rtx        gen_negdf2                    (rtx, rtx);
extern rtx        gen_absdf2                    (rtx, rtx);
extern rtx        gen_kvx_getsignd              (rtx, rtx);
extern rtx        gen_kvx_setsignd              (rtx, rtx, rtx);
extern rtx        gen_floatdidf2                (rtx, rtx);
extern rtx        gen_kvx_floatd                (rtx, rtx, rtx, rtx);
extern rtx        gen_floatunsdidf2             (rtx, rtx);
extern rtx        gen_kvx_floatud               (rtx, rtx, rtx, rtx);
extern rtx        gen_fix_truncdfdi2            (rtx, rtx);
extern rtx        gen_kvx_fixedd                (rtx, rtx, rtx, rtx);
extern rtx        gen_fixuns_truncdfdi2         (rtx, rtx);
extern rtx        gen_kvx_fixedud               (rtx, rtx, rtx, rtx);
extern rtx        gen_truncdfsf2                (rtx, rtx);
extern rtx        gen_kvx_fcdivd_insn           (rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivd_insn           (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrecd                (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrsrd                (rtx, rtx, rtx);
extern rtx        gen_kvx_lbz                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lbs                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lhz                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lhs                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lwz                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lws                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lhf                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lwf                   (rtx, rtx, rtx);
extern rtx        gen_kvx_ld                    (rtx, rtx, rtx);
extern rtx        gen_kvx_lq                    (rtx, rtx, rtx);
extern rtx        gen_kvx_ldf                   (rtx, rtx, rtx);
extern rtx        gen_kvx_selecthq              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_selectwp              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_addv4hi3                  (rtx, rtx, rtx);
extern rtx        gen_addv2si3                  (rtx, rtx, rtx);
extern rtx        gen_ssaddv4hi3                (rtx, rtx, rtx);
extern rtx        gen_ssaddv2si3                (rtx, rtx, rtx);
extern rtx        gen_usaddv4hi3                (rtx, rtx, rtx);
extern rtx        gen_usaddv2si3                (rtx, rtx, rtx);
extern rtx        gen_subv4hi3                  (rtx, rtx, rtx);
extern rtx        gen_subv2si3                  (rtx, rtx, rtx);
extern rtx        gen_sssubv4hi3                (rtx, rtx, rtx);
extern rtx        gen_sssubv2si3                (rtx, rtx, rtx);
extern rtx        gen_ussubv4hi3                (rtx, rtx, rtx);
extern rtx        gen_ussubv2si3                (rtx, rtx, rtx);
extern rtx        gen_mulv4hi3                  (rtx, rtx, rtx);
extern rtx        gen_mulv2si3                  (rtx, rtx, rtx);
extern rtx        gen_sminv4hi3                 (rtx, rtx, rtx);
extern rtx        gen_sminv2si3                 (rtx, rtx, rtx);
extern rtx        gen_smaxv4hi3                 (rtx, rtx, rtx);
extern rtx        gen_smaxv2si3                 (rtx, rtx, rtx);
extern rtx        gen_uminv4hi3                 (rtx, rtx, rtx);
extern rtx        gen_uminv2si3                 (rtx, rtx, rtx);
extern rtx        gen_umaxv4hi3                 (rtx, rtx, rtx);
extern rtx        gen_umaxv2si3                 (rtx, rtx, rtx);
extern rtx        gen_andv4hi3                  (rtx, rtx, rtx);
extern rtx        gen_andv2si3                  (rtx, rtx, rtx);
extern rtx        gen_iorv4hi3                  (rtx, rtx, rtx);
extern rtx        gen_iorv2si3                  (rtx, rtx, rtx);
extern rtx        gen_xorv4hi3                  (rtx, rtx, rtx);
extern rtx        gen_xorv2si3                  (rtx, rtx, rtx);
extern rtx        gen_maddv4hiv4hi4             (rtx, rtx, rtx, rtx);
extern rtx        gen_maddv2siv2si4             (rtx, rtx, rtx, rtx);
extern rtx        gen_msubv4hiv4hi4             (rtx, rtx, rtx, rtx);
extern rtx        gen_msubv2siv2si4             (rtx, rtx, rtx, rtx);
extern rtx        gen_ashlv4hi3                 (rtx, rtx, rtx);
extern rtx        gen_ashlv2si3                 (rtx, rtx, rtx);
extern rtx        gen_ssashlv4hi3               (rtx, rtx, rtx);
extern rtx        gen_ssashlv2si3               (rtx, rtx, rtx);
extern rtx        gen_usashlv4hi3               (rtx, rtx, rtx);
extern rtx        gen_usashlv2si3               (rtx, rtx, rtx);
extern rtx        gen_ashrv4hi3                 (rtx, rtx, rtx);
extern rtx        gen_ashrv2si3                 (rtx, rtx, rtx);
extern rtx        gen_lshrv4hi3                 (rtx, rtx, rtx);
extern rtx        gen_lshrv2si3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_srshqs                (rtx, rtx, rtx);
extern rtx        gen_kvx_srswps                (rtx, rtx, rtx);
extern rtx        gen_avgv4hi3_floor            (rtx, rtx, rtx);
extern rtx        gen_avgv2si3_floor            (rtx, rtx, rtx);
extern rtx        gen_avgv4hi3_ceil             (rtx, rtx, rtx);
extern rtx        gen_avgv2si3_ceil             (rtx, rtx, rtx);
extern rtx        gen_uavgv4hi3_floor           (rtx, rtx, rtx);
extern rtx        gen_uavgv2si3_floor           (rtx, rtx, rtx);
extern rtx        gen_uavgv4hi3_ceil            (rtx, rtx, rtx);
extern rtx        gen_uavgv2si3_ceil            (rtx, rtx, rtx);
extern rtx        gen_negv4hi2                  (rtx, rtx);
extern rtx        gen_negv2si2                  (rtx, rtx);
extern rtx        gen_ssnegv4hi2                (rtx, rtx);
extern rtx        gen_ssnegv2si2                (rtx, rtx);
extern rtx        gen_absv4hi2                  (rtx, rtx);
extern rtx        gen_absv2si2                  (rtx, rtx);
extern rtx        gen_ssabsv4hi2                (rtx, rtx);
extern rtx        gen_ssabsv2si2                (rtx, rtx);
extern rtx        gen_clrsbv4hi2                (rtx, rtx);
extern rtx        gen_clrsbv2si2                (rtx, rtx);
extern rtx        gen_clzv4hi2                  (rtx, rtx);
extern rtx        gen_clzv2si2                  (rtx, rtx);
extern rtx        gen_ctzv4hi2                  (rtx, rtx);
extern rtx        gen_ctzv2si2                  (rtx, rtx);
extern rtx        gen_popcountv4hi2             (rtx, rtx);
extern rtx        gen_popcountv2si2             (rtx, rtx);
extern rtx        gen_one_cmplv4hi2             (rtx, rtx);
extern rtx        gen_one_cmplv2si2             (rtx, rtx);
extern rtx        gen_abdv4hi3                  (rtx, rtx, rtx);
extern rtx        gen_abdv2si3                  (rtx, rtx, rtx);
extern rtx        gen_ssabdv4hi3                (rtx, rtx, rtx);
extern rtx        gen_ssabdv2si3                (rtx, rtx, rtx);
extern rtx        gen__mulhwq                   (rtx, rtx, rtx);
extern rtx        gen__mulwdp                   (rtx, rtx, rtx);
extern rtx        gen__muluhwq                  (rtx, rtx, rtx);
extern rtx        gen__muluwdp                  (rtx, rtx, rtx);
extern rtx        gen__mulsuhwq                 (rtx, rtx, rtx);
extern rtx        gen__mulsuwdp                 (rtx, rtx, rtx);
extern rtx        gen__maddhwq                  (rtx, rtx, rtx, rtx);
extern rtx        gen__maddwdp                  (rtx, rtx, rtx, rtx);
extern rtx        gen__madduhwq                 (rtx, rtx, rtx, rtx);
extern rtx        gen__madduwdp                 (rtx, rtx, rtx, rtx);
extern rtx        gen__maddsuhwq                (rtx, rtx, rtx, rtx);
extern rtx        gen__maddsuwdp                (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfhwq                  (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfwdp                  (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfuhwq                 (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfuwdp                 (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfsuhwq                (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfsuwdp                (rtx, rtx, rtx, rtx);
extern rtx        gen_rotlv4hi3                 (rtx, rtx, rtx);
extern rtx        gen_rotrv4hi3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_sxbho                 (rtx, rtx);
extern rtx        gen_kvx_sxhwq                 (rtx, rtx);
extern rtx        gen_maddv4hiv4si4             (rtx, rtx, rtx, rtx);
extern rtx        gen_umaddv4hiv4si4            (rtx, rtx, rtx, rtx);
extern rtx        gen_msubv4hiv4si4             (rtx, rtx, rtx, rtx);
extern rtx        gen_umsubv4hiv4si4            (rtx, rtx, rtx, rtx);
extern rtx        gen_rotlv2si3                 (rtx, rtx, rtx);
extern rtx        gen_rotrv2si3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_conswp                (rtx, rtx, rtx);
extern rtx        gen_kvx_zxwdp                 (rtx, rtx);
extern rtx        gen_kvx_sxwdp                 (rtx, rtx);
extern rtx        gen_kvx_truncldw              (rtx, rtx);
extern rtx        gen_kvx_truncmdw              (rtx, rtx);
extern rtx        gen_kvx_fractldw              (rtx, rtx);
extern rtx        gen_kvx_selectho              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_selectwq              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_ashlv8hi3                 (rtx, rtx, rtx);
extern rtx        gen_ashlv4si3                 (rtx, rtx, rtx);
extern rtx        gen_ssashlv8hi3               (rtx, rtx, rtx);
extern rtx        gen_ssashlv4si3               (rtx, rtx, rtx);
extern rtx        gen_usashlv8hi3               (rtx, rtx, rtx);
extern rtx        gen_usashlv4si3               (rtx, rtx, rtx);
extern rtx        gen_ashrv8hi3                 (rtx, rtx, rtx);
extern rtx        gen_ashrv4si3                 (rtx, rtx, rtx);
extern rtx        gen_lshrv8hi3                 (rtx, rtx, rtx);
extern rtx        gen_lshrv4si3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_srshos                (rtx, rtx, rtx);
extern rtx        gen_kvx_srswqs                (rtx, rtx, rtx);
extern rtx        gen_avgv8hi3_floor            (rtx, rtx, rtx);
extern rtx        gen_avgv4si3_floor            (rtx, rtx, rtx);
extern rtx        gen_avgv8hi3_ceil             (rtx, rtx, rtx);
extern rtx        gen_avgv4si3_ceil             (rtx, rtx, rtx);
extern rtx        gen_uavgv8hi3_floor           (rtx, rtx, rtx);
extern rtx        gen_uavgv4si3_floor           (rtx, rtx, rtx);
extern rtx        gen_uavgv8hi3_ceil            (rtx, rtx, rtx);
extern rtx        gen_uavgv4si3_ceil            (rtx, rtx, rtx);
extern rtx        gen__mulhwo                   (rtx, rtx, rtx);
extern rtx        gen__mulwdq                   (rtx, rtx, rtx);
extern rtx        gen__muluhwo                  (rtx, rtx, rtx);
extern rtx        gen__muluwdq                  (rtx, rtx, rtx);
extern rtx        gen__mulsuhwo                 (rtx, rtx, rtx);
extern rtx        gen__mulsuwdq                 (rtx, rtx, rtx);
extern rtx        gen__maddhwo                  (rtx, rtx, rtx, rtx);
extern rtx        gen__maddwdq                  (rtx, rtx, rtx, rtx);
extern rtx        gen__madduhwo                 (rtx, rtx, rtx, rtx);
extern rtx        gen__madduwdq                 (rtx, rtx, rtx, rtx);
extern rtx        gen__maddsuhwo                (rtx, rtx, rtx, rtx);
extern rtx        gen__maddsuwdq                (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfhwo                  (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfwdq                  (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfuhwo                 (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfuwdq                 (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfsuhwo                (rtx, rtx, rtx, rtx);
extern rtx        gen__msbfsuwdq                (rtx, rtx, rtx, rtx);
extern rtx        gen_addv8hi3                  (rtx, rtx, rtx);
extern rtx        gen_addv4si3                  (rtx, rtx, rtx);
extern rtx        gen_addv2di3                  (rtx, rtx, rtx);
extern rtx        gen_ssaddv8hi3                (rtx, rtx, rtx);
extern rtx        gen_ssaddv4si3                (rtx, rtx, rtx);
extern rtx        gen_ssaddv2di3                (rtx, rtx, rtx);
extern rtx        gen_usaddv8hi3                (rtx, rtx, rtx);
extern rtx        gen_usaddv4si3                (rtx, rtx, rtx);
extern rtx        gen_usaddv2di3                (rtx, rtx, rtx);
extern rtx        gen_subv8hi3                  (rtx, rtx, rtx);
extern rtx        gen_subv4si3                  (rtx, rtx, rtx);
extern rtx        gen_subv2di3                  (rtx, rtx, rtx);
extern rtx        gen_sssubv8hi3                (rtx, rtx, rtx);
extern rtx        gen_sssubv4si3                (rtx, rtx, rtx);
extern rtx        gen_sssubv2di3                (rtx, rtx, rtx);
extern rtx        gen_ussubv8hi3                (rtx, rtx, rtx);
extern rtx        gen_ussubv4si3                (rtx, rtx, rtx);
extern rtx        gen_ussubv2di3                (rtx, rtx, rtx);
extern rtx        gen_sminv8hi3                 (rtx, rtx, rtx);
extern rtx        gen_sminv4si3                 (rtx, rtx, rtx);
extern rtx        gen_sminv2di3                 (rtx, rtx, rtx);
extern rtx        gen_smaxv8hi3                 (rtx, rtx, rtx);
extern rtx        gen_smaxv4si3                 (rtx, rtx, rtx);
extern rtx        gen_smaxv2di3                 (rtx, rtx, rtx);
extern rtx        gen_uminv8hi3                 (rtx, rtx, rtx);
extern rtx        gen_uminv4si3                 (rtx, rtx, rtx);
extern rtx        gen_uminv2di3                 (rtx, rtx, rtx);
extern rtx        gen_umaxv8hi3                 (rtx, rtx, rtx);
extern rtx        gen_umaxv4si3                 (rtx, rtx, rtx);
extern rtx        gen_umaxv2di3                 (rtx, rtx, rtx);
extern rtx        gen_andv8hi3                  (rtx, rtx, rtx);
extern rtx        gen_andv4si3                  (rtx, rtx, rtx);
extern rtx        gen_andv2di3                  (rtx, rtx, rtx);
extern rtx        gen_iorv8hi3                  (rtx, rtx, rtx);
extern rtx        gen_iorv4si3                  (rtx, rtx, rtx);
extern rtx        gen_iorv2di3                  (rtx, rtx, rtx);
extern rtx        gen_xorv8hi3                  (rtx, rtx, rtx);
extern rtx        gen_xorv4si3                  (rtx, rtx, rtx);
extern rtx        gen_xorv2di3                  (rtx, rtx, rtx);
extern rtx        gen_maddv8hiv8hi4             (rtx, rtx, rtx, rtx);
extern rtx        gen_maddv4siv4si4             (rtx, rtx, rtx, rtx);
extern rtx        gen_maddv2div2di4             (rtx, rtx, rtx, rtx);
extern rtx        gen_msubv8hiv8hi4             (rtx, rtx, rtx, rtx);
extern rtx        gen_msubv4siv4si4             (rtx, rtx, rtx, rtx);
extern rtx        gen_msubv2div2di4             (rtx, rtx, rtx, rtx);
extern rtx        gen_negv8hi2                  (rtx, rtx);
extern rtx        gen_negv4si2                  (rtx, rtx);
extern rtx        gen_negv2di2                  (rtx, rtx);
extern rtx        gen_ssnegv8hi2                (rtx, rtx);
extern rtx        gen_ssnegv4si2                (rtx, rtx);
extern rtx        gen_ssnegv2di2                (rtx, rtx);
extern rtx        gen_absv8hi2                  (rtx, rtx);
extern rtx        gen_absv4si2                  (rtx, rtx);
extern rtx        gen_absv2di2                  (rtx, rtx);
extern rtx        gen_ssabsv8hi2                (rtx, rtx);
extern rtx        gen_ssabsv4si2                (rtx, rtx);
extern rtx        gen_ssabsv2di2                (rtx, rtx);
extern rtx        gen_clrsbv8hi2                (rtx, rtx);
extern rtx        gen_clrsbv4si2                (rtx, rtx);
extern rtx        gen_clrsbv2di2                (rtx, rtx);
extern rtx        gen_clzv8hi2                  (rtx, rtx);
extern rtx        gen_clzv4si2                  (rtx, rtx);
extern rtx        gen_clzv2di2                  (rtx, rtx);
extern rtx        gen_ctzv8hi2                  (rtx, rtx);
extern rtx        gen_ctzv4si2                  (rtx, rtx);
extern rtx        gen_ctzv2di2                  (rtx, rtx);
extern rtx        gen_popcountv8hi2             (rtx, rtx);
extern rtx        gen_popcountv4si2             (rtx, rtx);
extern rtx        gen_popcountv2di2             (rtx, rtx);
extern rtx        gen_one_cmplv8hi2             (rtx, rtx);
extern rtx        gen_one_cmplv4si2             (rtx, rtx);
extern rtx        gen_one_cmplv2di2             (rtx, rtx);
extern rtx        gen_abdv8hi3                  (rtx, rtx, rtx);
extern rtx        gen_abdv4si3                  (rtx, rtx, rtx);
extern rtx        gen_abdv2di3                  (rtx, rtx, rtx);
extern rtx        gen_ssabdv8hi3                (rtx, rtx, rtx);
extern rtx        gen_ssabdv4si3                (rtx, rtx, rtx);
extern rtx        gen_ssabdv2di3                (rtx, rtx, rtx);
extern rtx        gen_mulv8hi3                  (rtx, rtx, rtx);
extern rtx        gen_mulv2di3                  (rtx, rtx, rtx);
extern rtx        gen_rotlv8hi3                 (rtx, rtx, rtx);
extern rtx        gen_rotlv2di3                 (rtx, rtx, rtx);
extern rtx        gen_rotrv8hi3                 (rtx, rtx, rtx);
extern rtx        gen_rotrv2di3                 (rtx, rtx, rtx);
extern rtx        gen_mulv4si3                  (rtx, rtx, rtx);
extern rtx        gen_rotlv4si3                 (rtx, rtx, rtx);
extern rtx        gen_rotrv4si3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_selectdp              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_ashlv2di3                 (rtx, rtx, rtx);
extern rtx        gen_ssashlv2di3               (rtx, rtx, rtx);
extern rtx        gen_usashlv2di3               (rtx, rtx, rtx);
extern rtx        gen_ashrv2di3                 (rtx, rtx, rtx);
extern rtx        gen_lshrv2di3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_srsdps                (rtx, rtx, rtx);
extern rtx        gen_kvx_selecthx              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_selectwo              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_ashlv16hi3                (rtx, rtx, rtx);
extern rtx        gen_ashlv8si3                 (rtx, rtx, rtx);
extern rtx        gen_ssashlv16hi3              (rtx, rtx, rtx);
extern rtx        gen_ssashlv8si3               (rtx, rtx, rtx);
extern rtx        gen_usashlv16hi3              (rtx, rtx, rtx);
extern rtx        gen_usashlv8si3               (rtx, rtx, rtx);
extern rtx        gen_ashrv16hi3                (rtx, rtx, rtx);
extern rtx        gen_ashrv8si3                 (rtx, rtx, rtx);
extern rtx        gen_lshrv16hi3                (rtx, rtx, rtx);
extern rtx        gen_lshrv8si3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_srshxs                (rtx, rtx, rtx);
extern rtx        gen_kvx_srswos                (rtx, rtx, rtx);
extern rtx        gen_avgv16hi3_floor           (rtx, rtx, rtx);
extern rtx        gen_avgv8si3_floor            (rtx, rtx, rtx);
extern rtx        gen_avgv16hi3_ceil            (rtx, rtx, rtx);
extern rtx        gen_avgv8si3_ceil             (rtx, rtx, rtx);
extern rtx        gen_uavgv16hi3_floor          (rtx, rtx, rtx);
extern rtx        gen_uavgv8si3_floor           (rtx, rtx, rtx);
extern rtx        gen_uavgv16hi3_ceil           (rtx, rtx, rtx);
extern rtx        gen_uavgv8si3_ceil            (rtx, rtx, rtx);
extern rtx        gen_mulv16hi3                 (rtx, rtx, rtx);
extern rtx        gen_mulv4di3                  (rtx, rtx, rtx);
extern rtx        gen_addv16hi3                 (rtx, rtx, rtx);
extern rtx        gen_addv8si3                  (rtx, rtx, rtx);
extern rtx        gen_addv4di3                  (rtx, rtx, rtx);
extern rtx        gen_ssaddv16hi3               (rtx, rtx, rtx);
extern rtx        gen_ssaddv8si3                (rtx, rtx, rtx);
extern rtx        gen_ssaddv4di3                (rtx, rtx, rtx);
extern rtx        gen_usaddv16hi3               (rtx, rtx, rtx);
extern rtx        gen_usaddv8si3                (rtx, rtx, rtx);
extern rtx        gen_usaddv4di3                (rtx, rtx, rtx);
extern rtx        gen_subv16hi3                 (rtx, rtx, rtx);
extern rtx        gen_subv8si3                  (rtx, rtx, rtx);
extern rtx        gen_subv4di3                  (rtx, rtx, rtx);
extern rtx        gen_sssubv16hi3               (rtx, rtx, rtx);
extern rtx        gen_sssubv8si3                (rtx, rtx, rtx);
extern rtx        gen_sssubv4di3                (rtx, rtx, rtx);
extern rtx        gen_ussubv16hi3               (rtx, rtx, rtx);
extern rtx        gen_ussubv8si3                (rtx, rtx, rtx);
extern rtx        gen_ussubv4di3                (rtx, rtx, rtx);
extern rtx        gen_sminv16hi3                (rtx, rtx, rtx);
extern rtx        gen_sminv8si3                 (rtx, rtx, rtx);
extern rtx        gen_sminv4di3                 (rtx, rtx, rtx);
extern rtx        gen_smaxv16hi3                (rtx, rtx, rtx);
extern rtx        gen_smaxv8si3                 (rtx, rtx, rtx);
extern rtx        gen_smaxv4di3                 (rtx, rtx, rtx);
extern rtx        gen_uminv16hi3                (rtx, rtx, rtx);
extern rtx        gen_uminv8si3                 (rtx, rtx, rtx);
extern rtx        gen_uminv4di3                 (rtx, rtx, rtx);
extern rtx        gen_umaxv16hi3                (rtx, rtx, rtx);
extern rtx        gen_umaxv8si3                 (rtx, rtx, rtx);
extern rtx        gen_umaxv4di3                 (rtx, rtx, rtx);
extern rtx        gen_andv16hi3                 (rtx, rtx, rtx);
extern rtx        gen_andv8si3                  (rtx, rtx, rtx);
extern rtx        gen_andv4di3                  (rtx, rtx, rtx);
extern rtx        gen_iorv16hi3                 (rtx, rtx, rtx);
extern rtx        gen_iorv8si3                  (rtx, rtx, rtx);
extern rtx        gen_iorv4di3                  (rtx, rtx, rtx);
extern rtx        gen_xorv16hi3                 (rtx, rtx, rtx);
extern rtx        gen_xorv8si3                  (rtx, rtx, rtx);
extern rtx        gen_xorv4di3                  (rtx, rtx, rtx);
extern rtx        gen_maddv16hiv16hi4           (rtx, rtx, rtx, rtx);
extern rtx        gen_maddv8siv8si4             (rtx, rtx, rtx, rtx);
extern rtx        gen_maddv4div4di4             (rtx, rtx, rtx, rtx);
extern rtx        gen_msubv16hiv16hi4           (rtx, rtx, rtx, rtx);
extern rtx        gen_msubv8siv8si4             (rtx, rtx, rtx, rtx);
extern rtx        gen_msubv4div4di4             (rtx, rtx, rtx, rtx);
extern rtx        gen_rotlv16hi3                (rtx, rtx, rtx);
extern rtx        gen_rotlv8si3                 (rtx, rtx, rtx);
extern rtx        gen_rotlv4di3                 (rtx, rtx, rtx);
extern rtx        gen_rotrv16hi3                (rtx, rtx, rtx);
extern rtx        gen_rotrv8si3                 (rtx, rtx, rtx);
extern rtx        gen_rotrv4di3                 (rtx, rtx, rtx);
extern rtx        gen_negv16hi2                 (rtx, rtx);
extern rtx        gen_negv8si2                  (rtx, rtx);
extern rtx        gen_negv4di2                  (rtx, rtx);
extern rtx        gen_ssnegv16hi2               (rtx, rtx);
extern rtx        gen_ssnegv8si2                (rtx, rtx);
extern rtx        gen_ssnegv4di2                (rtx, rtx);
extern rtx        gen_absv16hi2                 (rtx, rtx);
extern rtx        gen_absv8si2                  (rtx, rtx);
extern rtx        gen_absv4di2                  (rtx, rtx);
extern rtx        gen_ssabsv16hi2               (rtx, rtx);
extern rtx        gen_ssabsv8si2                (rtx, rtx);
extern rtx        gen_ssabsv4di2                (rtx, rtx);
extern rtx        gen_clrsbv16hi2               (rtx, rtx);
extern rtx        gen_clrsbv8si2                (rtx, rtx);
extern rtx        gen_clrsbv4di2                (rtx, rtx);
extern rtx        gen_clzv16hi2                 (rtx, rtx);
extern rtx        gen_clzv8si2                  (rtx, rtx);
extern rtx        gen_clzv4di2                  (rtx, rtx);
extern rtx        gen_ctzv16hi2                 (rtx, rtx);
extern rtx        gen_ctzv8si2                  (rtx, rtx);
extern rtx        gen_ctzv4di2                  (rtx, rtx);
extern rtx        gen_popcountv16hi2            (rtx, rtx);
extern rtx        gen_popcountv8si2             (rtx, rtx);
extern rtx        gen_popcountv4di2             (rtx, rtx);
extern rtx        gen_one_cmplv16hi2            (rtx, rtx);
extern rtx        gen_one_cmplv8si2             (rtx, rtx);
extern rtx        gen_one_cmplv4di2             (rtx, rtx);
extern rtx        gen_abdv16hi3                 (rtx, rtx, rtx);
extern rtx        gen_abdv8si3                  (rtx, rtx, rtx);
extern rtx        gen_abdv4di3                  (rtx, rtx, rtx);
extern rtx        gen_ssabdv16hi3               (rtx, rtx, rtx);
extern rtx        gen_ssabdv8si3                (rtx, rtx, rtx);
extern rtx        gen_ssabdv4di3                (rtx, rtx, rtx);
extern rtx        gen_mulv8si3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_selectdq              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_ashlv4di3                 (rtx, rtx, rtx);
extern rtx        gen_ssashlv4di3               (rtx, rtx, rtx);
extern rtx        gen_usashlv4di3               (rtx, rtx, rtx);
extern rtx        gen_ashrv4di3                 (rtx, rtx, rtx);
extern rtx        gen_lshrv4di3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_srsdqs                (rtx, rtx, rtx);
extern rtx        gen_kvx_selectfhq             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_selectfwp             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_addv4hf3                  (rtx, rtx, rtx);
extern rtx        gen_addv2sf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_faddhq                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_faddwp                (rtx, rtx, rtx, rtx);
extern rtx        gen_subv4hf3                  (rtx, rtx, rtx);
extern rtx        gen_subv2sf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfhq                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfwp                (rtx, rtx, rtx, rtx);
extern rtx        gen_mulv4hf3                  (rtx, rtx, rtx);
extern rtx        gen_mulv2sf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fmulhq                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwp                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmav4hf4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_fmav2sf4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmahq                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawp                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav4hf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav2sf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmshq                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswp                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fminv4hf3                 (rtx, rtx, rtx);
extern rtx        gen_fminv2sf3                 (rtx, rtx, rtx);
extern rtx        gen_fmaxv4hf3                 (rtx, rtx, rtx);
extern rtx        gen_fmaxv2sf3                 (rtx, rtx, rtx);
extern rtx        gen_negv4hf2                  (rtx, rtx);
extern rtx        gen_negv2sf2                  (rtx, rtx);
extern rtx        gen_absv4hf2                  (rtx, rtx);
extern rtx        gen_absv2sf2                  (rtx, rtx);
extern rtx        gen_kvx_fmulhwq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwdp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmahwq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawdp               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmshwq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswdp               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fwidenhwq             (rtx, rtx, rtx);
extern rtx        gen_kvx_fwidenwdp             (rtx, rtx, rtx);
extern rtx        gen_kvx_fnarrowwhq            (rtx, rtx, rtx);
extern rtx        gen_kvx_fnarrowdwp            (rtx, rtx, rtx);
extern rtx        gen_kvx_fdot2w                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fdot2wd               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fdot2wdp              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fdot2wzp              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwc                (rtx, rtx, rtx, rtx);
extern rtx        gen_floatv2siv2sf2            (rtx, rtx);
extern rtx        gen_kvx_floatwp               (rtx, rtx, rtx, rtx);
extern rtx        gen_floatunsv2siv2sf2         (rtx, rtx);
extern rtx        gen_kvx_floatuwp              (rtx, rtx, rtx, rtx);
extern rtx        gen_fix_truncv2sfv2si2        (rtx, rtx);
extern rtx        gen_kvx_fixedwp               (rtx, rtx, rtx, rtx);
extern rtx        gen_fixuns_truncv2sfv2si2     (rtx, rtx);
extern rtx        gen_kvx_fixeduwp              (rtx, rtx, rtx, rtx);
extern rtx        gen_extendv2sfv2df2           (rtx, rtx);
extern rtx        gen_kvx_fcdivwp_insn          (rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivwp_insn          (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrecwp               (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrsrwp               (rtx, rtx, rtx);
extern rtx        gen_kvx_fconjwc               (rtx, rtx);
extern rtx        gen_kvx_fmm212w               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmma212w              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmms212w              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_consfwp               (rtx, rtx, rtx);
extern rtx        gen_kvx_selectfho             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_selectfwq             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fmav8hf4_1                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmav4sf4_1                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmav8hf4_2                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmav4sf4_2                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmaho_1              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawq_1              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmaho_2              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawq_2              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav8hf4_1               (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav4sf4_1               (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav8hf4_2               (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav4sf4_2               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsho_1              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswq_1              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsho_2              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswq_2              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fminv8hf3                 (rtx, rtx, rtx);
extern rtx        gen_fminv4sf3                 (rtx, rtx, rtx);
extern rtx        gen_fminv2df3                 (rtx, rtx, rtx);
extern rtx        gen_fmaxv8hf3                 (rtx, rtx, rtx);
extern rtx        gen_fmaxv4sf3                 (rtx, rtx, rtx);
extern rtx        gen_fmaxv2df3                 (rtx, rtx, rtx);
extern rtx        gen_negv8hf2                  (rtx, rtx);
extern rtx        gen_negv4sf2                  (rtx, rtx);
extern rtx        gen_negv2df2                  (rtx, rtx);
extern rtx        gen_absv8hf2                  (rtx, rtx);
extern rtx        gen_absv4sf2                  (rtx, rtx);
extern rtx        gen_absv2df2                  (rtx, rtx);
extern rtx        gen_kvx_fmulhwo               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwdq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmahwo               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawdq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmshwo               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswdq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_addv8hf3_1                (rtx, rtx, rtx);
extern rtx        gen_addv8hf3_2                (rtx, rtx, rtx);
extern rtx        gen_kvx_faddho_1              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_faddho_2              (rtx, rtx, rtx, rtx);
extern rtx        gen_subv8hf3_1                (rtx, rtx, rtx);
extern rtx        gen_subv8hf3_2                (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfho_1              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfho_2              (rtx, rtx, rtx, rtx);
extern rtx        gen_mulv8hf3_1                (rtx, rtx, rtx);
extern rtx        gen_mulv8hf3_2                (rtx, rtx, rtx);
extern rtx        gen_kvx_fmulho_1              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulho_2              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwcp_1             (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwcp_2             (rtx, rtx, rtx, rtx);
extern rtx        gen_addv4sf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_faddwq                (rtx, rtx, rtx, rtx);
extern rtx        gen_subv4sf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfwq                (rtx, rtx, rtx, rtx);
extern rtx        gen_mulv4sf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwq                (rtx, rtx, rtx, rtx);
extern rtx        gen_floatv4siv4sf2            (rtx, rtx);
extern rtx        gen_kvx_floatwq               (rtx, rtx, rtx, rtx);
extern rtx        gen_floatunsv4siv4sf2         (rtx, rtx);
extern rtx        gen_kvx_floatuwq              (rtx, rtx, rtx, rtx);
extern rtx        gen_fix_truncv4sfv4si2        (rtx, rtx);
extern rtx        gen_kvx_fixedwq               (rtx, rtx, rtx, rtx);
extern rtx        gen_fixuns_truncv4sfv4si2     (rtx, rtx);
extern rtx        gen_kvx_fixeduwq              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fconjwcp              (rtx, rtx);
extern rtx        gen_kvx_selectfdp             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_addv2df3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fadddp                (rtx, rtx, rtx, rtx);
extern rtx        gen_subv2df3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfdp                (rtx, rtx, rtx, rtx);
extern rtx        gen_mulv2df3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fmuldp                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmav2df4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmadp                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav2df4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsdp                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_floatv2div2df2            (rtx, rtx);
extern rtx        gen_kvx_floatdp               (rtx, rtx, rtx, rtx);
extern rtx        gen_floatunsv2div2df2         (rtx, rtx);
extern rtx        gen_kvx_floatudp              (rtx, rtx, rtx, rtx);
extern rtx        gen_fix_truncv2dfv2di2        (rtx, rtx);
extern rtx        gen_kvx_fixeddp               (rtx, rtx, rtx, rtx);
extern rtx        gen_fixuns_truncv2dfv2di2     (rtx, rtx);
extern rtx        gen_kvx_fixedudp              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fconjdc               (rtx, rtx);
extern rtx        gen_kvx_selectfhx             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_selectfwo             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fmav16hf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_fmav8sf4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmahx                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawo                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav16hf4                (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav8sf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmshx                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswo                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fminv16hf3                (rtx, rtx, rtx);
extern rtx        gen_fminv8sf3                 (rtx, rtx, rtx);
extern rtx        gen_fminv4df3                 (rtx, rtx, rtx);
extern rtx        gen_fmaxv16hf3                (rtx, rtx, rtx);
extern rtx        gen_fmaxv8sf3                 (rtx, rtx, rtx);
extern rtx        gen_fmaxv4df3                 (rtx, rtx, rtx);
extern rtx        gen_negv16hf2                 (rtx, rtx);
extern rtx        gen_negv8sf2                  (rtx, rtx);
extern rtx        gen_negv4df2                  (rtx, rtx);
extern rtx        gen_absv16hf2                 (rtx, rtx);
extern rtx        gen_absv8sf2                  (rtx, rtx);
extern rtx        gen_absv4df2                  (rtx, rtx);
extern rtx        gen_addv16hf3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_faddhx                (rtx, rtx, rtx, rtx);
extern rtx        gen_subv16hf3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfhx                (rtx, rtx, rtx, rtx);
extern rtx        gen_mulv16hf3                 (rtx, rtx, rtx);
extern rtx        gen_kvx_fmulhx                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwcq               (rtx, rtx, rtx, rtx);
extern rtx        gen_addv8sf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_faddwo                (rtx, rtx, rtx, rtx);
extern rtx        gen_subv8sf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfwo                (rtx, rtx, rtx, rtx);
extern rtx        gen_mulv8sf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwo                (rtx, rtx, rtx, rtx);
extern rtx        gen_floatv8siv8sf2            (rtx, rtx);
extern rtx        gen_kvx_floatwo               (rtx, rtx, rtx, rtx);
extern rtx        gen_floatunsv8siv8sf2         (rtx, rtx);
extern rtx        gen_kvx_floatuwo              (rtx, rtx, rtx, rtx);
extern rtx        gen_fix_truncv8sfv8si2        (rtx, rtx);
extern rtx        gen_kvx_fixedwo               (rtx, rtx, rtx, rtx);
extern rtx        gen_fixuns_truncv8sfv8si2     (rtx, rtx);
extern rtx        gen_kvx_fixeduwo              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fconjwcq              (rtx, rtx);
extern rtx        gen_kvx_selectfdq             (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_addv4df3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fadddq                (rtx, rtx, rtx, rtx);
extern rtx        gen_subv4df3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfdq                (rtx, rtx, rtx, rtx);
extern rtx        gen_mulv4df3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fmuldq                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmav4df4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmadq                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav4df4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsdq                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_floatv4div4df2            (rtx, rtx);
extern rtx        gen_kvx_floatdq               (rtx, rtx, rtx, rtx);
extern rtx        gen_floatunsv4div4df2         (rtx, rtx);
extern rtx        gen_kvx_floatudq              (rtx, rtx, rtx, rtx);
extern rtx        gen_fix_truncv4dfv4di2        (rtx, rtx);
extern rtx        gen_kvx_fixeddq               (rtx, rtx, rtx, rtx);
extern rtx        gen_fixuns_truncv4dfv4di2     (rtx, rtx);
extern rtx        gen_kvx_fixedudq              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fconjdcp              (rtx, rtx);
extern rtx        gen_kvx_consbx                (rtx, rtx, rtx);
extern rtx        gen_kvx_consho                (rtx, rtx, rtx);
extern rtx        gen_kvx_conswq                (rtx, rtx, rtx);
extern rtx        gen_kvx_consfho               (rtx, rtx, rtx);
extern rtx        gen_kvx_consfwq               (rtx, rtx, rtx);
extern rtx        gen_kvx_consdp                (rtx, rtx, rtx);
extern rtx        gen_kvx_consfdp               (rtx, rtx, rtx);
extern rtx        gen_kvx_consbv                (rtx, rtx, rtx);
extern rtx        gen_kvx_conshx                (rtx, rtx, rtx);
extern rtx        gen_kvx_conswo                (rtx, rtx, rtx);
extern rtx        gen_kvx_consfhx               (rtx, rtx, rtx);
extern rtx        gen_kvx_consfwo               (rtx, rtx, rtx);
extern rtx        gen_kvx_consdq                (rtx, rtx, rtx);
extern rtx        gen_kvx_consfdq               (rtx, rtx, rtx);
extern rtx        gen_kvx_lbo                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lhq                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lfhq                  (rtx, rtx, rtx);
extern rtx        gen_kvx_lwp                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lfwp                  (rtx, rtx, rtx);
extern rtx        gen_kvx_sbo                   (rtx, rtx);
extern rtx        gen_kvx_shq                   (rtx, rtx);
extern rtx        gen_kvx_sfhq                  (rtx, rtx);
extern rtx        gen_kvx_swp                   (rtx, rtx);
extern rtx        gen_kvx_sfwp                  (rtx, rtx);
extern rtx        gen_kvx_lbx                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lho                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lfho                  (rtx, rtx, rtx);
extern rtx        gen_kvx_lwq                   (rtx, rtx, rtx);
extern rtx        gen_kvx_ldp                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lfwq                  (rtx, rtx, rtx);
extern rtx        gen_kvx_lfdp                  (rtx, rtx, rtx);
extern rtx        gen_kvx_sbx                   (rtx, rtx);
extern rtx        gen_kvx_sho                   (rtx, rtx);
extern rtx        gen_kvx_sfho                  (rtx, rtx);
extern rtx        gen_kvx_swq                   (rtx, rtx);
extern rtx        gen_kvx_sdp                   (rtx, rtx);
extern rtx        gen_kvx_sfwq                  (rtx, rtx);
extern rtx        gen_kvx_sfdp                  (rtx, rtx);
extern rtx        gen_kvx_lbv                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lhx                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lfhx                  (rtx, rtx, rtx);
extern rtx        gen_kvx_lwo                   (rtx, rtx, rtx);
extern rtx        gen_kvx_ldq                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lfwo                  (rtx, rtx, rtx);
extern rtx        gen_kvx_lfdq                  (rtx, rtx, rtx);
extern rtx        gen_kvx_sbv                   (rtx, rtx);
extern rtx        gen_kvx_shx                   (rtx, rtx);
extern rtx        gen_kvx_sfhx                  (rtx, rtx);
extern rtx        gen_kvx_swo                   (rtx, rtx);
extern rtx        gen_kvx_sdq                   (rtx, rtx);
extern rtx        gen_kvx_sfwo                  (rtx, rtx);
extern rtx        gen_kvx_sfdq                  (rtx, rtx);
extern rtx        gen_kvx_lvo                   (rtx, rtx, rtx);
extern rtx        gen_kvx_lvbv                  (rtx, rtx, rtx);
extern rtx        gen_kvx_lvhx                  (rtx, rtx, rtx);
extern rtx        gen_kvx_lvfhx                 (rtx, rtx, rtx);
extern rtx        gen_kvx_lvwo                  (rtx, rtx, rtx);
extern rtx        gen_kvx_lvdq                  (rtx, rtx, rtx);
extern rtx        gen_kvx_lvfwo                 (rtx, rtx, rtx);
extern rtx        gen_kvx_lvfdq                 (rtx, rtx, rtx);
extern rtx        gen_kvx_svo                   (rtx, rtx);
extern rtx        gen_kvx_svbv                  (rtx, rtx);
extern rtx        gen_kvx_svhx                  (rtx, rtx);
extern rtx        gen_kvx_svfhx                 (rtx, rtx);
extern rtx        gen_kvx_svwo                  (rtx, rtx);
extern rtx        gen_kvx_svdq                  (rtx, rtx);
extern rtx        gen_kvx_svfwo                 (rtx, rtx);
extern rtx        gen_kvx_svfdq                 (rtx, rtx);
extern rtx        gen_kvx_movetoo               (rtx, rtx);
extern rtx        gen_kvx_movetobv              (rtx, rtx);
extern rtx        gen_kvx_movetohx              (rtx, rtx);
extern rtx        gen_kvx_movetofhx             (rtx, rtx);
extern rtx        gen_kvx_movetowo              (rtx, rtx);
extern rtx        gen_kvx_movetodq              (rtx, rtx);
extern rtx        gen_kvx_movetofwo             (rtx, rtx);
extern rtx        gen_kvx_movetofdq             (rtx, rtx);
extern rtx        gen_kvx_movefoo               (rtx, rtx);
extern rtx        gen_kvx_movefobv              (rtx, rtx);
extern rtx        gen_kvx_movefohx              (rtx, rtx);
extern rtx        gen_kvx_movefofhx             (rtx, rtx);
extern rtx        gen_kvx_movefowo              (rtx, rtx);
extern rtx        gen_kvx_movefodq              (rtx, rtx);
extern rtx        gen_kvx_movefofwo             (rtx, rtx);
extern rtx        gen_kvx_movefofdq             (rtx, rtx);
extern rtx        gen_kvx_swapvoo               (rtx, rtx, rtx);
extern rtx        gen_kvx_swapvobv              (rtx, rtx, rtx);
extern rtx        gen_kvx_swapvohx              (rtx, rtx, rtx);
extern rtx        gen_kvx_swapvofhx             (rtx, rtx, rtx);
extern rtx        gen_kvx_swapvowo              (rtx, rtx, rtx);
extern rtx        gen_kvx_swapvodq              (rtx, rtx, rtx);
extern rtx        gen_kvx_swapvofwo             (rtx, rtx, rtx);
extern rtx        gen_kvx_swapvofdq             (rtx, rtx, rtx);
extern rtx        gen_kvx_alignoo               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_alignobv              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_alignohx              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_alignofhx             (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_alignowo              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_alignodq              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_alignofwo             (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_alignofdq             (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_alignv                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_copyv                 (rtx, rtx);
extern rtx        gen_kvx_mt4x4d                (rtx, rtx);
extern rtx        gen_kvx_mm4abw                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmm4ahw0              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmm4ahw1              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmm4ahw2              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmm4ahw3              (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredi4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapsi (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapdi (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_loadqi             (rtx, rtx, rtx);
extern rtx        gen_atomic_loadhi             (rtx, rtx, rtx);
extern rtx        gen_atomic_loadsi             (rtx, rtx, rtx);
extern rtx        gen_atomic_loaddi             (rtx, rtx, rtx);
extern rtx        gen_atomic_loadti             (rtx, rtx, rtx);
extern rtx        gen_atomic_storeqi            (rtx, rtx, rtx);
extern rtx        gen_atomic_storehi            (rtx, rtx, rtx);
extern rtx        gen_atomic_storesi            (rtx, rtx, rtx);
extern rtx        gen_atomic_storedi            (rtx, rtx, rtx);
extern rtx        gen_atomic_storeti            (rtx, rtx, rtx);
extern rtx        gen_atomic_exchangesi         (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangedi         (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_addsi              (rtx, rtx, rtx);
extern rtx        gen_atomic_orsi               (rtx, rtx, rtx);
extern rtx        gen_atomic_xorsi              (rtx, rtx, rtx);
extern rtx        gen_atomic_subsi              (rtx, rtx, rtx);
extern rtx        gen_atomic_andsi              (rtx, rtx, rtx);
extern rtx        gen_atomic_nandsi             (rtx, rtx, rtx);
extern rtx        gen_atomic_adddi              (rtx, rtx, rtx);
extern rtx        gen_atomic_ordi               (rtx, rtx, rtx);
extern rtx        gen_atomic_xordi              (rtx, rtx, rtx);
extern rtx        gen_atomic_subdi              (rtx, rtx, rtx);
extern rtx        gen_atomic_anddi              (rtx, rtx, rtx);
extern rtx        gen_atomic_nanddi             (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addsi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orsi         (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorsi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subsi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andsi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandsi       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_adddi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_ordi         (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xordi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subdi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_anddi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nanddi       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_add_fetchsi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_or_fetchsi         (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_xor_fetchsi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_sub_fetchsi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_and_fetchsi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_nand_fetchsi       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_add_fetchdi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_or_fetchdi         (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_xor_fetchdi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_sub_fetchdi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_and_fetchdi        (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_nand_fetchdi       (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_test_and_set       (rtx, rtx, rtx);
extern rtx        gen_mem_thread_fence          (rtx);
extern rtx        gen_mem_signal_fence          (rtx);
extern rtx        gen_store_multiple            (rtx, rtx, rtx);
extern rtx        gen_load_multiple             (rtx, rtx, rtx);
extern rtx        gen_movqi                     (rtx, rtx);
extern rtx        gen_movhi                     (rtx, rtx);
extern rtx        gen_movhf                     (rtx, rtx);
extern rtx        gen_movsi                     (rtx, rtx);
extern rtx        gen_movsf                     (rtx, rtx);
extern rtx        gen_movdi                     (rtx, rtx);
extern rtx        gen_movdf                     (rtx, rtx);
extern rtx        gen_indirect_jump             (rtx);
extern rtx        gen_tablejump                 (rtx, rtx);
extern rtx        gen_kvx_dzerol                (rtx);
extern rtx        gen_memory_barrier            (void);
extern rtx        gen_call                      (rtx, rtx);
extern rtx        gen_call_value                (rtx, rtx, rtx);
extern rtx        gen_sibcall_value             (rtx, rtx, rtx);
extern rtx        gen_sibcall                   (rtx, rtx);
extern rtx        gen_prologue                  (void);
extern rtx        gen_epilogue                  (void);
extern rtx        gen_sibcall_epilogue          (void);
extern rtx        gen_untyped_call              (rtx, rtx, rtx);
extern rtx        gen_doloop_end                (rtx, rtx);
extern rtx        gen_reload_in_gotoff_si       (rtx, rtx, rtx);
extern rtx        gen_reload_in_gotoff_di       (rtx, rtx, rtx);
extern rtx        gen_kvx_addw                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_addd                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfw                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfd                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shlw                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shld                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrw                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrd                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_negw                  (rtx, rtx, rtx);
extern rtx        gen_kvx_negd                  (rtx, rtx, rtx);
extern rtx        gen_kvx_absw                  (rtx, rtx, rtx);
extern rtx        gen_kvx_absd                  (rtx, rtx, rtx);
extern rtx        gen_kvx_abdw                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_abdd                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_bitcntw               (rtx, rtx, rtx);
extern rtx        gen_kvx_bitcntd               (rtx, rtx, rtx);
extern rtx        gen_divsi3                    (rtx, rtx, rtx);
extern rtx        gen_kvx_avgw                  (rtx, rtx, rtx, rtx);
extern rtx        gen_divdi3                    (rtx, rtx, rtx);
extern rtx        gen_addti3                    (rtx, rtx, rtx);
extern rtx        gen_subti3                    (rtx, rtx, rtx);
extern rtx        gen_multi3                    (rtx, rtx, rtx);
extern rtx        gen_divhf3                    (rtx, rtx, rtx);
extern rtx        gen_copysignhf3               (rtx, rtx, rtx);
extern rtx        gen_floatsihf2                (rtx, rtx);
extern rtx        gen_floatdihf2                (rtx, rtx);
extern rtx        gen_floatunssihf2             (rtx, rtx);
extern rtx        gen_floatunsdihf2             (rtx, rtx);
extern rtx        gen_extendhfdf2               (rtx, rtx);
extern rtx        gen_divsf3                    (rtx, rtx, rtx);
extern rtx        gen_copysignsf3               (rtx, rtx, rtx);
extern rtx        gen_sqrtsf2                   (rtx, rtx);
extern rtx        gen_recipsf2                  (rtx, rtx);
extern rtx        gen_rsqrtsf2                  (rtx, rtx);
extern rtx        gen_kvx_fcdivw                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivw                (rtx, rtx, rtx, rtx);
extern rtx        gen_copysigndf3               (rtx, rtx, rtx);
extern rtx        gen_truncdfhf2                (rtx, rtx);
extern rtx        gen_kvx_fcdivd                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivd                (rtx, rtx, rtx, rtx);
extern rtx        gen_movv8qi                   (rtx, rtx);
extern rtx        gen_movv4hi                   (rtx, rtx);
extern rtx        gen_movv4hf                   (rtx, rtx);
extern rtx        gen_movv2si                   (rtx, rtx);
extern rtx        gen_movv2sf                   (rtx, rtx);
extern rtx        gen_movti                     (rtx, rtx);
extern rtx        gen_movv16qi                  (rtx, rtx);
extern rtx        gen_movv8hi                   (rtx, rtx);
extern rtx        gen_movv8hf                   (rtx, rtx);
extern rtx        gen_movv4si                   (rtx, rtx);
extern rtx        gen_movv2di                   (rtx, rtx);
extern rtx        gen_movv4sf                   (rtx, rtx);
extern rtx        gen_movv2df                   (rtx, rtx);
extern rtx        gen_movoi                     (rtx, rtx);
extern rtx        gen_movv32qi                  (rtx, rtx);
extern rtx        gen_movv16hi                  (rtx, rtx);
extern rtx        gen_movv16hf                  (rtx, rtx);
extern rtx        gen_movv8si                   (rtx, rtx);
extern rtx        gen_movv4di                   (rtx, rtx);
extern rtx        gen_movv8sf                   (rtx, rtx);
extern rtx        gen_movv4df                   (rtx, rtx);
extern rtx        gen_vec_setv8qi               (rtx, rtx, rtx);
extern rtx        gen_vec_setv4hi               (rtx, rtx, rtx);
extern rtx        gen_vec_setv4hf               (rtx, rtx, rtx);
extern rtx        gen_vec_setv2si               (rtx, rtx, rtx);
extern rtx        gen_vec_setv2sf               (rtx, rtx, rtx);
extern rtx        gen_vec_setv16qi              (rtx, rtx, rtx);
extern rtx        gen_vec_setv8hi               (rtx, rtx, rtx);
extern rtx        gen_vec_setv8hf               (rtx, rtx, rtx);
extern rtx        gen_vec_setv4si               (rtx, rtx, rtx);
extern rtx        gen_vec_setv2di               (rtx, rtx, rtx);
extern rtx        gen_vec_setv4sf               (rtx, rtx, rtx);
extern rtx        gen_vec_setv2df               (rtx, rtx, rtx);
extern rtx        gen_vec_setv32qi              (rtx, rtx, rtx);
extern rtx        gen_vec_setv16hi              (rtx, rtx, rtx);
extern rtx        gen_vec_setv16hf              (rtx, rtx, rtx);
extern rtx        gen_vec_setv8si               (rtx, rtx, rtx);
extern rtx        gen_vec_setv4di               (rtx, rtx, rtx);
extern rtx        gen_vec_setv8sf               (rtx, rtx, rtx);
extern rtx        gen_vec_setv4df               (rtx, rtx, rtx);
extern rtx        gen_vec_extractv8qi           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv4hi           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv4hf           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv2si           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv2sf           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv16qi          (rtx, rtx, rtx);
extern rtx        gen_vec_extractv8hi           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv8hf           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv4si           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv2di           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv4sf           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv2df           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv32qi          (rtx, rtx, rtx);
extern rtx        gen_vec_extractv16hi          (rtx, rtx, rtx);
extern rtx        gen_vec_extractv16hf          (rtx, rtx, rtx);
extern rtx        gen_vec_extractv8si           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv4di           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv8sf           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv4df           (rtx, rtx, rtx);
extern rtx        gen_vec_initv8qi              (rtx, rtx);
extern rtx        gen_vec_initv4hi              (rtx, rtx);
extern rtx        gen_vec_initv4hf              (rtx, rtx);
extern rtx        gen_vec_initv2si              (rtx, rtx);
extern rtx        gen_vec_initv2sf              (rtx, rtx);
extern rtx        gen_vec_initv16qi             (rtx, rtx);
extern rtx        gen_vec_initv8hi              (rtx, rtx);
extern rtx        gen_vec_initv8hf              (rtx, rtx);
extern rtx        gen_vec_initv4si              (rtx, rtx);
extern rtx        gen_vec_initv2di              (rtx, rtx);
extern rtx        gen_vec_initv4sf              (rtx, rtx);
extern rtx        gen_vec_initv2df              (rtx, rtx);
extern rtx        gen_vec_initv32qi             (rtx, rtx);
extern rtx        gen_vec_initv16hi             (rtx, rtx);
extern rtx        gen_vec_initv16hf             (rtx, rtx);
extern rtx        gen_vec_initv8si              (rtx, rtx);
extern rtx        gen_vec_initv4di              (rtx, rtx);
extern rtx        gen_vec_initv8sf              (rtx, rtx);
extern rtx        gen_vec_initv4df              (rtx, rtx);
extern rtx        gen_vec_cmpv4hiv4hi           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv4hfv4hi           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv2siv2si           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv2sfv2si           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv8hiv8hi           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv8hfv8hi           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv4siv4si           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv2div2di           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv4sfv4si           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv2dfv2di           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv16hiv16hi         (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv16hfv16hi         (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv8siv8si           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv4div4di           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv8sfv8si           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpv4dfv4di           (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv4hiv4hi          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv4hfv4hi          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv2siv2si          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv2sfv2si          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv8hiv8hi          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv8hfv8hi          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv4siv4si          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv2div2di          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv4sfv4si          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv2dfv2di          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv16hiv16hi        (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv16hfv16hi        (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv8siv8si          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv4div4di          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv8sfv8si          (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_cmpuv4dfv4di          (rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hfv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2sfv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hiv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8hfv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4siv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2div4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4sfv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2dfv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hiv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv16hfv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8siv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4div4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv8sfv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv4hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv4hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv2si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv2sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv8hi             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv8hf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv4si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv2di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv4sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv2df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv16hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv16hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv8si             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv4di             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv8sf             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4dfv4df             (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hfv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2sfv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hiv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8hfv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4siv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2div4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4sfv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2dfv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv4hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv4hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv2si           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv2sf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv8hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv8hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv4si           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv2di           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv4sf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv2df           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv16hi          (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv16hf          (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv8si           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv4di           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv8sf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hiv4df           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv4hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv4hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv2si           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv2sf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv8hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv8hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv4si           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv2di           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv4sf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv2df           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv16hi          (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv16hf          (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv8si           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv4di           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv8sf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv16hfv4df           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8siv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4div4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8sfv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv4hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv4hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv2si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv2sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv8hi            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv8hf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv4si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv2di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv4sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv2df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv16hi           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv16hf           (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv8si            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv4di            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv8sf            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4dfv4df            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v4hiv4hi       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v4hfv4hi       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v2siv2si       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v2sfv2si       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v8hiv8hi       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v8hfv8hi       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v4siv4si       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v2div2di       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v4sfv4si       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v2dfv2di       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v16hiv16hi     (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v16hfv16hi     (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v8siv8si       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v4div4di       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v8sfv8si       (rtx, rtx, rtx, rtx);
extern rtx        gen_vcond_mask_v4dfv4di       (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_shr_v8qi              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v4hi              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v4hf              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v2si              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v2sf              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v16qi             (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v8hi              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v8hf              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v4si              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v2di              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v4sf              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v2df              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v32qi             (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v16hi             (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v16hf             (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v8si              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v4di              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v8sf              (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v4df              (rtx, rtx, rtx);
extern rtx        gen_kvx_addhq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_addwp                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfhq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfwp                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shlhqs                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shlwps                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrhqs                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrwps                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_avghq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_avgwp                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_neghq                 (rtx, rtx, rtx);
extern rtx        gen_kvx_negwp                 (rtx, rtx, rtx);
extern rtx        gen_kvx_abshq                 (rtx, rtx, rtx);
extern rtx        gen_kvx_abswp                 (rtx, rtx, rtx);
extern rtx        gen_kvx_bitcnthq              (rtx, rtx, rtx);
extern rtx        gen_kvx_bitcntwp              (rtx, rtx, rtx);
extern rtx        gen_kvx_abdhq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_abdwp                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_mulhwq                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_mulwdp                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_maddhwq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_maddwdp               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_msbfhwq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_msbfwdp               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_zxbho                 (rtx, rtx);
extern rtx        gen_kvx_zxhwq                 (rtx, rtx);
extern rtx        gen_kvx_qxbho                 (rtx, rtx);
extern rtx        gen_kvx_qxhwq                 (rtx, rtx);
extern rtx        gen_kvx_widenbho              (rtx, rtx, rtx);
extern rtx        gen_kvx_widenhwq              (rtx, rtx, rtx);
extern rtx        gen_kvx_trunchbo              (rtx, rtx);
extern rtx        gen_kvx_truncwhq              (rtx, rtx);
extern rtx        gen_kvx_fracthbo              (rtx, rtx);
extern rtx        gen_kvx_fractwhq              (rtx, rtx);
extern rtx        gen_kvx_sathbo                (rtx, rtx);
extern rtx        gen_kvx_satwhq                (rtx, rtx);
extern rtx        gen_kvx_satuhbo               (rtx, rtx);
extern rtx        gen_kvx_satuwhq               (rtx, rtx);
extern rtx        gen_kvx_narrowhbo             (rtx, rtx, rtx);
extern rtx        gen_kvx_narrowwhq             (rtx, rtx, rtx);
extern rtx        gen_kvx_qxwdp                 (rtx, rtx);
extern rtx        gen_kvx_widenwdp              (rtx, rtx, rtx);
extern rtx        gen_kvx_truncdwp              (rtx, rtx);
extern rtx        gen_kvx_fractdwp              (rtx, rtx);
extern rtx        gen_kvx_satdwp                (rtx, rtx);
extern rtx        gen_kvx_satudwp               (rtx, rtx);
extern rtx        gen_kvx_narrowdwp             (rtx, rtx, rtx);
extern rtx        gen_kvx_fractmdw              (rtx, rtx);
extern rtx        gen_kvx_satldw                (rtx, rtx);
extern rtx        gen_kvx_satmdw                (rtx, rtx);
extern rtx        gen_kvx_satuldw               (rtx, rtx);
extern rtx        gen_kvx_satumdw               (rtx, rtx);
extern rtx        gen_kvx_avgho                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_avgwq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_mulhwo                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_mulwdq                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_maddhwo               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_maddwdq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_msbfhwo               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_msbfwdq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_addho                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_addwq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_adddp                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfho                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfwq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfdp                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_negho                 (rtx, rtx, rtx);
extern rtx        gen_kvx_negwq                 (rtx, rtx, rtx);
extern rtx        gen_kvx_negdp                 (rtx, rtx, rtx);
extern rtx        gen_kvx_absho                 (rtx, rtx, rtx);
extern rtx        gen_kvx_abswq                 (rtx, rtx, rtx);
extern rtx        gen_kvx_absdp                 (rtx, rtx, rtx);
extern rtx        gen_kvx_bitcntho              (rtx, rtx, rtx);
extern rtx        gen_kvx_bitcntwq              (rtx, rtx, rtx);
extern rtx        gen_kvx_bitcntdp              (rtx, rtx, rtx);
extern rtx        gen_kvx_abdho                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_abdwq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_abddp                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_zxbhx                 (rtx, rtx);
extern rtx        gen_kvx_zxhwo                 (rtx, rtx);
extern rtx        gen_kvx_zxwdq                 (rtx, rtx);
extern rtx        gen_kvx_sxbhx                 (rtx, rtx);
extern rtx        gen_kvx_sxhwo                 (rtx, rtx);
extern rtx        gen_kvx_sxwdq                 (rtx, rtx);
extern rtx        gen_kvx_qxbhx                 (rtx, rtx);
extern rtx        gen_kvx_qxhwo                 (rtx, rtx);
extern rtx        gen_kvx_qxwdq                 (rtx, rtx);
extern rtx        gen_kvx_widenbhx              (rtx, rtx, rtx);
extern rtx        gen_kvx_widenhwo              (rtx, rtx, rtx);
extern rtx        gen_kvx_widenwdq              (rtx, rtx, rtx);
extern rtx        gen_kvx_trunchbx              (rtx, rtx);
extern rtx        gen_kvx_truncwho              (rtx, rtx);
extern rtx        gen_kvx_truncdwq              (rtx, rtx);
extern rtx        gen_kvx_fracthbx              (rtx, rtx);
extern rtx        gen_kvx_fractwho              (rtx, rtx);
extern rtx        gen_kvx_fractdwq              (rtx, rtx);
extern rtx        gen_kvx_sathbx                (rtx, rtx);
extern rtx        gen_kvx_satwho                (rtx, rtx);
extern rtx        gen_kvx_satdwq                (rtx, rtx);
extern rtx        gen_kvx_satuhbx               (rtx, rtx);
extern rtx        gen_kvx_satuwho               (rtx, rtx);
extern rtx        gen_kvx_satudwq               (rtx, rtx);
extern rtx        gen_kvx_narrowhbx             (rtx, rtx, rtx);
extern rtx        gen_kvx_narrowwho             (rtx, rtx, rtx);
extern rtx        gen_kvx_narrowdwq             (rtx, rtx, rtx);
extern rtx        gen_kvx_shlhos                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shlwqs                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shldps                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrhos                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrwqs                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrdps                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_avghx                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_avgwo                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_addhx                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_addwo                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_adddq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfhx                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfwo                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_sbfdq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_neghx                 (rtx, rtx, rtx);
extern rtx        gen_kvx_negwo                 (rtx, rtx, rtx);
extern rtx        gen_kvx_negdq                 (rtx, rtx, rtx);
extern rtx        gen_kvx_abshx                 (rtx, rtx, rtx);
extern rtx        gen_kvx_abswo                 (rtx, rtx, rtx);
extern rtx        gen_kvx_absdq                 (rtx, rtx, rtx);
extern rtx        gen_kvx_bitcnthx              (rtx, rtx, rtx);
extern rtx        gen_kvx_bitcntwo              (rtx, rtx, rtx);
extern rtx        gen_kvx_bitcntdq              (rtx, rtx, rtx);
extern rtx        gen_kvx_abdhx                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_abdwo                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_abddq                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shlhxs                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shlwos                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shldqs                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrhxs                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrwos                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shrdqs                (rtx, rtx, rtx, rtx);
extern rtx        gen_copysignv4hf3             (rtx, rtx, rtx);
extern rtx        gen_copysignv2sf3             (rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmaw                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmsw                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmdaw               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmsaw               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmdsw               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmasw               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawc                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswc                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_frecwp                (rtx, rtx, rtx);
extern rtx        gen_kvx_frsrwp                (rtx, rtx, rtx);
extern rtx        gen_kvx_fcdivwp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivwp               (rtx, rtx, rtx, rtx);
extern rtx        gen_divv2sf3                  (rtx, rtx, rtx);
extern rtx        gen_divv4sf3                  (rtx, rtx, rtx);
extern rtx        gen_divv8sf3                  (rtx, rtx, rtx);
extern rtx        gen_sqrtv2sf2                 (rtx, rtx);
extern rtx        gen_sqrtv4sf2                 (rtx, rtx);
extern rtx        gen_sqrtv8sf2                 (rtx, rtx);
extern rtx        gen_recipv2sf2                (rtx, rtx);
extern rtx        gen_recipv4sf2                (rtx, rtx);
extern rtx        gen_recipv8sf2                (rtx, rtx);
extern rtx        gen_rsqrtv2sf2                (rtx, rtx);
extern rtx        gen_rsqrtv4sf2                (rtx, rtx);
extern rtx        gen_rsqrtv8sf2                (rtx, rtx);
extern rtx        gen_fmav8hf4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_fmav4sf4                  (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmaho                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawq                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav8hf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav4sf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsho                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswq                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_copysignv8hf3             (rtx, rtx, rtx);
extern rtx        gen_copysignv4sf3             (rtx, rtx, rtx);
extern rtx        gen_kvx_fwidenhwo             (rtx, rtx, rtx);
extern rtx        gen_kvx_fwidenwdq             (rtx, rtx, rtx);
extern rtx        gen_kvx_fnarrowwho            (rtx, rtx, rtx);
extern rtx        gen_kvx_fnarrowdwq            (rtx, rtx, rtx);
extern rtx        gen_addv8hf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_faddho                (rtx, rtx, rtx, rtx);
extern rtx        gen_subv8hf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fsbfho                (rtx, rtx, rtx, rtx);
extern rtx        gen_mulv8hf3                  (rtx, rtx, rtx);
extern rtx        gen_kvx_fmulho                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmt22w                (rtx, rtx);
extern rtx        gen_kvx_fmm222w               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmma222w              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmms222w              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmawp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmswp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmdawp              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmsawp              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmdswp              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmaswp              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fmulwcp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawcp               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswcp               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_frecwq                (rtx, rtx, rtx);
extern rtx        gen_kvx_frsrwq                (rtx, rtx, rtx);
extern rtx        gen_kvx_fcdivwq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivwq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsrecwq               (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrsrwq               (rtx, rtx, rtx);
extern rtx        gen_kvx_fmuldc                (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmadc                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsdc                (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_copysignv2df3             (rtx, rtx, rtx);
extern rtx        gen_kvx_fcdivdp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivdp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsrecdp               (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrsrdp               (rtx, rtx, rtx);
extern rtx        gen_copysignv16hf3            (rtx, rtx, rtx);
extern rtx        gen_copysignv8sf3             (rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmawq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmswq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmdawq              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmsawq              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmdswq              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffdmaswq              (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmawcq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmswcq               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_frecwo                (rtx, rtx, rtx);
extern rtx        gen_kvx_frsrwo                (rtx, rtx, rtx);
extern rtx        gen_kvx_fcdivwo               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivwo               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsrecwo               (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrsrwo               (rtx, rtx, rtx);
extern rtx        gen_kvx_fmuldcp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmadcp               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_ffmsdcp               (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_copysignv4df3             (rtx, rtx, rtx);
extern rtx        gen_kvx_fcdivdq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsdivdq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_fsrecdq               (rtx, rtx, rtx);
extern rtx        gen_kvx_fsrsrdq               (rtx, rtx, rtx);
extern rtx        gen_kvx_shiftbo               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shifthq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftwp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftfhq              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftfwp              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftbx               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftho               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftwq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftfho              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftfwq              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftdp               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftfdp              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftbv               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shifthx               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftwo               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftfhx              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftfwo              (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftdq               (rtx, rtx, rtx, rtx);
extern rtx        gen_kvx_shiftfdq              (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredf4                 (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsi4                (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsf4                (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdi4                (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdf4                (rtx, rtx, rtx, rtx);
extern rtx        gen_movqicc                   (rtx, rtx, rtx, rtx);
extern rtx        gen_movhicc                   (rtx, rtx, rtx, rtx);
extern rtx        gen_movhfcc                   (rtx, rtx, rtx, rtx);
extern rtx        gen_movsicc                   (rtx, rtx, rtx, rtx);
extern rtx        gen_movsfcc                   (rtx, rtx, rtx, rtx);
extern rtx        gen_movdicc                   (rtx, rtx, rtx, rtx);
extern rtx        gen_movdfcc                   (rtx, rtx, rtx, rtx);
extern rtx        gen_movticc                   (rtx, rtx, rtx, rtx);
extern rtx        gen_movoicc                   (rtx, rtx, rtx, rtx);
extern rtx        gen_movv8qicc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv4hicc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv4hfcc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv2sicc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv2sfcc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv16qicc                (rtx, rtx, rtx, rtx);
extern rtx        gen_movv8hicc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv8hfcc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv4sicc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv2dicc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv4sfcc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv2dfcc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv32qicc                (rtx, rtx, rtx, rtx);
extern rtx        gen_movv16hicc                (rtx, rtx, rtx, rtx);
extern rtx        gen_movv16hfcc                (rtx, rtx, rtx, rtx);
extern rtx        gen_movv8sicc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv4dicc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv8sfcc                 (rtx, rtx, rtx, rtx);
extern rtx        gen_movv4dfcc                 (rtx, rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
