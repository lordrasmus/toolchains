#ifndef GCC_TM_P_H
#define GCC_TM_P_H
#ifdef IN_GCC
# include "config/kvx/kvx-protos.h"
# include "config/linux-protos.h"
# include "tm-preds.h"
#endif
#endif /* GCC_TM_P_H */
