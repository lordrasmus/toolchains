/* Generated automatically. */
static const char configuration_arguments[] = "/home/ramin/openadk-mb/toolchain_build_generic-microblaze_uclibc-ng_microblaze/w-gcc-15.3.0-1/gcc-15.3.0/configure --disable-multilib --prefix=/home/ramin/openadk-mb/toolchain_generic-microblaze_uclibc-ng_microblaze/usr --with-bugurl=https://openadk.org --build=x86_64-linux-gnu --host=x86_64-linux-gnu --target=microblaze-openadk-linux-uclibc --with-gmp=/home/ramin/openadk-mb/host_x86_64-linux-gnu/usr --with-mpfr=/home/ramin/openadk-mb/host_x86_64-linux-gnu/usr --enable-__cxa_atexit --with-system-zlib --with-gnu-ld --with-gnu-as --disable-install-libiberty --disable-libitm --disable-libmudflap --disable-libgomp --disable-libcc1 --disable-libmpx --disable-libcilkrts --disable-libquadmath --disable-libquadmath-support --disable-decimal-float --disable-gcov --disable-libstdcxx-pch --disable-ppl-version-check --disable-cloog-version-check --without-ppl --without-cloog --without-isl --disable-werror --disable-nls --enable-obsolete --disable-lto --disable-libsanitizer --enable-tls --enable-languages=c --with-newlib --disable-shared --disable-threads --disable-libatomic --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
