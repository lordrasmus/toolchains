/* Generated automatically by the program `genattr-common'
   from the machine description file `md'.  */

#ifndef GCC_INSN_ATTR_COMMON_H
#define GCC_INSN_ATTR_COMMON_H

enum attr_far_jump {FAR_JUMP_YES, FAR_JUMP_NO};
enum attr_type {TYPE_ALU, TYPE_LOAD, TYPE_STORE, TYPE_CMP, TYPE_BRANCH, TYPE_CBRANCH, TYPE_ADDSUB, TYPE_ALU_IX, TYPE_BRANCH_JMP, TYPE_CALL_JSR, TYPE_CALL};
enum attr_cycle {CYCLE_1, CYCLE_2, CYCLE_NOT_USED_YET};
#define INSN_SCHEDULING
#define DELAY_SLOTS 0

#endif /* GCC_INSN_ATTR_COMMON_H */
