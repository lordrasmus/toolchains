/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_movstrictqi 1
#define HAVE_movstricthi 1
#define HAVE_cmpsi (reload_completed)
#define HAVE_mulhi3 (TARGET_H8300SX)
#define HAVE_mulsi3 (TARGET_H8300SX)
#define HAVE_mulhi3_clobber_flags (TARGET_H8300SX)
#define HAVE_mulsi3_clobber_flags (TARGET_H8300SX)
#define HAVE_smulsi3_highpart (TARGET_H8300SXMUL)
#define HAVE_smulsi3_highpart_clobber_flags (TARGET_H8300SXMUL)
#define HAVE_umulsi3_highpart (TARGET_H8300SX)
#define HAVE_udivhi3 (TARGET_H8300SX)
#define HAVE_udivsi3 (TARGET_H8300SX)
#define HAVE_udivhi3_clobber_flags (TARGET_H8300SX)
#define HAVE_udivsi3_clobber_flags (TARGET_H8300SX)
#define HAVE_divhi3 (TARGET_H8300SX)
#define HAVE_divsi3 (TARGET_H8300SX)
#define HAVE_divhi3_clobber_flags (TARGET_H8300SX)
#define HAVE_divsi3_clobber_flags (TARGET_H8300SX)
#define HAVE_udivmodqi4 1
#define HAVE_udivmodqi4_clobber_flags 1
#define HAVE_divmodqi4 1
#define HAVE_divmodqi4_clobber_flags 1
#define HAVE_udivmodhi4 1
#define HAVE_udivmodhi4_clobber_flags 1
#define HAVE_divmodhi4 1
#define HAVE_divmodhi4_clobber_flags 1
#define HAVE_bclrqi_msx (TARGET_H8300SX && rtx_equal_p (operands[0], operands[1]))
#define HAVE_bclrhi_msx (TARGET_H8300SX && rtx_equal_p (operands[0], operands[1]))
#define HAVE_andqi3_1 (register_operand (operands[0], QImode) \
   || single_zero_operand (operands[2], QImode))
#define HAVE_biorqi_msx (TARGET_H8300SX && rtx_equal_p (operands[0], operands[1]))
#define HAVE_bxorqi_msx (TARGET_H8300SX && rtx_equal_p (operands[0], operands[1]))
#define HAVE_biorhi_msx (TARGET_H8300SX && rtx_equal_p (operands[0], operands[1]))
#define HAVE_bxorhi_msx (TARGET_H8300SX && rtx_equal_p (operands[0], operands[1]))
#define HAVE_iorqi3_1 (TARGET_H8300SX || register_operand (operands[0], QImode) \
   || single_one_operand (operands[2], QImode))
#define HAVE_xorqi3_1 (TARGET_H8300SX || register_operand (operands[0], QImode) \
   || single_one_operand (operands[2], QImode))
#define HAVE_one_cmplqi2 1
#define HAVE_one_cmplhi2 1
#define HAVE_one_cmplsi2 1
#define HAVE_one_cmplqi2_ 1
#define HAVE_one_cmplqi2__cczn 1
#define HAVE_one_cmplhi2_ 1
#define HAVE_one_cmplhi2__cczn 1
#define HAVE_one_cmplsi2_ 1
#define HAVE_one_cmplsi2__cczn 1
#define HAVE_abssf2 1
#define HAVE_abssf2_clobber_flags 1
#define HAVE_nop 1
#define HAVE_jump 1
#define HAVE_tablejumphi (Pmode == HImode)
#define HAVE_tablejumpsi (Pmode == SImode)
#define HAVE_call_insn_hi ((!SIBLING_CALL_P (insn)) && (Pmode == HImode))
#define HAVE_call_insn_si ((!SIBLING_CALL_P (insn)) && (Pmode == SImode))
#define HAVE_call_value_insn_hi ((!SIBLING_CALL_P (insn)) && (Pmode == HImode))
#define HAVE_call_value_insn_si ((!SIBLING_CALL_P (insn)) && (Pmode == SImode))
#define HAVE_sibcall_insn_hi ((SIBLING_CALL_P (insn)) && (Pmode == HImode))
#define HAVE_sibcall_insn_si ((SIBLING_CALL_P (insn)) && (Pmode == SImode))
#define HAVE_sibcall_value_insn_hi ((SIBLING_CALL_P (insn)) && (Pmode == HImode))
#define HAVE_sibcall_value_insn_si ((SIBLING_CALL_P (insn)) && (Pmode == SImode))
#define HAVE_ldm_h8300sx (TARGET_H8300S)
#define HAVE_stm_h8300sx (TARGET_H8300S)
#define HAVE_return_h8sx (TARGET_H8300SX)
#define HAVE_monitor_prologue 1
#define HAVE_rotlqi3_1 1
#define HAVE_rotlhi3_1 1
#define HAVE_rotlsi3_1 1
#define HAVE_rotlqi3_1_clobber_flags 1
#define HAVE_rotlhi3_1_clobber_flags 1
#define HAVE_rotlsi3_1_clobber_flags 1
#define HAVE_bfld (TARGET_H8300SX && INTVAL (operands[2]) + INTVAL (operands[3]) <= 8)
#define HAVE_bfld_clobber_flags (TARGET_H8300SX && INTVAL (operands[2]) + INTVAL (operands[3]) <= 8)
#define HAVE_bfst (TARGET_H8300SX && INTVAL (operands[2]) + INTVAL (operands[3]) <= 8)
#define HAVE_bfst_clobber_flags (TARGET_H8300SX && INTVAL (operands[2]) + INTVAL (operands[3]) <= 8)
#define HAVE_movqi 1
#define HAVE_movhi 1
#define HAVE_movsi 1
#define HAVE_movsf 1
#define HAVE_cstoreqi4 1
#define HAVE_cstorehi4 1
#define HAVE_cstoresi4 1
#define HAVE_addqi3 1
#define HAVE_addhi3 1
#define HAVE_addsi3 1
#define HAVE_subqi3 1
#define HAVE_subhi3 1
#define HAVE_subsi3 1
#define HAVE_negqi2 1
#define HAVE_neghi2 1
#define HAVE_negsi2 1
#define HAVE_negsf2 1
#define HAVE_mulqihi3 1
#define HAVE_mulhisi3 1
#define HAVE_umulqihi3 1
#define HAVE_umulhisi3 1
#define HAVE_iorqi3 1
#define HAVE_xorqi3 1
#define HAVE_andqi3 1
#define HAVE_iorhi3 1
#define HAVE_xorhi3 1
#define HAVE_andhi3 1
#define HAVE_iorsi3 1
#define HAVE_xorsi3 1
#define HAVE_andsi3 1
#define HAVE_cbranchqi4 1
#define HAVE_cbranchhi4 1
#define HAVE_cbranchsi4 1
#define HAVE_tablejump 1
#define HAVE_indirect_jump 1
#define HAVE_call 1
#define HAVE_call_value 1
#define HAVE_sibcall 1
#define HAVE_sibcall_value 1
#define HAVE_push_h8300hs_advanced (TARGET_H8300H && TARGET_H8300S && !TARGET_NORMAL_MODE)
#define HAVE_push_h8300hs_normal (TARGET_H8300H && TARGET_H8300S && TARGET_NORMAL_MODE)
#define HAVE_pop_h8300hs_advanced (TARGET_H8300H && TARGET_H8300S && !TARGET_NORMAL_MODE)
#define HAVE_pop_h8300hs_normal (TARGET_H8300H && TARGET_H8300S && TARGET_NORMAL_MODE)
#define HAVE_return (h8300_can_use_return_insn_p ())
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_zero_extendqihi2 1
#define HAVE_zero_extendqisi2 1
#define HAVE_zero_extendhisi2 1
#define HAVE_extendqihi2 1
#define HAVE_extendqisi2 1
#define HAVE_extendhisi2 1
#define HAVE_ashlqi3 1
#define HAVE_ashlhi3 1
#define HAVE_ashlsi3 1
#define HAVE_ashrqi3 1
#define HAVE_ashrhi3 1
#define HAVE_ashrsi3 1
#define HAVE_lshrqi3 1
#define HAVE_lshrhi3 1
#define HAVE_lshrsi3 1
#define HAVE_rotlqi3 1
#define HAVE_rotlhi3 1
#define HAVE_rotlsi3 1
#define HAVE_insv (TARGET_H8300SX)
#define HAVE_extzv (TARGET_H8300SX)
extern rtx        gen_movstrictqi                    (rtx, rtx);
extern rtx        gen_movstricthi                    (rtx, rtx);
extern rtx        gen_cmpsi                          (rtx, rtx);
extern rtx        gen_mulhi3                         (rtx, rtx, rtx);
extern rtx        gen_mulsi3                         (rtx, rtx, rtx);
extern rtx        gen_mulhi3_clobber_flags           (rtx, rtx, rtx);
extern rtx        gen_mulsi3_clobber_flags           (rtx, rtx, rtx);
extern rtx        gen_smulsi3_highpart               (rtx, rtx, rtx);
extern rtx        gen_smulsi3_highpart_clobber_flags (rtx, rtx, rtx);
extern rtx        gen_umulsi3_highpart               (rtx, rtx, rtx);
extern rtx        gen_udivhi3                        (rtx, rtx, rtx);
extern rtx        gen_udivsi3                        (rtx, rtx, rtx);
extern rtx        gen_udivhi3_clobber_flags          (rtx, rtx, rtx);
extern rtx        gen_udivsi3_clobber_flags          (rtx, rtx, rtx);
extern rtx        gen_divhi3                         (rtx, rtx, rtx);
extern rtx        gen_divsi3                         (rtx, rtx, rtx);
extern rtx        gen_divhi3_clobber_flags           (rtx, rtx, rtx);
extern rtx        gen_divsi3_clobber_flags           (rtx, rtx, rtx);
extern rtx        gen_udivmodqi4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_udivmodqi4_clobber_flags       (rtx, rtx, rtx, rtx);
extern rtx        gen_divmodqi4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_divmodqi4_clobber_flags        (rtx, rtx, rtx, rtx);
extern rtx        gen_udivmodhi4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_udivmodhi4_clobber_flags       (rtx, rtx, rtx, rtx);
extern rtx        gen_divmodhi4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_divmodhi4_clobber_flags        (rtx, rtx, rtx, rtx);
extern rtx        gen_bclrqi_msx                     (rtx, rtx, rtx);
extern rtx        gen_bclrhi_msx                     (rtx, rtx, rtx);
extern rtx        gen_andqi3_1                       (rtx, rtx, rtx);
extern rtx        gen_biorqi_msx                     (rtx, rtx, rtx);
extern rtx        gen_bxorqi_msx                     (rtx, rtx, rtx);
extern rtx        gen_biorhi_msx                     (rtx, rtx, rtx);
extern rtx        gen_bxorhi_msx                     (rtx, rtx, rtx);
extern rtx        gen_iorqi3_1                       (rtx, rtx, rtx);
extern rtx        gen_xorqi3_1                       (rtx, rtx, rtx);
extern rtx        gen_one_cmplqi2                    (rtx, rtx);
extern rtx        gen_one_cmplhi2                    (rtx, rtx);
extern rtx        gen_one_cmplsi2                    (rtx, rtx);
extern rtx        gen_one_cmplqi2_                   (rtx, rtx);
extern rtx        gen_one_cmplqi2__cczn              (rtx, rtx);
extern rtx        gen_one_cmplhi2_                   (rtx, rtx);
extern rtx        gen_one_cmplhi2__cczn              (rtx, rtx);
extern rtx        gen_one_cmplsi2_                   (rtx, rtx);
extern rtx        gen_one_cmplsi2__cczn              (rtx, rtx);
extern rtx        gen_abssf2                         (rtx, rtx);
extern rtx        gen_abssf2_clobber_flags           (rtx, rtx);
extern rtx        gen_nop                            (void);
extern rtx        gen_jump                           (rtx);
extern rtx        gen_tablejumphi                    (rtx, rtx);
extern rtx        gen_tablejumpsi                    (rtx, rtx);
extern rtx        gen_call_insn_hi                   (rtx, rtx);
extern rtx        gen_call_insn_si                   (rtx, rtx);
extern rtx        gen_call_value_insn_hi             (rtx, rtx, rtx);
extern rtx        gen_call_value_insn_si             (rtx, rtx, rtx);
extern rtx        gen_sibcall_insn_hi                (rtx, rtx);
extern rtx        gen_sibcall_insn_si                (rtx, rtx);
extern rtx        gen_sibcall_value_insn_hi          (rtx, rtx, rtx);
extern rtx        gen_sibcall_value_insn_si          (rtx, rtx, rtx);
extern rtx        gen_ldm_h8300sx                    (rtx, rtx, rtx);
extern rtx        gen_stm_h8300sx                    (rtx, rtx, rtx);
extern rtx        gen_return_h8sx                    (rtx, rtx, rtx);
extern rtx        gen_monitor_prologue               (void);
extern rtx        gen_rotlqi3_1                      (rtx, rtx, rtx);
extern rtx        gen_rotlhi3_1                      (rtx, rtx, rtx);
extern rtx        gen_rotlsi3_1                      (rtx, rtx, rtx);
extern rtx        gen_rotlqi3_1_clobber_flags        (rtx, rtx, rtx);
extern rtx        gen_rotlhi3_1_clobber_flags        (rtx, rtx, rtx);
extern rtx        gen_rotlsi3_1_clobber_flags        (rtx, rtx, rtx);
extern rtx        gen_bfld                           (rtx, rtx, rtx, rtx);
extern rtx        gen_bfld_clobber_flags             (rtx, rtx, rtx, rtx);
extern rtx        gen_bfst                           (rtx, rtx, rtx, rtx);
extern rtx        gen_bfst_clobber_flags             (rtx, rtx, rtx, rtx);
extern rtx        gen_movqi                          (rtx, rtx);
extern rtx        gen_movhi                          (rtx, rtx);
extern rtx        gen_movsi                          (rtx, rtx);
extern rtx        gen_movsf                          (rtx, rtx);
extern rtx        gen_cstoreqi4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_cstorehi4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresi4                      (rtx, rtx, rtx, rtx);
extern rtx        gen_addqi3                         (rtx, rtx, rtx);
extern rtx        gen_addhi3                         (rtx, rtx, rtx);
extern rtx        gen_addsi3                         (rtx, rtx, rtx);
extern rtx        gen_subqi3                         (rtx, rtx, rtx);
extern rtx        gen_subhi3                         (rtx, rtx, rtx);
extern rtx        gen_subsi3                         (rtx, rtx, rtx);
extern rtx        gen_negqi2                         (rtx, rtx);
extern rtx        gen_neghi2                         (rtx, rtx);
extern rtx        gen_negsi2                         (rtx, rtx);
extern rtx        gen_negsf2                         (rtx, rtx);
extern rtx        gen_mulqihi3                       (rtx, rtx, rtx);
extern rtx        gen_mulhisi3                       (rtx, rtx, rtx);
extern rtx        gen_umulqihi3                      (rtx, rtx, rtx);
extern rtx        gen_umulhisi3                      (rtx, rtx, rtx);
extern rtx        gen_iorqi3                         (rtx, rtx, rtx);
extern rtx        gen_xorqi3                         (rtx, rtx, rtx);
extern rtx        gen_andqi3                         (rtx, rtx, rtx);
extern rtx        gen_iorhi3                         (rtx, rtx, rtx);
extern rtx        gen_xorhi3                         (rtx, rtx, rtx);
extern rtx        gen_andhi3                         (rtx, rtx, rtx);
extern rtx        gen_iorsi3                         (rtx, rtx, rtx);
extern rtx        gen_xorsi3                         (rtx, rtx, rtx);
extern rtx        gen_andsi3                         (rtx, rtx, rtx);
extern rtx        gen_cbranchqi4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchhi4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsi4                     (rtx, rtx, rtx, rtx);
extern rtx        gen_tablejump                      (rtx, rtx);
extern rtx        gen_indirect_jump                  (rtx);
extern rtx        gen_call                           (rtx, rtx);
extern rtx        gen_call_value                     (rtx, rtx, rtx);
extern rtx        gen_sibcall                        (rtx, rtx);
extern rtx        gen_sibcall_value                  (rtx, rtx, rtx);
extern rtx        gen_push_h8300hs_advanced          (rtx);
extern rtx        gen_push_h8300hs_normal            (rtx);
extern rtx        gen_pop_h8300hs_advanced           (rtx);
extern rtx        gen_pop_h8300hs_normal             (rtx);
extern rtx        gen_return                         (void);
extern rtx        gen_prologue                       (void);
extern rtx        gen_epilogue                       (void);
extern rtx        gen_sibcall_epilogue               (void);
extern rtx        gen_zero_extendqihi2               (rtx, rtx);
extern rtx        gen_zero_extendqisi2               (rtx, rtx);
extern rtx        gen_zero_extendhisi2               (rtx, rtx);
extern rtx        gen_extendqihi2                    (rtx, rtx);
extern rtx        gen_extendqisi2                    (rtx, rtx);
extern rtx        gen_extendhisi2                    (rtx, rtx);
extern rtx        gen_ashlqi3                        (rtx, rtx, rtx);
extern rtx        gen_ashlhi3                        (rtx, rtx, rtx);
extern rtx        gen_ashlsi3                        (rtx, rtx, rtx);
extern rtx        gen_ashrqi3                        (rtx, rtx, rtx);
extern rtx        gen_ashrhi3                        (rtx, rtx, rtx);
extern rtx        gen_ashrsi3                        (rtx, rtx, rtx);
extern rtx        gen_lshrqi3                        (rtx, rtx, rtx);
extern rtx        gen_lshrhi3                        (rtx, rtx, rtx);
extern rtx        gen_lshrsi3                        (rtx, rtx, rtx);
extern rtx        gen_rotlqi3                        (rtx, rtx, rtx);
extern rtx        gen_rotlhi3                        (rtx, rtx, rtx);
extern rtx        gen_rotlsi3                        (rtx, rtx, rtx);
extern rtx        gen_insv                           (rtx, rtx, rtx, rtx);
extern rtx        gen_extzv                          (rtx, rtx, rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
