/* Definitions for POSIX memory map interface.  Linux/MicroBlaze version.
   Copyright (C) 1997-2018 Free Software Foundation, Inc.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public License as
   published by the Free Software Foundation; either version 2.1 of the
   License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http://www.gnu.org/licenses/>.  */

#ifndef _SYS_MMAN_H
# error "Never use <bits/mman.h> directly; include <sys/mman.h> instead."
#endif

/* The following definitions basically come from the kernel headers.
   But the kernel header is not namespace clean.  */

#ifdef __USE_MISC
/* These are Linux-specific.  */
# define MAP_GROWSDOWN      0x00100     /* Stack-like segment.  */
# define MAP_DENYWRITE      0x00800     /* ETXTBSY.  */
# define MAP_EXECUTABLE     0x01000     /* Mark it as an executable.  */
# define MAP_LOCKED         0x02000     /* Lock the mapping.  */
# define MAP_NORESERVE      0x04000     /* Don't check for reservations.  */
# define MAP_POPULATE       0x08000     /* Populate (prefault) pagetables.  */
# define MAP_NONBLOCK       0x10000     /* Do not block on IO.  */
# define MAP_STACK          0x20000     /* Allocation is for a stack.  */
# define MAP_HUGETLB        0x40000     /* Create huge page mapping.  */
#endif

/* Include generic Linux declarations.  */
#include <bits/mman-linux.h>
