/* Generated automatically by the program 'build/genpreds'
   from the machine description file '/home/ramin/openadk/toolchain_build_generic-hppa_uclibc-ng/w-gcc-13.2.0-1/gcc-13.2.0/gcc/config/pa/pa.md'.  */

#ifndef GCC_TM_PREDS_H
#define GCC_TM_PREDS_H

#ifdef HAVE_MACHINE_MODES
extern bool general_operand (rtx, machine_mode);
extern bool address_operand (rtx, machine_mode);
extern bool register_operand (rtx, machine_mode);
extern bool pmode_register_operand (rtx, machine_mode);
extern bool scratch_operand (rtx, machine_mode);
extern bool immediate_operand (rtx, machine_mode);
extern bool const_int_operand (rtx, machine_mode);
extern bool const_double_operand (rtx, machine_mode);
extern bool nonimmediate_operand (rtx, machine_mode);
extern bool nonmemory_operand (rtx, machine_mode);
extern bool push_operand (rtx, machine_mode);
extern bool pop_operand (rtx, machine_mode);
extern bool memory_operand (rtx, machine_mode);
extern bool indirect_operand (rtx, machine_mode);
extern bool ordered_comparison_operator (rtx, machine_mode);
extern bool comparison_operator (rtx, machine_mode);
extern bool int5_operand (rtx, machine_mode);
extern bool uint5_operand (rtx, machine_mode);
extern bool uint6_operand (rtx, machine_mode);
extern bool int11_operand (rtx, machine_mode);
extern bool int14_operand (rtx, machine_mode);
extern bool uint32_operand (rtx, machine_mode);
extern bool cint_ior_operand (rtx, machine_mode);
extern bool cint_move_operand (rtx, machine_mode);
extern bool const_0_operand (rtx, machine_mode);
extern bool pre_cint_operand (rtx, machine_mode);
extern bool post_cint_operand (rtx, machine_mode);
extern bool and_operand (rtx, machine_mode);
extern bool arith5_operand (rtx, machine_mode);
extern bool arith11_operand (rtx, machine_mode);
extern bool arith14_operand (rtx, machine_mode);
extern bool arith32_operand (rtx, machine_mode);
extern bool shift5_operand (rtx, machine_mode);
extern bool shift6_operand (rtx, machine_mode);
extern bool adddi3_operand (rtx, machine_mode);
extern bool borx_reg_operand (rtx, machine_mode);
extern bool call_operand_address (rtx, machine_mode);
extern bool div_operand (rtx, machine_mode);
extern bool fp_reg_operand (rtx, machine_mode);
extern bool function_label_operand (rtx, machine_mode);
extern bool indexed_memory_operand (rtx, machine_mode);
extern bool reg_plus_base_memory_operand (rtx, machine_mode);
extern bool base14_operand (rtx, machine_mode);
extern bool integer_store_memory_operand (rtx, machine_mode);
extern bool floating_point_store_memory_operand (rtx, machine_mode);
extern bool ireg_operand (rtx, machine_mode);
extern bool ireg_or_int5_operand (rtx, machine_mode);
extern bool lhs_lshift_cint_operand (rtx, machine_mode);
extern bool lhs_lshift_operand (rtx, machine_mode);
extern bool move_dest_operand (rtx, machine_mode);
extern bool move_src_operand (rtx, machine_mode);
extern bool nonsymb_mem_operand (rtx, machine_mode);
extern bool non_hard_reg_operand (rtx, machine_mode);
extern bool pic_label_operand (rtx, machine_mode);
extern bool read_only_operand (rtx, machine_mode);
extern bool reg_before_reload_operand (rtx, machine_mode);
extern bool reg_or_0_operand (rtx, machine_mode);
extern bool reg_or_0_or_nonsymb_mem_operand (rtx, machine_mode);
extern bool reg_or_cint_move_operand (rtx, machine_mode);
extern bool reg_or_cint_ior_operand (rtx, machine_mode);
extern bool mem_shadd_operand (rtx, machine_mode);
extern bool shadd_operand (rtx, machine_mode);
extern bool symbolic_memory_operand (rtx, machine_mode);
extern bool symbolic_operand (rtx, machine_mode);
extern bool tgd_symbolic_operand (rtx, machine_mode);
extern bool tld_symbolic_operand (rtx, machine_mode);
extern bool tie_symbolic_operand (rtx, machine_mode);
extern bool tle_symbolic_operand (rtx, machine_mode);
extern bool cmpib_comparison_operator (rtx, machine_mode);
extern bool movb_comparison_operator (rtx, machine_mode);
extern bool plus_xor_ior_operator (rtx, machine_mode);
#endif /* HAVE_MACHINE_MODES */

#define CONSTRAINT_NUM_DEFINED_P 1
enum constraint_num
{
  CONSTRAINT__UNKNOWN = 0,
  CONSTRAINT_r,
  CONSTRAINT_a,
  CONSTRAINT_f,
  CONSTRAINT_q,
  CONSTRAINT_x,
  CONSTRAINT_y,
  CONSTRAINT_Z,
  CONSTRAINT_I,
  CONSTRAINT_J,
  CONSTRAINT_K,
  CONSTRAINT_L,
  CONSTRAINT_M,
  CONSTRAINT_N,
  CONSTRAINT_O,
  CONSTRAINT_P,
  CONSTRAINT_m,
  CONSTRAINT_o,
  CONSTRAINT_p,
  CONSTRAINT_S,
  CONSTRAINT_U,
  CONSTRAINT_G,
  CONSTRAINT_V,
  CONSTRAINT__l,
  CONSTRAINT__g,
  CONSTRAINT_A,
  CONSTRAINT_R,
  CONSTRAINT_W,
  CONSTRAINT_i,
  CONSTRAINT_s,
  CONSTRAINT_n,
  CONSTRAINT_E,
  CONSTRAINT_F,
  CONSTRAINT_X,
  CONSTRAINT_Q,
  CONSTRAINT_T,
  CONSTRAINT__LIMIT
};

extern enum constraint_num lookup_constraint_1 (const char *);
extern const unsigned char lookup_constraint_array[];

/* Return the constraint at the beginning of P, or CONSTRAINT__UNKNOWN if it
   isn't recognized.  */

static inline enum constraint_num
lookup_constraint (const char *p)
{
  unsigned int index = lookup_constraint_array[(unsigned char) *p];
  return (index == UCHAR_MAX
          ? lookup_constraint_1 (p)
          : (enum constraint_num) index);
}

extern bool (*constraint_satisfied_p_array[]) (rtx);

/* Return true if X satisfies constraint C.  */

static inline bool
constraint_satisfied_p (rtx x, enum constraint_num c)
{
  int i = (int) c - (int) CONSTRAINT_I;
  return i >= 0 && constraint_satisfied_p_array[i] (x);
}

static inline bool
insn_extra_register_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_r && c <= CONSTRAINT_Z;
}

static inline bool
insn_extra_memory_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_m && c <= CONSTRAINT_o;
}

static inline bool
insn_extra_special_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_relaxed_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_address_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_p && c <= CONSTRAINT_p;
}

static inline void
insn_extra_constraint_allows_reg_mem (enum constraint_num c,
				      bool *allows_reg, bool *allows_mem)
{
  if (c >= CONSTRAINT_S && c <= CONSTRAINT_G)
    return;
  if (c >= CONSTRAINT_V && c <= CONSTRAINT_W)
    {
      *allows_mem = true;
      return;
    }
  (void) c;
  *allows_reg = true;
  *allows_mem = true;
}

#define CONSTRAINT_LEN(c_,s_) 1

extern enum reg_class reg_class_for_constraint_1 (enum constraint_num);

static inline enum reg_class
reg_class_for_constraint (enum constraint_num c)
{
  if (insn_extra_register_constraint (c))
    return reg_class_for_constraint_1 (c);
  return NO_REGS;
}

extern bool insn_const_int_ok_for_constraint (HOST_WIDE_INT, enum constraint_num);
#define CONST_OK_FOR_CONSTRAINT_P(v_,c_,s_) \
    insn_const_int_ok_for_constraint (v_, lookup_constraint (s_))

enum constraint_type
{
  CT_REGISTER,
  CT_CONST_INT,
  CT_MEMORY,
  CT_SPECIAL_MEMORY,
  CT_RELAXED_MEMORY,
  CT_ADDRESS,
  CT_FIXED_FORM
};

static inline enum constraint_type
get_constraint_type (enum constraint_num c)
{
  if (c >= CONSTRAINT_p)
    {
      if (c >= CONSTRAINT_S)
        return CT_FIXED_FORM;
      return CT_ADDRESS;
    }
  if (c >= CONSTRAINT_m)
    return CT_MEMORY;
  if (c >= CONSTRAINT_I)
    return CT_CONST_INT;
  return CT_REGISTER;
}
#endif /* tm-preds.h */
