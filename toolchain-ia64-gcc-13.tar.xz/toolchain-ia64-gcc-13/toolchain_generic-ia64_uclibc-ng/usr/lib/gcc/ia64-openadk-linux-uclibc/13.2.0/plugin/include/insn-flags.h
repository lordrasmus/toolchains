/* Generated automatically by the program `genflags'
   from the machine description file `md'.  */

#ifndef GCC_INSN_FLAGS_H
#define GCC_INSN_FLAGS_H

#define HAVE_movcci 1
#define HAVE_movbi 1
#define HAVE_movqi_internal (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movhi_internal (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsi_internal (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdi_internal (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movbi_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movqi_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movhi_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsi_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdi_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsf_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdf_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movxf_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movti_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_zero_extendqidi2_advanced 1
#define HAVE_zero_extendhidi2_advanced 1
#define HAVE_zero_extendsidi2_advanced 1
#define HAVE_movbi_speculative (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movqi_speculative (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movhi_speculative (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsi_speculative (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdi_speculative (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsf_speculative (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdf_speculative (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movxf_speculative (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movti_speculative (ia64_move_ok (operands[0], operands[1]))
#define HAVE_zero_extendqidi2_speculative 1
#define HAVE_zero_extendhidi2_speculative 1
#define HAVE_zero_extendsidi2_speculative 1
#define HAVE_movbi_speculative_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movqi_speculative_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movhi_speculative_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsi_speculative_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdi_speculative_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsf_speculative_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdf_speculative_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movxf_speculative_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movti_speculative_advanced (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movbi_speculative_a (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movqi_speculative_a (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movhi_speculative_a (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsi_speculative_a (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdi_speculative_a (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsf_speculative_a (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdf_speculative_a (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movxf_speculative_a (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movti_speculative_a (ia64_move_ok (operands[0], operands[1]))
#define HAVE_zero_extendqidi2_speculative_advanced 1
#define HAVE_zero_extendhidi2_speculative_advanced 1
#define HAVE_zero_extendsidi2_speculative_advanced 1
#define HAVE_zero_extendqidi2_speculative_a 1
#define HAVE_zero_extendhidi2_speculative_a 1
#define HAVE_zero_extendsidi2_speculative_a 1
#define HAVE_movbi_clr (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movqi_clr (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movhi_clr (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsi_clr (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdi_clr (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsf_clr (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdf_clr (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movxf_clr (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movti_clr (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movbi_nc (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movqi_nc (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movhi_nc (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsi_nc (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdi_nc (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsf_nc (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdf_nc (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movxf_nc (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movti_nc (ia64_move_ok (operands[0], operands[1]))
#define HAVE_zero_extendqidi2_clr 1
#define HAVE_zero_extendhidi2_clr 1
#define HAVE_zero_extendsidi2_clr 1
#define HAVE_zero_extendqidi2_nc 1
#define HAVE_zero_extendhidi2_nc 1
#define HAVE_zero_extendsidi2_nc 1
#define HAVE_advanced_load_check_clr_bi 1
#define HAVE_advanced_load_check_clr_qi 1
#define HAVE_advanced_load_check_clr_hi 1
#define HAVE_advanced_load_check_clr_si 1
#define HAVE_advanced_load_check_clr_di 1
#define HAVE_advanced_load_check_clr_sf 1
#define HAVE_advanced_load_check_clr_df 1
#define HAVE_advanced_load_check_clr_xf 1
#define HAVE_advanced_load_check_clr_ti 1
#define HAVE_advanced_load_check_nc_bi 1
#define HAVE_advanced_load_check_nc_qi 1
#define HAVE_advanced_load_check_nc_hi 1
#define HAVE_advanced_load_check_nc_si 1
#define HAVE_advanced_load_check_nc_di 1
#define HAVE_advanced_load_check_nc_sf 1
#define HAVE_advanced_load_check_nc_df 1
#define HAVE_advanced_load_check_nc_xf 1
#define HAVE_advanced_load_check_nc_ti 1
#define HAVE_speculation_check_bi 1
#define HAVE_speculation_check_qi 1
#define HAVE_speculation_check_hi 1
#define HAVE_speculation_check_si 1
#define HAVE_speculation_check_di 1
#define HAVE_speculation_check_sf 1
#define HAVE_speculation_check_df 1
#define HAVE_speculation_check_xf 1
#define HAVE_speculation_check_ti 1
#define HAVE_load_gprel (reload_completed)
#define HAVE_load_dtpmod 1
#define HAVE_movti_internal (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movsf_internal (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movdf_internal (ia64_move_ok (operands[0], operands[1]))
#define HAVE_movxf_internal (ia64_move_ok (operands[0], operands[1]))
#define HAVE_extendqidi2 1
#define HAVE_extendhidi2 1
#define HAVE_extendsidi2 1
#define HAVE_zero_extendqidi2 1
#define HAVE_zero_extendhidi2 1
#define HAVE_zero_extendsidi2 1
#define HAVE_extendsfdf2 1
#define HAVE_extendsfxf2 1
#define HAVE_extenddfxf2 1
#define HAVE_truncdfsf2 1
#define HAVE_truncxfsf2 1
#define HAVE_truncxfdf2 1
#define HAVE_floatdirf2 1
#define HAVE_floatdixf2 1
#define HAVE_fix_truncsfdi2 1
#define HAVE_fix_truncdfdi2 1
#define HAVE_fix_truncxfdi2 1
#define HAVE_fix_truncrfdi2 1
#define HAVE_floatunsdisf2 1
#define HAVE_floatunsdidf2 1
#define HAVE_floatunsdixf2 1
#define HAVE_floatunsdirf2 1
#define HAVE_fixuns_truncsfdi2 1
#define HAVE_fixuns_truncdfdi2 1
#define HAVE_fixuns_truncxfdi2 1
#define HAVE_fixuns_truncrfdi2 1
#define HAVE_extv 1
#define HAVE_extzv 1
#define HAVE_shift_mix4left 1
#define HAVE_mix4right 1
#define HAVE_andbi3 1
#define HAVE_iorbi3 1
#define HAVE_one_cmplbi2 1
#define HAVE_mulhi3 1
#define HAVE_addsi3 1
#define HAVE_subsi3 1
#define HAVE_mulsi3 1
#define HAVE_maddsi4 1
#define HAVE_negsi2 1
#define HAVE_adddi3 1
#define HAVE_subdi3 1
#define HAVE_muldi3 1
#define HAVE_madddi4 1
#define HAVE_smuldi3_highpart 1
#define HAVE_umuldi3_highpart 1
#define HAVE_negdi2 1
#define HAVE_popcountdi2 1
#define HAVE_bswapdi2 1
#define HAVE_addti3 1
#define HAVE_subti3 1
#define HAVE_negti2 1
#define HAVE_addsf3 1
#define HAVE_subsf3 1
#define HAVE_mulsf3 1
#define HAVE_abssf2 1
#define HAVE_negsf2 1
#define HAVE_copysignsf3 1
#define HAVE_sminsf3 1
#define HAVE_smaxsf3 1
#define HAVE_fmasf4 1
#define HAVE_fmssf4 1
#define HAVE_fnmasf4 1
#define HAVE_adddf3 1
#define HAVE_subdf3 1
#define HAVE_muldf3 1
#define HAVE_absdf2 1
#define HAVE_negdf2 1
#define HAVE_copysigndf3 1
#define HAVE_smindf3 1
#define HAVE_smaxdf3 1
#define HAVE_fmadf4 1
#define HAVE_fmsdf4 1
#define HAVE_fnmadf4 1
#define HAVE_addxf3 1
#define HAVE_subxf3 1
#define HAVE_mulxf3 1
#define HAVE_absxf2 1
#define HAVE_negxf2 1
#define HAVE_copysignxf3 1
#define HAVE_sminxf3 1
#define HAVE_smaxxf3 1
#define HAVE_fmaxf4 1
#define HAVE_fmsxf4 1
#define HAVE_fnmaxf4 1
#define HAVE_ashldi3 1
#define HAVE_ashrdi3 1
#define HAVE_lshrdi3 1
#define HAVE_shrp 1
#define HAVE_one_cmplsi2 1
#define HAVE_anddi3 1
#define HAVE_iordi3 1
#define HAVE_xordi3 1
#define HAVE_one_cmpldi2 1
#define HAVE_doloop_end_internal 1
#define HAVE_call_nogp 1
#define HAVE_call_value_nogp 1
#define HAVE_sibcall_nogp 1
#define HAVE_call_gp 1
#define HAVE_call_value_gp 1
#define HAVE_sibcall_gp 1
#define HAVE_return_internal 1
#define HAVE_return (ia64_direct_return ())
#define HAVE_jump 1
#define HAVE_indirect_jump 1
#define HAVE_prologue_allocate_stack 1
#define HAVE_prologue_allocate_stack_pr 1
#define HAVE_epilogue_deallocate_stack 1
#define HAVE_epilogue_deallocate_stack_pr 1
#define HAVE_prologue_use 1
#define HAVE_alloc 1
#define HAVE_gr_spill_internal 1
#define HAVE_gr_restore_internal 1
#define HAVE_fr_spill 1
#define HAVE_fr_restore 1
#define HAVE_bsp_value 1
#define HAVE_set_bsp 1
#define HAVE_flushrs 1
#define HAVE_nop 1
#define HAVE_nop_m 1
#define HAVE_nop_i 1
#define HAVE_nop_f 1
#define HAVE_nop_b 1
#define HAVE_nop_x 1
#define HAVE_pre_cycle 1
#define HAVE_bundle_selector 1
#define HAVE_blockage 1
#define HAVE_insn_group_barrier 1
#define HAVE_break_f 1
#define HAVE_prefetch 1
#define HAVE_nonlocal_goto_receiver 1
#define HAVE_builtin_setjmp_receiver 1
#define HAVE_pred_rel_mutex 1
#define HAVE_safe_across_calls_all 1
#define HAVE_safe_across_calls_normal 1
#define HAVE_ptr_extend 1
#define HAVE_ptr_extend_plus_imm (addp4_optimize_ok (operands[1], operands[2]))
#define HAVE_ip_value 1
#define HAVE_probe_stack_address 1
#define HAVE_probe_stack_range 1
#define HAVE_one_cmplv8qi2 1
#define HAVE_one_cmplv4hi2 1
#define HAVE_one_cmplv2si2 1
#define HAVE_andv8qi3 1
#define HAVE_andv4hi3 1
#define HAVE_andv2si3 1
#define HAVE_iorv8qi3 1
#define HAVE_iorv4hi3 1
#define HAVE_iorv2si3 1
#define HAVE_xorv8qi3 1
#define HAVE_xorv4hi3 1
#define HAVE_xorv2si3 1
#define HAVE_negv8qi2 1
#define HAVE_negv4hi2 1
#define HAVE_negv2si2 1
#define HAVE_addv8qi3 1
#define HAVE_addv4hi3 1
#define HAVE_addv2si3 1
#define HAVE_subv8qi3 1
#define HAVE_subv4hi3 1
#define HAVE_subv2si3 1
#define HAVE_mulv4hi3 1
#define HAVE_pmpyshr2 1
#define HAVE_pmpyshr2_u 1
#define HAVE_vec_widen_smult_even_v4hi 1
#define HAVE_vec_widen_smult_odd_v4hi 1
#define HAVE_ashlv4hi3 1
#define HAVE_ashlv2si3 1
#define HAVE_ashrv4hi3 1
#define HAVE_ashrv2si3 1
#define HAVE_lshrv4hi3 1
#define HAVE_lshrv2si3 1
#define HAVE_vec_pack_ssat_v4hi 1
#define HAVE_vec_pack_usat_v4hi 1
#define HAVE_vec_pack_ssat_v2si 1
#define HAVE_mux1_brcst_qi 1
#define HAVE_mix2_even 1
#define HAVE_mix2_odd 1
#define HAVE_absv2sf2 1
#define HAVE_negv2sf2 1
#define HAVE_mulv2sf3 1
#define HAVE_fmav2sf4 1
#define HAVE_fmsv2sf4 1
#define HAVE_fnmav2sf4 1
#define HAVE_smaxv2sf3 1
#define HAVE_sminv2sf3 1
#define HAVE_fpack 1
#define HAVE_fswap 1
#define HAVE_fmix_lr 1
#define HAVE_cmpxchg_acq_qi 1
#define HAVE_cmpxchg_acq_hi 1
#define HAVE_cmpxchg_acq_si 1
#define HAVE_cmpxchg_rel_qi 1
#define HAVE_cmpxchg_rel_hi 1
#define HAVE_cmpxchg_rel_si 1
#define HAVE_cmpxchg_acq_di 1
#define HAVE_cmpxchg_rel_di 1
#define HAVE_xchg_acq_qi 1
#define HAVE_xchg_acq_hi 1
#define HAVE_xchg_acq_si 1
#define HAVE_xchg_acq_di 1
#define HAVE_fetchadd_acq_si 1
#define HAVE_fetchadd_acq_di 1
#define HAVE_fetchadd_rel_si 1
#define HAVE_fetchadd_rel_di 1
#define HAVE_addrf3_cond 1
#define HAVE_subrf3_cond 1
#define HAVE_mulrf3_cond 1
#define HAVE_nmulrf3_cond 1
#define HAVE_m1addrf4_cond 1
#define HAVE_m1subrf4_cond 1
#define HAVE_m2addrf4_cond 1
#define HAVE_m2subrf4_cond 1
#define HAVE_extendsfrf2 1
#define HAVE_extenddfrf2 1
#define HAVE_extendxfrf2 1
#define HAVE_truncrfsf2 1
#define HAVE_truncrfdf2 1
#define HAVE_truncrfxf2 1
#define HAVE_fix_truncrfdi2_alts 1
#define HAVE_fixuns_truncrfdi2_alts 1
#define HAVE_setf_exp_rf 1
#define HAVE_recip_approx_rf 1
#define HAVE_sqrt_approx_rf 1
#define HAVE_movqi 1
#define HAVE_movhi 1
#define HAVE_movsi 1
#define HAVE_movdi 1
#define HAVE_load_fptr (reload_completed)
#define HAVE_load_gprel64 (reload_completed)
#define HAVE_load_dtprel 1
#define HAVE_add_dtprel (!TARGET_TLS64)
#define HAVE_load_tprel 1
#define HAVE_add_tprel (!TARGET_TLS64)
#define HAVE_movti 1
#define HAVE_movsf 1
#define HAVE_movdf 1
#define HAVE_movxf 1
#define HAVE_movrf 1
#define HAVE_movtf 1
#define HAVE_insv 1
#define HAVE_abssi2 1
#define HAVE_sminsi3 1
#define HAVE_smaxsi3 1
#define HAVE_uminsi3 1
#define HAVE_umaxsi3 1
#define HAVE_absdi2 1
#define HAVE_smindi3 1
#define HAVE_smaxdi3 1
#define HAVE_umindi3 1
#define HAVE_umaxdi3 1
#define HAVE_ffsdi2 1
#define HAVE_ctzdi2 1
#define HAVE_clzdi2 1
#define HAVE_mulditi3 1
#define HAVE_umulditi3 1
#define HAVE_ashlsi3 1
#define HAVE_ashrsi3 1
#define HAVE_lshrsi3 1
#define HAVE_rotrsi3 1
#define HAVE_rotlsi3 1
#define HAVE_rotrdi3 1
#define HAVE_rotldi3 1
#define HAVE_ashlti3 1
#define HAVE_ashrti3 1
#define HAVE_lshrti3 1
#define HAVE_rotlti3 1
#define HAVE_cbranchbi4 1
#define HAVE_cbranchsi4 1
#define HAVE_cbranchdi4 1
#define HAVE_cbranchsf4 1
#define HAVE_cbranchdf4 1
#define HAVE_cbranchxf4 1
#define HAVE_doloop_end 1
#define HAVE_cstorebi4 1
#define HAVE_cstoresi4 1
#define HAVE_cstoredi4 1
#define HAVE_cstoresf4 1
#define HAVE_cstoredf4 1
#define HAVE_cstorexf4 1
#define HAVE_call 1
#define HAVE_sibcall 1
#define HAVE_call_value 1
#define HAVE_sibcall_value 1
#define HAVE_untyped_call 1
#define HAVE_tablejump 1
#define HAVE_prologue 1
#define HAVE_epilogue 1
#define HAVE_sibcall_epilogue 1
#define HAVE_gr_spill 1
#define HAVE_gr_restore 1
#define HAVE_trap 1
#define HAVE_ctrapbi4 1
#define HAVE_ctrapsi4 1
#define HAVE_ctrapdi4 1
#define HAVE_ctrapsf4 1
#define HAVE_ctrapdf4 1
#define HAVE_ctrapxf4 1
#define HAVE_save_stack_nonlocal 1
#define HAVE_nonlocal_goto 1
#define HAVE_eh_epilogue 1
#define HAVE_restore_stack_nonlocal 1
#define HAVE_movv8qi 1
#define HAVE_movv4hi 1
#define HAVE_movv2si 1
#define HAVE_mulv8qi3 1
#define HAVE_vec_widen_umult_lo_v8qi 1
#define HAVE_vec_widen_umult_hi_v8qi 1
#define HAVE_vec_widen_smult_lo_v8qi 1
#define HAVE_vec_widen_smult_hi_v8qi 1
#define HAVE_smulv4hi3_highpart 1
#define HAVE_umulv4hi3_highpart 1
#define HAVE_vec_widen_smult_lo_v4hi 1
#define HAVE_vec_widen_smult_hi_v4hi 1
#define HAVE_vec_widen_umult_lo_v4hi 1
#define HAVE_vec_widen_umult_hi_v4hi 1
#define HAVE_mulv2si3 1
#define HAVE_umaxv8qi3 1
#define HAVE_umaxv4hi3 1
#define HAVE_umaxv2si3 1
#define HAVE_smaxv8qi3 1
#define HAVE_smaxv4hi3 1
#define HAVE_smaxv2si3 1
#define HAVE_uminv8qi3 1
#define HAVE_uminv4hi3 1
#define HAVE_uminv2si3 1
#define HAVE_sminv8qi3 1
#define HAVE_sminv4hi3 1
#define HAVE_sminv2si3 1
#define HAVE_vec_shl_v8qi 1
#define HAVE_vec_shl_v4hi 1
#define HAVE_vec_shl_v2si 1
#define HAVE_vec_shr_v8qi 1
#define HAVE_vec_shr_v4hi 1
#define HAVE_vec_shr_v2si 1
#define HAVE_widen_usumv8qi3 1
#define HAVE_widen_usumv4hi3 1
#define HAVE_widen_ssumv8qi3 1
#define HAVE_widen_ssumv4hi3 1
#define HAVE_vcondv8qiv8qi 1
#define HAVE_vcondv4hiv4hi 1
#define HAVE_vcondv2siv2si 1
#define HAVE_vconduv8qiv8qi 1
#define HAVE_vconduv4hiv4hi 1
#define HAVE_vconduv2siv2si 1
#define HAVE_vec_initv2sisi 1
#define HAVE_movv2sf 1
#define HAVE_addv2sf3 1
#define HAVE_subv2sf3 1
#define HAVE_reduc_splus_v2sf 1
#define HAVE_reduc_smax_v2sf 1
#define HAVE_reduc_smin_v2sf 1
#define HAVE_vcondv2sfv2sf 1
#define HAVE_vec_initv2sfsf 1
#define HAVE_vec_setv2sf 1
#define HAVE_vec_extractv2sfsf 1
#define HAVE_vec_unpacku_lo_v8qi 1
#define HAVE_vec_unpacku_lo_v4hi 1
#define HAVE_vec_unpacku_hi_v8qi 1
#define HAVE_vec_unpacku_hi_v4hi 1
#define HAVE_vec_unpacks_lo_v8qi 1
#define HAVE_vec_unpacks_lo_v4hi 1
#define HAVE_vec_unpacks_hi_v8qi 1
#define HAVE_vec_unpacks_hi_v4hi 1
#define HAVE_vec_pack_trunc_v4hi 1
#define HAVE_vec_pack_trunc_v2si 1
#define HAVE_mem_thread_fence 1
#define HAVE_memory_barrier 1
#define HAVE_atomic_loadqi 1
#define HAVE_atomic_loadhi 1
#define HAVE_atomic_loadsi 1
#define HAVE_atomic_loaddi 1
#define HAVE_atomic_storeqi 1
#define HAVE_atomic_storehi 1
#define HAVE_atomic_storesi 1
#define HAVE_atomic_storedi 1
#define HAVE_atomic_compare_and_swapqi 1
#define HAVE_atomic_compare_and_swaphi 1
#define HAVE_atomic_compare_and_swapsi 1
#define HAVE_atomic_compare_and_swapdi 1
#define HAVE_atomic_exchangeqi 1
#define HAVE_atomic_exchangehi 1
#define HAVE_atomic_exchangesi 1
#define HAVE_atomic_exchangedi 1
#define HAVE_atomic_addqi 1
#define HAVE_atomic_subqi 1
#define HAVE_atomic_orqi 1
#define HAVE_atomic_xorqi 1
#define HAVE_atomic_andqi 1
#define HAVE_atomic_addhi 1
#define HAVE_atomic_subhi 1
#define HAVE_atomic_orhi 1
#define HAVE_atomic_xorhi 1
#define HAVE_atomic_andhi 1
#define HAVE_atomic_addsi 1
#define HAVE_atomic_subsi 1
#define HAVE_atomic_orsi 1
#define HAVE_atomic_xorsi 1
#define HAVE_atomic_andsi 1
#define HAVE_atomic_adddi 1
#define HAVE_atomic_subdi 1
#define HAVE_atomic_ordi 1
#define HAVE_atomic_xordi 1
#define HAVE_atomic_anddi 1
#define HAVE_atomic_nandqi 1
#define HAVE_atomic_nandhi 1
#define HAVE_atomic_nandsi 1
#define HAVE_atomic_nanddi 1
#define HAVE_atomic_fetch_addqi 1
#define HAVE_atomic_fetch_subqi 1
#define HAVE_atomic_fetch_orqi 1
#define HAVE_atomic_fetch_xorqi 1
#define HAVE_atomic_fetch_andqi 1
#define HAVE_atomic_fetch_addhi 1
#define HAVE_atomic_fetch_subhi 1
#define HAVE_atomic_fetch_orhi 1
#define HAVE_atomic_fetch_xorhi 1
#define HAVE_atomic_fetch_andhi 1
#define HAVE_atomic_fetch_addsi 1
#define HAVE_atomic_fetch_subsi 1
#define HAVE_atomic_fetch_orsi 1
#define HAVE_atomic_fetch_xorsi 1
#define HAVE_atomic_fetch_andsi 1
#define HAVE_atomic_fetch_adddi 1
#define HAVE_atomic_fetch_subdi 1
#define HAVE_atomic_fetch_ordi 1
#define HAVE_atomic_fetch_xordi 1
#define HAVE_atomic_fetch_anddi 1
#define HAVE_atomic_fetch_nandqi 1
#define HAVE_atomic_fetch_nandhi 1
#define HAVE_atomic_fetch_nandsi 1
#define HAVE_atomic_fetch_nanddi 1
#define HAVE_atomic_add_fetchqi 1
#define HAVE_atomic_sub_fetchqi 1
#define HAVE_atomic_or_fetchqi 1
#define HAVE_atomic_xor_fetchqi 1
#define HAVE_atomic_and_fetchqi 1
#define HAVE_atomic_add_fetchhi 1
#define HAVE_atomic_sub_fetchhi 1
#define HAVE_atomic_or_fetchhi 1
#define HAVE_atomic_xor_fetchhi 1
#define HAVE_atomic_and_fetchhi 1
#define HAVE_atomic_add_fetchsi 1
#define HAVE_atomic_sub_fetchsi 1
#define HAVE_atomic_or_fetchsi 1
#define HAVE_atomic_xor_fetchsi 1
#define HAVE_atomic_and_fetchsi 1
#define HAVE_atomic_add_fetchdi 1
#define HAVE_atomic_sub_fetchdi 1
#define HAVE_atomic_or_fetchdi 1
#define HAVE_atomic_xor_fetchdi 1
#define HAVE_atomic_and_fetchdi 1
#define HAVE_atomic_nand_fetchqi 1
#define HAVE_atomic_nand_fetchhi 1
#define HAVE_atomic_nand_fetchsi 1
#define HAVE_atomic_nand_fetchdi 1
#define HAVE_divsf3 (TARGET_INLINE_FLOAT_DIV)
#define HAVE_divsf3_internal_thr (TARGET_INLINE_FLOAT_DIV)
#define HAVE_divsf3_internal_lat (TARGET_INLINE_FLOAT_DIV)
#define HAVE_divdf3 (TARGET_INLINE_FLOAT_DIV)
#define HAVE_divdf3_internal_thr (TARGET_INLINE_FLOAT_DIV)
#define HAVE_divdf3_internal_lat (TARGET_INLINE_FLOAT_DIV)
#define HAVE_divxf3 (TARGET_INLINE_FLOAT_DIV)
#define HAVE_divsi3 (TARGET_INLINE_INT_DIV)
#define HAVE_modsi3 (TARGET_INLINE_INT_DIV)
#define HAVE_udivsi3 (TARGET_INLINE_INT_DIV)
#define HAVE_umodsi3 (TARGET_INLINE_INT_DIV)
#define HAVE_divsi3_internal (TARGET_INLINE_INT_DIV)
#define HAVE_divdi3 (TARGET_INLINE_INT_DIV)
#define HAVE_moddi3 (TARGET_INLINE_INT_DIV)
#define HAVE_udivdi3 (TARGET_INLINE_INT_DIV)
#define HAVE_umoddi3 (TARGET_INLINE_INT_DIV)
#define HAVE_divdi3_internal_lat (TARGET_INLINE_INT_DIV)
#define HAVE_divdi3_internal_thr (TARGET_INLINE_INT_DIV)
#define HAVE_sqrtsf2 (TARGET_INLINE_SQRT)
#define HAVE_sqrtsf2_internal_thr (TARGET_INLINE_SQRT)
#define HAVE_sqrtsf2_internal_lat (TARGET_INLINE_SQRT)
#define HAVE_sqrtdf2 (TARGET_INLINE_SQRT)
#define HAVE_sqrtdf2_internal_thr (TARGET_INLINE_SQRT)
#define HAVE_sqrtxf2 (TARGET_INLINE_SQRT)
extern rtx        gen_movcci                                (rtx, rtx);
extern rtx        gen_movbi                                 (rtx, rtx);
extern rtx        gen_movqi_internal                        (rtx, rtx);
extern rtx        gen_movhi_internal                        (rtx, rtx);
extern rtx        gen_movsi_internal                        (rtx, rtx);
extern rtx        gen_movdi_internal                        (rtx, rtx);
extern rtx        gen_movbi_advanced                        (rtx, rtx);
extern rtx        gen_movqi_advanced                        (rtx, rtx);
extern rtx        gen_movhi_advanced                        (rtx, rtx);
extern rtx        gen_movsi_advanced                        (rtx, rtx);
extern rtx        gen_movdi_advanced                        (rtx, rtx);
extern rtx        gen_movsf_advanced                        (rtx, rtx);
extern rtx        gen_movdf_advanced                        (rtx, rtx);
extern rtx        gen_movxf_advanced                        (rtx, rtx);
extern rtx        gen_movti_advanced                        (rtx, rtx);
extern rtx        gen_zero_extendqidi2_advanced             (rtx, rtx);
extern rtx        gen_zero_extendhidi2_advanced             (rtx, rtx);
extern rtx        gen_zero_extendsidi2_advanced             (rtx, rtx);
extern rtx        gen_movbi_speculative                     (rtx, rtx);
extern rtx        gen_movqi_speculative                     (rtx, rtx);
extern rtx        gen_movhi_speculative                     (rtx, rtx);
extern rtx        gen_movsi_speculative                     (rtx, rtx);
extern rtx        gen_movdi_speculative                     (rtx, rtx);
extern rtx        gen_movsf_speculative                     (rtx, rtx);
extern rtx        gen_movdf_speculative                     (rtx, rtx);
extern rtx        gen_movxf_speculative                     (rtx, rtx);
extern rtx        gen_movti_speculative                     (rtx, rtx);
extern rtx        gen_zero_extendqidi2_speculative          (rtx, rtx);
extern rtx        gen_zero_extendhidi2_speculative          (rtx, rtx);
extern rtx        gen_zero_extendsidi2_speculative          (rtx, rtx);
extern rtx        gen_movbi_speculative_advanced            (rtx, rtx);
extern rtx        gen_movqi_speculative_advanced            (rtx, rtx);
extern rtx        gen_movhi_speculative_advanced            (rtx, rtx);
extern rtx        gen_movsi_speculative_advanced            (rtx, rtx);
extern rtx        gen_movdi_speculative_advanced            (rtx, rtx);
extern rtx        gen_movsf_speculative_advanced            (rtx, rtx);
extern rtx        gen_movdf_speculative_advanced            (rtx, rtx);
extern rtx        gen_movxf_speculative_advanced            (rtx, rtx);
extern rtx        gen_movti_speculative_advanced            (rtx, rtx);
extern rtx        gen_movbi_speculative_a                   (rtx, rtx);
extern rtx        gen_movqi_speculative_a                   (rtx, rtx);
extern rtx        gen_movhi_speculative_a                   (rtx, rtx);
extern rtx        gen_movsi_speculative_a                   (rtx, rtx);
extern rtx        gen_movdi_speculative_a                   (rtx, rtx);
extern rtx        gen_movsf_speculative_a                   (rtx, rtx);
extern rtx        gen_movdf_speculative_a                   (rtx, rtx);
extern rtx        gen_movxf_speculative_a                   (rtx, rtx);
extern rtx        gen_movti_speculative_a                   (rtx, rtx);
extern rtx        gen_zero_extendqidi2_speculative_advanced (rtx, rtx);
extern rtx        gen_zero_extendhidi2_speculative_advanced (rtx, rtx);
extern rtx        gen_zero_extendsidi2_speculative_advanced (rtx, rtx);
extern rtx        gen_zero_extendqidi2_speculative_a        (rtx, rtx);
extern rtx        gen_zero_extendhidi2_speculative_a        (rtx, rtx);
extern rtx        gen_zero_extendsidi2_speculative_a        (rtx, rtx);
extern rtx        gen_movbi_clr                             (rtx, rtx);
extern rtx        gen_movqi_clr                             (rtx, rtx);
extern rtx        gen_movhi_clr                             (rtx, rtx);
extern rtx        gen_movsi_clr                             (rtx, rtx);
extern rtx        gen_movdi_clr                             (rtx, rtx);
extern rtx        gen_movsf_clr                             (rtx, rtx);
extern rtx        gen_movdf_clr                             (rtx, rtx);
extern rtx        gen_movxf_clr                             (rtx, rtx);
extern rtx        gen_movti_clr                             (rtx, rtx);
extern rtx        gen_movbi_nc                              (rtx, rtx);
extern rtx        gen_movqi_nc                              (rtx, rtx);
extern rtx        gen_movhi_nc                              (rtx, rtx);
extern rtx        gen_movsi_nc                              (rtx, rtx);
extern rtx        gen_movdi_nc                              (rtx, rtx);
extern rtx        gen_movsf_nc                              (rtx, rtx);
extern rtx        gen_movdf_nc                              (rtx, rtx);
extern rtx        gen_movxf_nc                              (rtx, rtx);
extern rtx        gen_movti_nc                              (rtx, rtx);
extern rtx        gen_zero_extendqidi2_clr                  (rtx, rtx);
extern rtx        gen_zero_extendhidi2_clr                  (rtx, rtx);
extern rtx        gen_zero_extendsidi2_clr                  (rtx, rtx);
extern rtx        gen_zero_extendqidi2_nc                   (rtx, rtx);
extern rtx        gen_zero_extendhidi2_nc                   (rtx, rtx);
extern rtx        gen_zero_extendsidi2_nc                   (rtx, rtx);
extern rtx        gen_advanced_load_check_clr_bi            (rtx, rtx);
extern rtx        gen_advanced_load_check_clr_qi            (rtx, rtx);
extern rtx        gen_advanced_load_check_clr_hi            (rtx, rtx);
extern rtx        gen_advanced_load_check_clr_si            (rtx, rtx);
extern rtx        gen_advanced_load_check_clr_di            (rtx, rtx);
extern rtx        gen_advanced_load_check_clr_sf            (rtx, rtx);
extern rtx        gen_advanced_load_check_clr_df            (rtx, rtx);
extern rtx        gen_advanced_load_check_clr_xf            (rtx, rtx);
extern rtx        gen_advanced_load_check_clr_ti            (rtx, rtx);
extern rtx        gen_advanced_load_check_nc_bi             (rtx, rtx);
extern rtx        gen_advanced_load_check_nc_qi             (rtx, rtx);
extern rtx        gen_advanced_load_check_nc_hi             (rtx, rtx);
extern rtx        gen_advanced_load_check_nc_si             (rtx, rtx);
extern rtx        gen_advanced_load_check_nc_di             (rtx, rtx);
extern rtx        gen_advanced_load_check_nc_sf             (rtx, rtx);
extern rtx        gen_advanced_load_check_nc_df             (rtx, rtx);
extern rtx        gen_advanced_load_check_nc_xf             (rtx, rtx);
extern rtx        gen_advanced_load_check_nc_ti             (rtx, rtx);
extern rtx        gen_speculation_check_bi                  (rtx, rtx);
extern rtx        gen_speculation_check_qi                  (rtx, rtx);
extern rtx        gen_speculation_check_hi                  (rtx, rtx);
extern rtx        gen_speculation_check_si                  (rtx, rtx);
extern rtx        gen_speculation_check_di                  (rtx, rtx);
extern rtx        gen_speculation_check_sf                  (rtx, rtx);
extern rtx        gen_speculation_check_df                  (rtx, rtx);
extern rtx        gen_speculation_check_xf                  (rtx, rtx);
extern rtx        gen_speculation_check_ti                  (rtx, rtx);
extern rtx        gen_load_gprel                            (rtx, rtx);
extern rtx        gen_load_dtpmod                           (rtx, rtx);
extern rtx        gen_movti_internal                        (rtx, rtx);
extern rtx        gen_movsf_internal                        (rtx, rtx);
extern rtx        gen_movdf_internal                        (rtx, rtx);
extern rtx        gen_movxf_internal                        (rtx, rtx);
extern rtx        gen_extendqidi2                           (rtx, rtx);
extern rtx        gen_extendhidi2                           (rtx, rtx);
extern rtx        gen_extendsidi2                           (rtx, rtx);
extern rtx        gen_zero_extendqidi2                      (rtx, rtx);
extern rtx        gen_zero_extendhidi2                      (rtx, rtx);
extern rtx        gen_zero_extendsidi2                      (rtx, rtx);
extern rtx        gen_extendsfdf2                           (rtx, rtx);
extern rtx        gen_extendsfxf2                           (rtx, rtx);
extern rtx        gen_extenddfxf2                           (rtx, rtx);
extern rtx        gen_truncdfsf2                            (rtx, rtx);
extern rtx        gen_truncxfsf2                            (rtx, rtx);
extern rtx        gen_truncxfdf2                            (rtx, rtx);
extern rtx        gen_floatdirf2                            (rtx, rtx);
extern rtx        gen_floatdixf2                            (rtx, rtx);
extern rtx        gen_fix_truncsfdi2                        (rtx, rtx);
extern rtx        gen_fix_truncdfdi2                        (rtx, rtx);
extern rtx        gen_fix_truncxfdi2                        (rtx, rtx);
extern rtx        gen_fix_truncrfdi2                        (rtx, rtx);
extern rtx        gen_floatunsdisf2                         (rtx, rtx);
extern rtx        gen_floatunsdidf2                         (rtx, rtx);
extern rtx        gen_floatunsdixf2                         (rtx, rtx);
extern rtx        gen_floatunsdirf2                         (rtx, rtx);
extern rtx        gen_fixuns_truncsfdi2                     (rtx, rtx);
extern rtx        gen_fixuns_truncdfdi2                     (rtx, rtx);
extern rtx        gen_fixuns_truncxfdi2                     (rtx, rtx);
extern rtx        gen_fixuns_truncrfdi2                     (rtx, rtx);
extern rtx        gen_extv                                  (rtx, rtx, rtx, rtx);
extern rtx        gen_extzv                                 (rtx, rtx, rtx, rtx);
extern rtx        gen_shift_mix4left                        (rtx, rtx, rtx);
extern rtx        gen_mix4right                             (rtx, rtx);
extern rtx        gen_andbi3                                (rtx, rtx, rtx);
extern rtx        gen_iorbi3                                (rtx, rtx, rtx);
extern rtx        gen_one_cmplbi2                           (rtx, rtx);
extern rtx        gen_mulhi3                                (rtx, rtx, rtx);
extern rtx        gen_addsi3                                (rtx, rtx, rtx);
extern rtx        gen_subsi3                                (rtx, rtx, rtx);
extern rtx        gen_mulsi3                                (rtx, rtx, rtx);
extern rtx        gen_maddsi4                               (rtx, rtx, rtx, rtx);
extern rtx        gen_negsi2                                (rtx, rtx);
extern rtx        gen_adddi3                                (rtx, rtx, rtx);
extern rtx        gen_subdi3                                (rtx, rtx, rtx);
extern rtx        gen_muldi3                                (rtx, rtx, rtx);
extern rtx        gen_madddi4                               (rtx, rtx, rtx, rtx);
extern rtx        gen_smuldi3_highpart                      (rtx, rtx, rtx);
extern rtx        gen_umuldi3_highpart                      (rtx, rtx, rtx);
extern rtx        gen_negdi2                                (rtx, rtx);
extern rtx        gen_popcountdi2                           (rtx, rtx);
extern rtx        gen_bswapdi2                              (rtx, rtx);
extern rtx        gen_addti3                                (rtx, rtx, rtx);
extern rtx        gen_subti3                                (rtx, rtx, rtx);
extern rtx        gen_negti2                                (rtx, rtx);
extern rtx        gen_addsf3                                (rtx, rtx, rtx);
extern rtx        gen_subsf3                                (rtx, rtx, rtx);
extern rtx        gen_mulsf3                                (rtx, rtx, rtx);
extern rtx        gen_abssf2                                (rtx, rtx);
extern rtx        gen_negsf2                                (rtx, rtx);
extern rtx        gen_copysignsf3                           (rtx, rtx, rtx);
extern rtx        gen_sminsf3                               (rtx, rtx, rtx);
extern rtx        gen_smaxsf3                               (rtx, rtx, rtx);
extern rtx        gen_fmasf4                                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmssf4                                (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmasf4                               (rtx, rtx, rtx, rtx);
extern rtx        gen_adddf3                                (rtx, rtx, rtx);
extern rtx        gen_subdf3                                (rtx, rtx, rtx);
extern rtx        gen_muldf3                                (rtx, rtx, rtx);
extern rtx        gen_absdf2                                (rtx, rtx);
extern rtx        gen_negdf2                                (rtx, rtx);
extern rtx        gen_copysigndf3                           (rtx, rtx, rtx);
extern rtx        gen_smindf3                               (rtx, rtx, rtx);
extern rtx        gen_smaxdf3                               (rtx, rtx, rtx);
extern rtx        gen_fmadf4                                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmsdf4                                (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmadf4                               (rtx, rtx, rtx, rtx);
extern rtx        gen_addxf3                                (rtx, rtx, rtx);
extern rtx        gen_subxf3                                (rtx, rtx, rtx);
extern rtx        gen_mulxf3                                (rtx, rtx, rtx);
extern rtx        gen_absxf2                                (rtx, rtx);
extern rtx        gen_negxf2                                (rtx, rtx);
extern rtx        gen_copysignxf3                           (rtx, rtx, rtx);
extern rtx        gen_sminxf3                               (rtx, rtx, rtx);
extern rtx        gen_smaxxf3                               (rtx, rtx, rtx);
extern rtx        gen_fmaxf4                                (rtx, rtx, rtx, rtx);
extern rtx        gen_fmsxf4                                (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmaxf4                               (rtx, rtx, rtx, rtx);
extern rtx        gen_ashldi3                               (rtx, rtx, rtx);
extern rtx        gen_ashrdi3                               (rtx, rtx, rtx);
extern rtx        gen_lshrdi3                               (rtx, rtx, rtx);
extern rtx        gen_shrp                                  (rtx, rtx, rtx, rtx);
extern rtx        gen_one_cmplsi2                           (rtx, rtx);
extern rtx        gen_anddi3                                (rtx, rtx, rtx);
extern rtx        gen_iordi3                                (rtx, rtx, rtx);
extern rtx        gen_xordi3                                (rtx, rtx, rtx);
extern rtx        gen_one_cmpldi2                           (rtx, rtx);
extern rtx        gen_doloop_end_internal                   (rtx, rtx);
extern rtx        gen_call_nogp                             (rtx, rtx);
extern rtx        gen_call_value_nogp                       (rtx, rtx, rtx);
extern rtx        gen_sibcall_nogp                          (rtx);
extern rtx        gen_call_gp                               (rtx, rtx);
extern rtx        gen_call_value_gp                         (rtx, rtx, rtx);
extern rtx        gen_sibcall_gp                            (rtx);
extern rtx        gen_return_internal                       (rtx);
extern rtx        gen_return                                (void);
extern rtx        gen_jump                                  (rtx);
extern rtx        gen_indirect_jump                         (rtx);
extern rtx        gen_prologue_allocate_stack               (rtx, rtx, rtx, rtx);
extern rtx        gen_prologue_allocate_stack_pr            (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_epilogue_deallocate_stack             (rtx, rtx);
extern rtx        gen_epilogue_deallocate_stack_pr          (rtx, rtx, rtx, rtx);
extern rtx        gen_prologue_use                          (rtx);
extern rtx        gen_alloc                                 (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_gr_spill_internal                     (rtx, rtx, rtx, rtx);
extern rtx        gen_gr_restore_internal                   (rtx, rtx, rtx, rtx);
extern rtx        gen_fr_spill                              (rtx, rtx);
extern rtx        gen_fr_restore                            (rtx, rtx);
extern rtx        gen_bsp_value                             (rtx);
extern rtx        gen_set_bsp                               (rtx);
extern rtx        gen_flushrs                               (void);
extern rtx        gen_nop                                   (void);
extern rtx        gen_nop_m                                 (void);
extern rtx        gen_nop_i                                 (void);
extern rtx        gen_nop_f                                 (void);
extern rtx        gen_nop_b                                 (void);
extern rtx        gen_nop_x                                 (void);
extern rtx        gen_pre_cycle                             (void);
extern rtx        gen_bundle_selector                       (rtx);
extern rtx        gen_blockage                              (void);
extern rtx        gen_insn_group_barrier                    (rtx);
extern rtx        gen_break_f                               (void);
extern rtx        gen_prefetch                              (rtx, rtx, rtx);
extern rtx        gen_nonlocal_goto_receiver                (void);
extern rtx        gen_builtin_setjmp_receiver               (rtx);
extern rtx        gen_pred_rel_mutex                        (rtx);
extern rtx        gen_safe_across_calls_all                 (void);
extern rtx        gen_safe_across_calls_normal              (void);
extern rtx        gen_ptr_extend                            (rtx, rtx);
extern rtx        gen_ptr_extend_plus_imm                   (rtx, rtx, rtx);
extern rtx        gen_ip_value                              (rtx);
extern rtx        gen_probe_stack_address                   (rtx);
extern rtx        gen_probe_stack_range                     (rtx, rtx, rtx);
extern rtx        gen_one_cmplv8qi2                         (rtx, rtx);
extern rtx        gen_one_cmplv4hi2                         (rtx, rtx);
extern rtx        gen_one_cmplv2si2                         (rtx, rtx);
extern rtx        gen_andv8qi3                              (rtx, rtx, rtx);
extern rtx        gen_andv4hi3                              (rtx, rtx, rtx);
extern rtx        gen_andv2si3                              (rtx, rtx, rtx);
extern rtx        gen_iorv8qi3                              (rtx, rtx, rtx);
extern rtx        gen_iorv4hi3                              (rtx, rtx, rtx);
extern rtx        gen_iorv2si3                              (rtx, rtx, rtx);
extern rtx        gen_xorv8qi3                              (rtx, rtx, rtx);
extern rtx        gen_xorv4hi3                              (rtx, rtx, rtx);
extern rtx        gen_xorv2si3                              (rtx, rtx, rtx);
extern rtx        gen_negv8qi2                              (rtx, rtx);
extern rtx        gen_negv4hi2                              (rtx, rtx);
extern rtx        gen_negv2si2                              (rtx, rtx);
extern rtx        gen_addv8qi3                              (rtx, rtx, rtx);
extern rtx        gen_addv4hi3                              (rtx, rtx, rtx);
extern rtx        gen_addv2si3                              (rtx, rtx, rtx);
extern rtx        gen_subv8qi3                              (rtx, rtx, rtx);
extern rtx        gen_subv4hi3                              (rtx, rtx, rtx);
extern rtx        gen_subv2si3                              (rtx, rtx, rtx);
extern rtx        gen_mulv4hi3                              (rtx, rtx, rtx);
extern rtx        gen_pmpyshr2                              (rtx, rtx, rtx, rtx);
extern rtx        gen_pmpyshr2_u                            (rtx, rtx, rtx, rtx);
extern rtx        gen_vec_widen_smult_even_v4hi             (rtx, rtx, rtx);
extern rtx        gen_vec_widen_smult_odd_v4hi              (rtx, rtx, rtx);
extern rtx        gen_ashlv4hi3                             (rtx, rtx, rtx);
extern rtx        gen_ashlv2si3                             (rtx, rtx, rtx);
extern rtx        gen_ashrv4hi3                             (rtx, rtx, rtx);
extern rtx        gen_ashrv2si3                             (rtx, rtx, rtx);
extern rtx        gen_lshrv4hi3                             (rtx, rtx, rtx);
extern rtx        gen_lshrv2si3                             (rtx, rtx, rtx);
extern rtx        gen_vec_pack_ssat_v4hi                    (rtx, rtx, rtx);
extern rtx        gen_vec_pack_usat_v4hi                    (rtx, rtx, rtx);
extern rtx        gen_vec_pack_ssat_v2si                    (rtx, rtx, rtx);
extern rtx        gen_mux1_brcst_qi                         (rtx, rtx);
extern rtx        gen_mix2_even                             (rtx, rtx, rtx);
extern rtx        gen_mix2_odd                              (rtx, rtx, rtx);
extern rtx        gen_absv2sf2                              (rtx, rtx);
extern rtx        gen_negv2sf2                              (rtx, rtx);
extern rtx        gen_mulv2sf3                              (rtx, rtx, rtx);
extern rtx        gen_fmav2sf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_fmsv2sf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_fnmav2sf4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_smaxv2sf3                             (rtx, rtx, rtx);
extern rtx        gen_sminv2sf3                             (rtx, rtx, rtx);
extern rtx        gen_fpack                                 (rtx, rtx, rtx);
extern rtx        gen_fswap                                 (rtx, rtx, rtx);
extern rtx        gen_fmix_lr                               (rtx, rtx, rtx);
extern rtx        gen_cmpxchg_acq_qi                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cmpxchg_acq_hi                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cmpxchg_acq_si                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cmpxchg_rel_qi                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cmpxchg_rel_hi                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cmpxchg_rel_si                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cmpxchg_acq_di                        (rtx, rtx, rtx, rtx);
extern rtx        gen_cmpxchg_rel_di                        (rtx, rtx, rtx, rtx);
extern rtx        gen_xchg_acq_qi                           (rtx, rtx, rtx);
extern rtx        gen_xchg_acq_hi                           (rtx, rtx, rtx);
extern rtx        gen_xchg_acq_si                           (rtx, rtx, rtx);
extern rtx        gen_xchg_acq_di                           (rtx, rtx, rtx);
extern rtx        gen_fetchadd_acq_si                       (rtx, rtx, rtx);
extern rtx        gen_fetchadd_acq_di                       (rtx, rtx, rtx);
extern rtx        gen_fetchadd_rel_si                       (rtx, rtx, rtx);
extern rtx        gen_fetchadd_rel_di                       (rtx, rtx, rtx);
extern rtx        gen_addrf3_cond                           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_subrf3_cond                           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_mulrf3_cond                           (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_nmulrf3_cond                          (rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_m1addrf4_cond                         (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_m1subrf4_cond                         (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_m2addrf4_cond                         (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_m2subrf4_cond                         (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_extendsfrf2                           (rtx, rtx);
extern rtx        gen_extenddfrf2                           (rtx, rtx);
extern rtx        gen_extendxfrf2                           (rtx, rtx);
extern rtx        gen_truncrfsf2                            (rtx, rtx);
extern rtx        gen_truncrfdf2                            (rtx, rtx);
extern rtx        gen_truncrfxf2                            (rtx, rtx);
extern rtx        gen_fix_truncrfdi2_alts                   (rtx, rtx, rtx);
extern rtx        gen_fixuns_truncrfdi2_alts                (rtx, rtx, rtx);
extern rtx        gen_setf_exp_rf                           (rtx, rtx);
extern rtx        gen_recip_approx_rf                       (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sqrt_approx_rf                        (rtx, rtx, rtx, rtx);
extern rtx        gen_movqi                                 (rtx, rtx);
extern rtx        gen_movhi                                 (rtx, rtx);
extern rtx        gen_movsi                                 (rtx, rtx);
extern rtx        gen_movdi                                 (rtx, rtx);
extern rtx        gen_load_fptr                             (rtx, rtx);
extern rtx        gen_load_gprel64                          (rtx, rtx);
extern rtx        gen_load_dtprel                           (rtx, rtx);
extern rtx        gen_add_dtprel                            (rtx, rtx, rtx);
extern rtx        gen_load_tprel                            (rtx, rtx);
extern rtx        gen_add_tprel                             (rtx, rtx, rtx);
extern rtx        gen_movti                                 (rtx, rtx);
extern rtx        gen_movsf                                 (rtx, rtx);
extern rtx        gen_movdf                                 (rtx, rtx);
extern rtx        gen_movxf                                 (rtx, rtx);
extern rtx        gen_movrf                                 (rtx, rtx);
extern rtx        gen_movtf                                 (rtx, rtx);
extern rtx        gen_insv                                  (rtx, rtx, rtx, rtx);
extern rtx        gen_abssi2                                (rtx, rtx);
extern rtx        gen_sminsi3                               (rtx, rtx, rtx);
extern rtx        gen_smaxsi3                               (rtx, rtx, rtx);
extern rtx        gen_uminsi3                               (rtx, rtx, rtx);
extern rtx        gen_umaxsi3                               (rtx, rtx, rtx);
extern rtx        gen_absdi2                                (rtx, rtx);
extern rtx        gen_smindi3                               (rtx, rtx, rtx);
extern rtx        gen_smaxdi3                               (rtx, rtx, rtx);
extern rtx        gen_umindi3                               (rtx, rtx, rtx);
extern rtx        gen_umaxdi3                               (rtx, rtx, rtx);
extern rtx        gen_ffsdi2                                (rtx, rtx);
extern rtx        gen_ctzdi2                                (rtx, rtx);
extern rtx        gen_clzdi2                                (rtx, rtx);
extern rtx        gen_mulditi3                              (rtx, rtx, rtx);
extern rtx        gen_umulditi3                             (rtx, rtx, rtx);
extern rtx        gen_ashlsi3                               (rtx, rtx, rtx);
extern rtx        gen_ashrsi3                               (rtx, rtx, rtx);
extern rtx        gen_lshrsi3                               (rtx, rtx, rtx);
extern rtx        gen_rotrsi3                               (rtx, rtx, rtx);
extern rtx        gen_rotlsi3                               (rtx, rtx, rtx);
extern rtx        gen_rotrdi3                               (rtx, rtx, rtx);
extern rtx        gen_rotldi3                               (rtx, rtx, rtx);
extern rtx        gen_ashlti3                               (rtx, rtx, rtx);
extern rtx        gen_ashrti3                               (rtx, rtx, rtx);
extern rtx        gen_lshrti3                               (rtx, rtx, rtx);
extern rtx        gen_rotlti3                               (rtx, rtx, rtx);
extern rtx        gen_cbranchbi4                            (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsi4                            (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdi4                            (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchsf4                            (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchdf4                            (rtx, rtx, rtx, rtx);
extern rtx        gen_cbranchxf4                            (rtx, rtx, rtx, rtx);
static inline rtx gen_cbranchtf4                            (rtx, rtx, rtx, rtx);
static inline rtx
gen_cbranchtf4(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_doloop_end                            (rtx, rtx);
extern rtx        gen_cstorebi4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresi4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredi4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoresf4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_cstoredf4                             (rtx, rtx, rtx, rtx);
extern rtx        gen_cstorexf4                             (rtx, rtx, rtx, rtx);
static inline rtx gen_cstoretf4                             (rtx, rtx, rtx, rtx);
static inline rtx
gen_cstoretf4(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_call                                  (rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall                               (rtx, rtx, rtx, rtx);
extern rtx        gen_call_value                            (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_sibcall_value                         (rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_untyped_call                          (rtx, rtx, rtx);
extern rtx        gen_tablejump                             (rtx, rtx);
extern rtx        gen_prologue                              (void);
extern rtx        gen_epilogue                              (void);
extern rtx        gen_sibcall_epilogue                      (void);
extern rtx        gen_gr_spill                              (rtx, rtx, rtx);
extern rtx        gen_gr_restore                            (rtx, rtx, rtx);
extern rtx        gen_trap                                  (void);
extern rtx        gen_ctrapbi4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_ctrapsi4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_ctrapdi4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_ctrapsf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_ctrapdf4                              (rtx, rtx, rtx, rtx);
extern rtx        gen_ctrapxf4                              (rtx, rtx, rtx, rtx);
static inline rtx gen_ctraptf4                              (rtx, rtx, rtx, rtx);
static inline rtx
gen_ctraptf4(rtx ARG_UNUSED (a), rtx ARG_UNUSED (b), rtx ARG_UNUSED (c), rtx ARG_UNUSED (d))
{
  return 0;
}
extern rtx        gen_save_stack_nonlocal                   (rtx, rtx);
extern rtx        gen_nonlocal_goto                         (rtx, rtx, rtx, rtx);
extern rtx        gen_eh_epilogue                           (rtx, rtx, rtx);
extern rtx        gen_restore_stack_nonlocal                (rtx, rtx);
extern rtx        gen_movv8qi                               (rtx, rtx);
extern rtx        gen_movv4hi                               (rtx, rtx);
extern rtx        gen_movv2si                               (rtx, rtx);
extern rtx        gen_mulv8qi3                              (rtx, rtx, rtx);
extern rtx        gen_vec_widen_umult_lo_v8qi               (rtx, rtx, rtx);
extern rtx        gen_vec_widen_umult_hi_v8qi               (rtx, rtx, rtx);
extern rtx        gen_vec_widen_smult_lo_v8qi               (rtx, rtx, rtx);
extern rtx        gen_vec_widen_smult_hi_v8qi               (rtx, rtx, rtx);
extern rtx        gen_smulv4hi3_highpart                    (rtx, rtx, rtx);
extern rtx        gen_umulv4hi3_highpart                    (rtx, rtx, rtx);
extern rtx        gen_vec_widen_smult_lo_v4hi               (rtx, rtx, rtx);
extern rtx        gen_vec_widen_smult_hi_v4hi               (rtx, rtx, rtx);
extern rtx        gen_vec_widen_umult_lo_v4hi               (rtx, rtx, rtx);
extern rtx        gen_vec_widen_umult_hi_v4hi               (rtx, rtx, rtx);
extern rtx        gen_mulv2si3                              (rtx, rtx, rtx);
extern rtx        gen_umaxv8qi3                             (rtx, rtx, rtx);
extern rtx        gen_umaxv4hi3                             (rtx, rtx, rtx);
extern rtx        gen_umaxv2si3                             (rtx, rtx, rtx);
extern rtx        gen_smaxv8qi3                             (rtx, rtx, rtx);
extern rtx        gen_smaxv4hi3                             (rtx, rtx, rtx);
extern rtx        gen_smaxv2si3                             (rtx, rtx, rtx);
extern rtx        gen_uminv8qi3                             (rtx, rtx, rtx);
extern rtx        gen_uminv4hi3                             (rtx, rtx, rtx);
extern rtx        gen_uminv2si3                             (rtx, rtx, rtx);
extern rtx        gen_sminv8qi3                             (rtx, rtx, rtx);
extern rtx        gen_sminv4hi3                             (rtx, rtx, rtx);
extern rtx        gen_sminv2si3                             (rtx, rtx, rtx);
extern rtx        gen_vec_shl_v8qi                          (rtx, rtx, rtx);
extern rtx        gen_vec_shl_v4hi                          (rtx, rtx, rtx);
extern rtx        gen_vec_shl_v2si                          (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v8qi                          (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v4hi                          (rtx, rtx, rtx);
extern rtx        gen_vec_shr_v2si                          (rtx, rtx, rtx);
extern rtx        gen_widen_usumv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_widen_usumv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_widen_ssumv8qi3                       (rtx, rtx, rtx);
extern rtx        gen_widen_ssumv4hi3                       (rtx, rtx, rtx);
extern rtx        gen_vcondv8qiv8qi                         (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv4hiv4hi                         (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vcondv2siv2si                         (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv8qiv8qi                        (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv4hiv4hi                        (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vconduv2siv2si                        (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vec_initv2sisi                        (rtx, rtx);
extern rtx        gen_movv2sf                               (rtx, rtx);
extern rtx        gen_addv2sf3                              (rtx, rtx, rtx);
extern rtx        gen_subv2sf3                              (rtx, rtx, rtx);
extern rtx        gen_reduc_splus_v2sf                      (rtx, rtx);
extern rtx        gen_reduc_smax_v2sf                       (rtx, rtx);
extern rtx        gen_reduc_smin_v2sf                       (rtx, rtx);
extern rtx        gen_vcondv2sfv2sf                         (rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_vec_initv2sfsf                        (rtx, rtx);
extern rtx        gen_vec_setv2sf                           (rtx, rtx, rtx);
extern rtx        gen_vec_extractv2sfsf                     (rtx, rtx, rtx);
extern rtx        gen_vec_unpacku_lo_v8qi                   (rtx, rtx);
extern rtx        gen_vec_unpacku_lo_v4hi                   (rtx, rtx);
extern rtx        gen_vec_unpacku_hi_v8qi                   (rtx, rtx);
extern rtx        gen_vec_unpacku_hi_v4hi                   (rtx, rtx);
extern rtx        gen_vec_unpacks_lo_v8qi                   (rtx, rtx);
extern rtx        gen_vec_unpacks_lo_v4hi                   (rtx, rtx);
extern rtx        gen_vec_unpacks_hi_v8qi                   (rtx, rtx);
extern rtx        gen_vec_unpacks_hi_v4hi                   (rtx, rtx);
extern rtx        gen_vec_pack_trunc_v4hi                   (rtx, rtx, rtx);
extern rtx        gen_vec_pack_trunc_v2si                   (rtx, rtx, rtx);
extern rtx        gen_mem_thread_fence                      (rtx);
extern rtx        gen_memory_barrier                        (void);
extern rtx        gen_atomic_loadqi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_loadhi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_loadsi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_loaddi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_storeqi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_storehi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_storesi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_storedi                        (rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapqi             (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swaphi             (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapsi             (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_compare_and_swapdi             (rtx, rtx, rtx, rtx, rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangeqi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangehi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangesi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_exchangedi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_addqi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_subqi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_orqi                           (rtx, rtx, rtx);
extern rtx        gen_atomic_xorqi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_andqi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_addhi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_subhi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_orhi                           (rtx, rtx, rtx);
extern rtx        gen_atomic_xorhi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_andhi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_addsi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_subsi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_orsi                           (rtx, rtx, rtx);
extern rtx        gen_atomic_xorsi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_andsi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_adddi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_subdi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_ordi                           (rtx, rtx, rtx);
extern rtx        gen_atomic_xordi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_anddi                          (rtx, rtx, rtx);
extern rtx        gen_atomic_nandqi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_nandhi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_nandsi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_nanddi                         (rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addqi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subqi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orqi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorqi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andqi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addhi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subhi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orhi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorhi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andhi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_addsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_orsi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xorsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_andsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_adddi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_subdi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_ordi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_xordi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_anddi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandqi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandhi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nandsi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_fetch_nanddi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_add_fetchqi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_sub_fetchqi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_or_fetchqi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_xor_fetchqi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_and_fetchqi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_add_fetchhi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_sub_fetchhi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_or_fetchhi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_xor_fetchhi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_and_fetchhi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_add_fetchsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_sub_fetchsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_or_fetchsi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_xor_fetchsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_and_fetchsi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_add_fetchdi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_sub_fetchdi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_or_fetchdi                     (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_xor_fetchdi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_and_fetchdi                    (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_nand_fetchqi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_nand_fetchhi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_nand_fetchsi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_atomic_nand_fetchdi                   (rtx, rtx, rtx, rtx);
extern rtx        gen_divsf3                                (rtx, rtx, rtx);
extern rtx        gen_divsf3_internal_thr                   (rtx, rtx, rtx);
extern rtx        gen_divsf3_internal_lat                   (rtx, rtx, rtx);
extern rtx        gen_divdf3                                (rtx, rtx, rtx);
extern rtx        gen_divdf3_internal_thr                   (rtx, rtx, rtx);
extern rtx        gen_divdf3_internal_lat                   (rtx, rtx, rtx);
extern rtx        gen_divxf3                                (rtx, rtx, rtx);
extern rtx        gen_divsi3                                (rtx, rtx, rtx);
extern rtx        gen_modsi3                                (rtx, rtx, rtx);
extern rtx        gen_udivsi3                               (rtx, rtx, rtx);
extern rtx        gen_umodsi3                               (rtx, rtx, rtx);
extern rtx        gen_divsi3_internal                       (rtx, rtx, rtx);
extern rtx        gen_divdi3                                (rtx, rtx, rtx);
extern rtx        gen_moddi3                                (rtx, rtx, rtx);
extern rtx        gen_udivdi3                               (rtx, rtx, rtx);
extern rtx        gen_umoddi3                               (rtx, rtx, rtx);
extern rtx        gen_divdi3_internal_lat                   (rtx, rtx, rtx);
extern rtx        gen_divdi3_internal_thr                   (rtx, rtx, rtx);
extern rtx        gen_sqrtsf2                               (rtx, rtx);
extern rtx        gen_sqrtsf2_internal_thr                  (rtx, rtx);
extern rtx        gen_sqrtsf2_internal_lat                  (rtx, rtx);
extern rtx        gen_sqrtdf2                               (rtx, rtx);
extern rtx        gen_sqrtdf2_internal_thr                  (rtx, rtx);
extern rtx        gen_sqrtxf2                               (rtx, rtx);

#endif /* GCC_INSN_FLAGS_H */
