/* Generated automatically by the program 'build/genpreds'
   from the machine description file '/home/ramin/openadk/toolchain_build_generic-ia64_uclibc-ng/w-gcc-13.2.0-1/gcc-13.2.0/gcc/config/ia64/ia64.md'.  */

#ifndef GCC_TM_PREDS_H
#define GCC_TM_PREDS_H

#ifdef HAVE_MACHINE_MODES
extern bool general_operand (rtx, machine_mode);
extern bool address_operand (rtx, machine_mode);
extern bool register_operand (rtx, machine_mode);
extern bool pmode_register_operand (rtx, machine_mode);
extern bool scratch_operand (rtx, machine_mode);
extern bool immediate_operand (rtx, machine_mode);
extern bool const_int_operand (rtx, machine_mode);
extern bool const_double_operand (rtx, machine_mode);
extern bool nonimmediate_operand (rtx, machine_mode);
extern bool nonmemory_operand (rtx, machine_mode);
extern bool push_operand (rtx, machine_mode);
extern bool pop_operand (rtx, machine_mode);
extern bool memory_operand (rtx, machine_mode);
extern bool indirect_operand (rtx, machine_mode);
extern bool ordered_comparison_operator (rtx, machine_mode);
extern bool comparison_operator (rtx, machine_mode);
extern bool call_operand (rtx, machine_mode);
extern bool symbolic_operand (rtx, machine_mode);
extern bool function_operand (rtx, machine_mode);
extern bool sdata_symbolic_operand (rtx, machine_mode);
extern bool local_symbolic_operand64 (rtx, machine_mode);
extern bool small_addr_symbolic_operand (rtx, machine_mode);
extern bool any_offset_symbol_operand (rtx, machine_mode);
extern bool aligned_offset_symbol_operand (rtx, machine_mode);
extern bool got_symbolic_operand (rtx, machine_mode);
extern bool tls_symbolic_operand (rtx, machine_mode);
extern bool ld_tls_symbolic_operand (rtx, machine_mode);
extern bool ie_tls_symbolic_operand (rtx, machine_mode);
extern bool le_tls_symbolic_operand (rtx, machine_mode);
extern bool destination_operand (rtx, machine_mode);
extern bool not_postinc_destination_operand (rtx, machine_mode);
extern bool not_postinc_memory_operand (rtx, machine_mode);
extern bool move_operand (rtx, machine_mode);
extern bool not_postinc_move_operand (rtx, machine_mode);
extern bool gr_register_operand (rtx, machine_mode);
extern bool fr_register_operand (rtx, machine_mode);
extern bool grfr_register_operand (rtx, machine_mode);
extern bool gr_nonimmediate_operand (rtx, machine_mode);
extern bool fr_nonimmediate_operand (rtx, machine_mode);
extern bool grfr_nonimmediate_operand (rtx, machine_mode);
extern bool gr_reg_or_0_operand (rtx, machine_mode);
extern bool gr_reg_or_5bit_operand (rtx, machine_mode);
extern bool gr_reg_or_6bit_operand (rtx, machine_mode);
extern bool gr_reg_or_8bit_operand (rtx, machine_mode);
extern bool grfr_reg_or_8bit_operand (rtx, machine_mode);
extern bool gr_reg_or_8bit_adjusted_operand (rtx, machine_mode);
extern bool gr_reg_or_8bit_and_adjusted_operand (rtx, machine_mode);
extern bool gr_reg_or_14bit_operand (rtx, machine_mode);
extern bool gr_reg_or_22bit_operand (rtx, machine_mode);
extern bool dshift_count_operand (rtx, machine_mode);
extern bool shift_count_operand (rtx, machine_mode);
extern bool extr_len_operand (rtx, machine_mode);
extern bool shift_32bit_count_operand (rtx, machine_mode);
extern bool shladd_operand (rtx, machine_mode);
extern bool shladd_log2_operand (rtx, machine_mode);
extern bool fetchadd_operand (rtx, machine_mode);
extern bool pmpyshr_operand (rtx, machine_mode);
extern bool const_int_2bit_operand (rtx, machine_mode);
extern bool fr_reg_or_fp01_operand (rtx, machine_mode);
extern bool xfreg_or_fp01_operand (rtx, machine_mode);
extern bool fr_reg_or_signed_fp01_operand (rtx, machine_mode);
extern bool xfreg_or_signed_fp01_operand (rtx, machine_mode);
extern bool fr_reg_or_0_operand (rtx, machine_mode);
extern bool ia64_cbranch_operator (rtx, machine_mode);
extern bool normal_comparison_operator (rtx, machine_mode);
extern bool adjusted_comparison_operator (rtx, machine_mode);
extern bool signed_inequality_operator (rtx, machine_mode);
extern bool predicate_operator (rtx, machine_mode);
extern bool condop_operator (rtx, machine_mode);
extern bool ar_lc_reg_operand (rtx, machine_mode);
extern bool ar_ccv_reg_operand (rtx, machine_mode);
extern bool ar_pfs_reg_operand (rtx, machine_mode);
extern bool basereg_operand (rtx, machine_mode);
extern bool mux1_brcst_element (rtx, machine_mode);
#endif /* HAVE_MACHINE_MODES */

#define CONSTRAINT_NUM_DEFINED_P 1
enum constraint_num
{
  CONSTRAINT__UNKNOWN = 0,
  CONSTRAINT_r,
  CONSTRAINT_a,
  CONSTRAINT_b,
  CONSTRAINT_c,
  CONSTRAINT_d,
  CONSTRAINT_e,
  CONSTRAINT_f,
  CONSTRAINT_x,
  CONSTRAINT_I,
  CONSTRAINT_J,
  CONSTRAINT_K,
  CONSTRAINT_L,
  CONSTRAINT_M,
  CONSTRAINT_N,
  CONSTRAINT_O,
  CONSTRAINT_P,
  CONSTRAINT_m,
  CONSTRAINT_o,
  CONSTRAINT_S,
  CONSTRAINT_p,
  CONSTRAINT_j,
  CONSTRAINT_G,
  CONSTRAINT_Z,
  CONSTRAINT_H,
  CONSTRAINT_R,
  CONSTRAINT_T,
  CONSTRAINT_U,
  CONSTRAINT_W,
  CONSTRAINT_Y,
  CONSTRAINT_V,
  CONSTRAINT__l,
  CONSTRAINT__g,
  CONSTRAINT_i,
  CONSTRAINT_s,
  CONSTRAINT_n,
  CONSTRAINT_E,
  CONSTRAINT_F,
  CONSTRAINT_X,
  CONSTRAINT_Q,
  CONSTRAINT__LIMIT
};

extern enum constraint_num lookup_constraint_1 (const char *);
extern const unsigned char lookup_constraint_array[];

/* Return the constraint at the beginning of P, or CONSTRAINT__UNKNOWN if it
   isn't recognized.  */

static inline enum constraint_num
lookup_constraint (const char *p)
{
  unsigned int index = lookup_constraint_array[(unsigned char) *p];
  return (index == UCHAR_MAX
          ? lookup_constraint_1 (p)
          : (enum constraint_num) index);
}

extern bool (*constraint_satisfied_p_array[]) (rtx);

/* Return true if X satisfies constraint C.  */

static inline bool
constraint_satisfied_p (rtx x, enum constraint_num c)
{
  int i = (int) c - (int) CONSTRAINT_I;
  return i >= 0 && constraint_satisfied_p_array[i] (x);
}

static inline bool
insn_extra_register_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_r && c <= CONSTRAINT_x;
}

static inline bool
insn_extra_memory_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_m && c <= CONSTRAINT_S;
}

static inline bool
insn_extra_special_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_relaxed_memory_constraint (enum constraint_num)
{
  return false;
}

static inline bool
insn_extra_address_constraint (enum constraint_num c)
{
  return c >= CONSTRAINT_p && c <= CONSTRAINT_p;
}

static inline void
insn_extra_constraint_allows_reg_mem (enum constraint_num c,
				      bool *allows_reg, bool *allows_mem)
{
  if (c >= CONSTRAINT_j && c <= CONSTRAINT_Y)
    return;
  if (c >= CONSTRAINT_V && c <= CONSTRAINT__g)
    {
      *allows_mem = true;
      return;
    }
  (void) c;
  *allows_reg = true;
  *allows_mem = true;
}

#define CONSTRAINT_LEN(c_,s_) 1

extern enum reg_class reg_class_for_constraint_1 (enum constraint_num);

static inline enum reg_class
reg_class_for_constraint (enum constraint_num c)
{
  if (insn_extra_register_constraint (c))
    return reg_class_for_constraint_1 (c);
  return NO_REGS;
}

extern bool insn_const_int_ok_for_constraint (HOST_WIDE_INT, enum constraint_num);
#define CONST_OK_FOR_CONSTRAINT_P(v_,c_,s_) \
    insn_const_int_ok_for_constraint (v_, lookup_constraint (s_))

enum constraint_type
{
  CT_REGISTER,
  CT_CONST_INT,
  CT_MEMORY,
  CT_SPECIAL_MEMORY,
  CT_RELAXED_MEMORY,
  CT_ADDRESS,
  CT_FIXED_FORM
};

static inline enum constraint_type
get_constraint_type (enum constraint_num c)
{
  if (c >= CONSTRAINT_p)
    {
      if (c >= CONSTRAINT_j)
        return CT_FIXED_FORM;
      return CT_ADDRESS;
    }
  if (c >= CONSTRAINT_m)
    return CT_MEMORY;
  if (c >= CONSTRAINT_I)
    return CT_CONST_INT;
  return CT_REGISTER;
}
#endif /* tm-preds.h */
