#ifndef GCC_TM_P_H
#define GCC_TM_P_H
#ifdef IN_GCC
# include "config/ia64/ia64-protos.h"
# include "config/linux-protos.h"
# include "tm-preds.h"
#endif
#endif /* GCC_TM_P_H */
