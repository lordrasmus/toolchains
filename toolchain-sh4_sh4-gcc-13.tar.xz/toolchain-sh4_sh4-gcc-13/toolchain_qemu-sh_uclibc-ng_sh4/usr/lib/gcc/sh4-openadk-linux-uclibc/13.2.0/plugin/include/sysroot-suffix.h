#undef SYSROOT_SUFFIX_SPEC
#define SYSROOT_SUFFIX_SPEC "" \
"%{m4:/m4;" \
"m4-nofpu:/m4-nofpu;" \
":}"
