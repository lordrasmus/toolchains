/* Generated automatically. */
static const char configuration_arguments[] = "/home/ramin/openadk/toolchain_build_generic-sparc64_uclibc-ng_v9/w-gcc-10.5.0-1/gcc-10.5.0/configure --prefix=/home/ramin/openadk/toolchain_generic-sparc64_uclibc-ng_v9/usr --with-bugurl=https://openadk.org --build=x86_64-linux-gnu --host=x86_64-linux-gnu --target=sparc64-openadk-linux-uclibc --with-gmp=/home/ramin/openadk/host_x86_64-linux-gnu/usr --with-mpfr=/home/ramin/openadk/host_x86_64-linux-gnu/usr --enable-__cxa_atexit --with-system-zlib --with-gnu-ld --with-gnu-as --disable-libsanitizer --disable-install-libiberty --disable-libitm --disable-libmudflap --disable-libgomp --disable-libcc1 --disable-libmpx --disable-libcilkrts --disable-libquadmath --disable-libquadmath-support --disable-decimal-float --disable-gcov --disable-libstdcxx-pch --disable-ppl-version-check --disable-cloog-version-check --without-ppl --without-cloog --without-isl --disable-werror --disable-nls --enable-obsolete --disable-lto --with-cpu=ultrasparc --disable-tls --enable-languages=c --with-newlib --disable-shared --disable-threads --disable-multilib --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "ultrasparc" } };
